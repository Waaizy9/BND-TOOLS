"""Check and optionally install Python dependencies."""
import importlib
import subprocess
import sys
import os

REQUIRED = [
    ("colorama", "colorama"),
    ("rich", "rich"),
]

OPTIONAL = [
    ("dns.resolver", "dnspython"),
    ("requests", "requests"),
]


def check_deps(auto_install=True) -> bool:
    missing = []
    for mod, pkg in REQUIRED + OPTIONAL:
        try:
            importlib.import_module(mod.split(".")[0] if "." in mod else mod)
        except ImportError:
            missing.append(pkg)

    if not missing:
        return True

    if auto_install:
        pkgs = list(dict.fromkeys(missing))
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-q"] + pkgs,
                check=False,
                capture_output=True,
            )
            if result.returncode != 0:
                print(
                    f"[deps] pip install failed (exit {result.returncode}): "
                    f"{result.stderr.decode(errors='replace').strip()}",
                    file=sys.stderr,
                )
            return True
        except FileNotFoundError as e:
            print(f"[deps] pip not found: {e}", file=sys.stderr)
        except OSError as e:
            print(f"[deps] install error: {e}", file=sys.stderr)
    return len([p for p in missing if p in [x[1] for x in REQUIRED]]) == 0