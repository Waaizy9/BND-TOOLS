import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, re, time, math
import requests
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box

console = Console()
TIMEOUT = 10

IP_REGEX = re.compile(r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')

# BND-IP Banner mit Matrix Style
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ██╗██████╗ 
  ██╔══██╗████╗  ██║██╔══██╗    ██║██╔══██╗
  ██████╔╝██╔██╗ ██║██║  ██║    ██║██████╔╝
  ██╔══██╗██║╚██╗██║██║  ██║    ██║██╔═══╝ 
  ██████╔╝██║ ╚████║██████╔╝    ██║██║     
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚═╝╚═╝     
"""

SUBTITLE = "B N D - I P   -   A D V A N C E D   G E O - T R A C K I N G"

# Farben
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
DIM = "\033[90m"
RESET = "\033[0m"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-IP // IP LOCALISATION")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(100 + 155 * math.sin(t * 10 - c * 0.2))))
                        sys.stdout.write(f"\033[38;2;0;0;{v}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {BLUE}{SUBTITLE}{RESET}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def geolocate(ip):
    """Mehrere API Quellen"""
    try:
        r = requests.get(
            f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,isp,org,as,query,mobile,proxy,hosting",
            timeout=TIMEOUT
        )
        if r.status_code == 200:
            data = r.json()
            if data.get("status") == "success":
                return data
    except (requests.RequestException, ValueError):
        pass
    
    try:
        r = requests.get(f"https://ipinfo.io/{ip}/json", timeout=TIMEOUT)
        if r.status_code == 200:
            data = r.json()
            loc = data.get("loc", "").split(",")
            lat = loc[0] if len(loc) > 0 else None
            lon = loc[1] if len(loc) > 1 else None
            return {
                "status": "success",
                "query": ip,
                "country": data.get("country", "N/A"),
                "regionName": data.get("region", "N/A"),
                "city": data.get("city", "N/A"),
                "zip": data.get("postal", "N/A"),
                "lat": lat,
                "lon": lon,
                "isp": data.get("org", "N/A"),
                "org": data.get("org", "N/A"),
            }
    except Exception:
        pass
    
    return {"status": "fail", "message": "API nicht erreichbar"}

def display(data, ip):
    if data.get("status") == "fail":
        console.print(Panel(f"[red]  API Error: {data.get('message', 'Unknown')}[/]", border_style="blue"))
        return

    tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style="blue", show_header=False,
                padding=(0, 2), expand=False)
    tbl.add_column("KEY", style="dim blue", width=18, no_wrap=True)
    tbl.add_column("VAL", style="white")

    proxy_tag = "[bold red]  YES  ─ VPN/PROXY DETECTED[/]" if data.get("proxy") else "[dim green]No[/]"
    mob_tag   = "[green]Yes[/]"  if data.get("mobile")  else "[dim]No[/]"
    host_tag  = "[yellow]Yes[/]" if data.get("hosting") else "[dim]No[/]"

    tbl.add_row("RESOLVED IP",    f"[bold white]{data.get('query', ip)}[/]")
    tbl.add_row("COUNTRY",        f"[bold white]{data.get('country','N/A')}[/] [dim]({data.get('countryCode','??')})[/]")
    tbl.add_row("REGION",         data.get("regionName", "N/A"))
    tbl.add_row("CITY",           data.get("city", "N/A"))
    tbl.add_row("ZIP CODE",       data.get("zip", "N/A"))
    tbl.add_row("COORDS",         f"[cyan]{data.get('lat','?')}°N, {data.get('lon','?')}°E[/]")
    tbl.add_row("ISP",            f"[cyan]{data.get('isp', 'N/A')}[/]")
    tbl.add_row("ORGANIZATION",   data.get("org", "N/A"))
    tbl.add_row("ASN",            f"[dim]{data.get('as', 'N/A')}[/]")
    tbl.add_row("PROXY / VPN",    proxy_tag)
    tbl.add_row("MOBILE",         mob_tag)
    tbl.add_row("HOSTING",        host_tag)

    console.print()
    console.print(Align.center(Panel(
        tbl,
        title=f"[bold blue]  GEOLOCATION[/]  [dim white]─[/]  [white]{data.get('query', ip)}[/]",
        border_style="blue",
        padding=(1, 3),
    )))
    console.print()

    lat, lon = data.get("lat"), data.get("lon")
    if lat and lon:
        maps = f"https://www.google.com/maps?q={lat},{lon}"
        console.print(Align.center(f"[dim]  Google Maps :[/]  [cyan underline]{maps}[/]"))
        console.print()

if __name__ == "__main__":
    try:
        boot()

        console.print(Align.center(Panel(
            Text.from_markup("[bold blue]BND-IP[/]  [dim]//[/]  [white]IP LOCALISATION[/]  [dim]//[/]  [blue]GEO-TRACKING[/]"),
            border_style="blue", padding=(0, 6)
        )))
        console.print()

        console.print(" [blue]┌─[[/][bold white] Target IP Address [/][blue]][/]")
        ip = console.input(" [blue]└─▶[/] [bold white]").strip()

        if not ip:
            console.print("\n[red] [!] No address entered.[/]")
            sys.exit(0)

        if not IP_REGEX.match(ip):
            console.print(f"\n[red] [!] Invalid IPv4 format:[/] [white]{ip}[/]")
            sys.exit(0)

        console.print()
        with Progress(
            SpinnerColumn(spinner_name="point", style="blue"),
            TextColumn("[dim white]{task.description}"),
            console=console, transient=True,
        ) as p:
            p.add_task("Querying geolocation API...", total=None)
            data = geolocate(ip)

        display(data, ip)
        console.input(" [dim]Press [bold blue]ENTER[/] to quit...[/]")

    except requests.RequestException as e:
        console.print(f"\n[red] [!] Network error:[/] {e}")
    except (KeyboardInterrupt, EOFError):
        console.print("\n[red] [!] Interrupted.[/]")