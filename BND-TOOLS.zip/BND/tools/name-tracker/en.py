import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, requests, webbrowser, json
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

SITES = {
    "Twitter": "https://twitter.com/{}", "Facebook": "https://www.facebook.com/{}",
    "Instagram": "https://www.instagram.com/{}", "GitHub": "https://github.com/{}",
    "Reddit": "https://www.reddit.com/user/{}", "LinkedIn": "https://www.linkedin.com/in/{}",
    "Pinterest": "https://www.pinterest.com/{}", "YouTube": "https://www.youtube.com/{}",
    "TikTok": "https://www.tiktok.com/@{}", "Twitch": "https://www.twitch.tv/{}",
    "SoundCloud": "https://soundcloud.com/{}", "Medium": "https://medium.com/@{}",
    "DeviantArt": "https://www.deviantart.com/{}", "Behance": "https://www.behance.net/{}",
    "Patreon": "https://www.patreon.com/{}", "GitLab": "https://gitlab.com/{}",
    "Snapchat": "https://www.snapchat.com/add/{}", "Telegram": "https://t.me/{}"
}

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"}

# BND-TOOLS Banner - KEIN VOID MEHR
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}M U L T I - P L A T F O R M   U S E R N A M E   R E C O N{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // NAME TRACKER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        # Verwende die ausgewählte Farbe
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.1))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def check_user(site, template, user):
    url = template.format(user)
    try:
        r = requests.get(url, headers=HEADERS, timeout=8, allow_redirects=True)
        if r.status_code == 200:
            if "not found" not in r.text.lower() and "doesn't exist" not in r.text.lower():
                return (site, True, url)
    except: pass
    return (site, False, None)

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]NAME TRACKER[/]  [dim]//[/]  [{CURRENT_HEX}]OSINT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()

        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Username to search [/][{CURRENT_HEX}]][/]")
        user = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        if not user: sys.exit(0)

        results = []
        with Progress(
            SpinnerColumn(style=CURRENT_HEX),
            TextColumn("[dim]{task.description}"),
            BarColumn(bar_width=30, style="dark_red", complete_style=CURRENT_HEX),
            console=console, transient=True
        ) as prog:
            task = prog.add_task(f"Tracking '{user}'...", total=len(SITES))
            with ThreadPoolExecutor(max_workers=20) as ex:
                futs = {ex.submit(check_user, site, url, user): site for site, url in SITES.items()}
                for f in as_completed(futs):
                    results.append(f.result())
                    prog.advance(task)

        trouves = [r for r in results if r[1]]
        
        tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, header_style=f"bold {CURRENT_HEX}")
        tbl.add_column("PLATFORM", style="white")
        tbl.add_column("STATUS", justify="center")
        tbl.add_column("LINK", style="cyan")

        for site, found, url in sorted(results, key=lambda x: x[0]):
            if found:
                tbl.add_row(site, f"[bold {CURRENT_HEX}]FOUND[/]", url)
            else:
                tbl.add_row(f"[dim]{site}[/]", "[dim red]ABSENT[/]", "[dim]—[/]")

        os.system("cls" if os.name == "nt" else "clear")
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]NAME TRACKER[/]  [dim]//[/]  [{CURRENT_HEX}]RESULTS[/]"),
            border_style=CURRENT_HEX, padding=(0, 4)
        )))
        console.print(Align.center(tbl))
        console.print(Align.center(f"\n [bold {CURRENT_HEX}]Found: {len(trouves)}[/] [dim]/ {len(SITES)} sites tested[/]"))

        if trouves:
            console.print(f"\n [{CURRENT_HEX}]┌─[[/][bold white] Open links? (yes/no) [/][{CURRENT_HEX}]][/]")
            ask = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip().lower()
            if ask in ("yes", "y", "oui", "o"):
                for _, _, url in trouves: webbrowser.open(url)

        console.input("\n [dim]Press [bold red]ENTER[/] to exit...[/]")

    except (KeyboardInterrupt, EOFError):
        pass