import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, re, requests, json
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box

console = Console()
IP_REGEX = re.compile(r'^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}D E E P   I P   I N T E L L I G E N C E   L O O K U P{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // IP LOOKUP")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.15))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def lookup_ip(ip):
    try:
        r = requests.get(f"http://ip-api.com/json/{ip}?fields=66846719", timeout=8)
        return r.json()
    except (requests.RequestException, ValueError):
        return {}

def display_intel(ip, data):
    tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, show_header=False, padding=(0, 2))
    tbl.add_column("K", style=f"dim {CURRENT_HEX}", width=18)
    tbl.add_column("V", style="white")

    tbl.add_row("IP ADDRESS", f"[bold white]{ip}[/]")
    tbl.add_row("COUNTRY", data.get("country", "—"))
    tbl.add_row("REGION", data.get("regionName", "—"))
    tbl.add_row("CITY", data.get("city", "—"))
    tbl.add_row("ZIP CODE", data.get("zip", "—"))
    tbl.add_row("COORDINATES", f"{data.get('lat','—')} / {data.get('lon','—')}")
    tbl.add_row("TIMEZONE", data.get("timezone", "—"))
    tbl.add_row("ISP", f"[{CURRENT_HEX}]{data.get('isp','—')}[/]")
    tbl.add_row("ORGANIZATION", data.get("org", "—"))
    tbl.add_row("ASN", data.get("as", "—"))
    
    proxy_status = "[red]YES[/]" if data.get("proxy") else f"[{CURRENT_HEX}]No[/]"
    tbl.add_row("PROXY / VPN", proxy_status)
    
    hosting_status = f"[{CURRENT_HEX}]Yes[/]" if data.get("hosting") else "No"
    tbl.add_row("DATACENTER", hosting_status)

    console.print(Align.center(Panel(tbl, title=f"[bold {CURRENT_HEX}] INTEL [/] [dim]─[/] [white]{ip}[/]", border_style=CURRENT_HEX)))
    console.print()

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]IP LOOKUP[/]  [dim]//[/]  [{CURRENT_HEX}]OSINT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()

        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] IP Address [/][{CURRENT_HEX}]][/]")
        ip = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        if not ip: sys.exit(0)

        if not IP_REGEX.match(ip):
            console.print(f"\n [{CURRENT_HEX}][!]{RESET} [white]Invalid IP format:[/] {ip}")
            time.sleep(2); sys.exit(0)

        with Progress(SpinnerColumn(style=CURRENT_HEX), TextColumn("[dim]{task.description}"), console=console, transient=True) as p:
            p.add_task("Querying database...", total=None)
            data = lookup_ip(ip)

        os.system("cls" if os.name == "nt" else "clear")
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]IP LOOKUP[/]  [dim]//[/]  [{CURRENT_HEX}]REPORT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        display_intel(ip, data)
        console.input(f" [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

    except (KeyboardInterrupt, EOFError):
        pass