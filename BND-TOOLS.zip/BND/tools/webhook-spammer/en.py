#!/usr/bin/env python3
"""BND-TOOLS // WEBHOOK SPAMMER"""

import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, aiohttp, json, random, re

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // WEBHOOK SPAMMER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== SPAM MESSAGES ==============
SPAM_MESSAGES = [
    "@everyone **BND-TOOLS** https://discord.gg/Gc2MKCJvtm",
    "@everyone **JOIN US** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS ON TOP** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BEST OSINT TOOLS** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS FTW** https://discord.gg/Gc2MKCJvtm",
    "@everyone **FREE TOOLS** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS 2024** https://discord.gg/Gc2MKCJvtm",
    "@everyone **JOIN THE COMMUNITY** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS BEST** https://discord.gg/Gc2MKCJvtm",
    "@everyone **DISCORD TOOLS** https://discord.gg/Gc2MKCJvtm"
]

def validate_webhook(url):
    pattern = r'https://discord\.com/api/webhooks/[0-9]+/[a-zA-Z0-9_-]+'
    return re.match(pattern, url) is not None

async def spam_webhook(session, webhook_url, message, count, delay, username, avatar_url, show_progress=False):
    spam_count = 0
    errors = 0
    
    for i in range(count):
        try:
            if message == "random":
                msg = random.choice(SPAM_MESSAGES)
            elif message == "sequential":
                msg = SPAM_MESSAGES[i % len(SPAM_MESSAGES)]
            else:
                msg = message
            
            msg = msg.replace("{count}", str(i+1))
            msg = msg.replace("{total}", str(count))
            
            payload = {
                "content": msg,
                "username": username,
                "avatar_url": avatar_url
            }
            
            async with session.post(webhook_url, json=payload) as r:
                if r.status == 204:
                    spam_count += 1
                    if show_progress and (i % 10 == 0 or i == count-1):
                        console.print(f" [dim]Progress: {i+1}/{count} messages sent[/]")
                else:
                    errors += 1
                    if show_progress:
                        console.print(f" [red]Error {r.status} at message {i+1}[/]")
            
            if delay > 0:
                await asyncio.sleep(delay)
        except Exception as e:
            errors += 1
            if show_progress:
                console.print(f" [red]Error: {str(e)[:50]} at message {i+1}[/]")
    
    return spam_count, errors

async def get_webhook_info(session, webhook_url):
    try:
        async with session.get(webhook_url) as r:
            if r.status == 200:
                return await r.json()
            return None
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        console.print(f" [dim]Webhook info request failed: {e}[/]")
        return None

async def delete_webhook(session, webhook_url):
    try:
        async with session.delete(webhook_url) as r:
            return r.status in [200, 204]
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        console.print(f" [dim]Webhook delete failed: {e}[/]")
        return False

def main():
    boot()
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]WEBHOOK SPAMMER[/]"),
        border_style=CURRENT_HEX, padding=(0, 5)
    )))
    console.print()
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Webhook URL [/][bold {CURRENT_HEX}]][/]")
    webhook = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    
    if not webhook:
        console.print("\n [red]No webhook provided![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    if not validate_webhook(webhook):
        console.print("\n [red]Invalid webhook URL![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Message (custom/random/sequential) [/][bold {CURRENT_HEX}]][/]")
    msg_choice = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip().lower() or "random"
    
    if msg_choice == "custom":
        console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Your message [/][bold {CURRENT_HEX}]][/]")
        message = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "BND-TOOLS"
    else:
        message = msg_choice if msg_choice in ["random", "sequential"] else "random"
    
    try:
        console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] How many messages [/][bold {CURRENT_HEX}]][/]")
        count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "10")
    except (ValueError, EOFError):
        count = 10
    
    try:
        console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Delay (seconds) [/][bold {CURRENT_HEX}]][/]")
        delay = float(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "0.3")
    except (ValueError, EOFError):
        delay = 0.3
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Webhook username [/][bold {CURRENT_HEX}]][/]")
    username = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "BND-TOOLS"
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Avatar URL (optional) [/][bold {CURRENT_HEX}]][/]")
    avatar = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    if not avatar:
        avatar = "https://cdn.discordapp.com/attachments/1323423423/bnd.png"
    
    console.print(f"\n [bold yellow]Starting webhook spam...[/]")
    console.print(f" [dim]Messages: {count} | Delay: {delay}s | Type: {message}[/]\n")
    
    async def run():
        async with aiohttp.ClientSession() as session:
            sent, errors = await spam_webhook(
                session, webhook, message, count, delay, 
                username, avatar, show_progress=True
            )
            console.print(f"\n [bold green]✓ Sent: {sent} messages[/]")
            console.print(f" [bold red]✗ Errors: {errors}[/]")
    
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

if __name__ == "__main__":
    main()