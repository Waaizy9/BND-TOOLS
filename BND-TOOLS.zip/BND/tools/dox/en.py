import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, json
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}H I G H - F I D E L I T Y   D O S S I E R   G E N E R A T O R{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // DOX CREATOR")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.1))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def ask_field(prompt):
    return console.input(f" [{CURRENT_HEX}]─▶[/] [white]{prompt}: [/]").strip() or "N/A"

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]DOX CREATOR[/]  [dim]//[/]  [{CURRENT_HEX}]OSINT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()

        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Filename [/][{CURRENT_HEX}]][/]")
        fn = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip() or "dox_output"

        data = {}
        sections = {
            "IDENTITY": ["Last Name", "First Name", "Age", "Date of Birth", "City", "Address"],
            "CONTACTS": ["Email", "Phone", "Discord", "Instagram", "Twitter"],
            "FAMILY":   ["Father's Name", "Father's Work", "Mother's Name", "Mother's Work"],
            "HARDWARE": ["IP Address", "MAC Address", "PC Model", "OS"]
        }

        for sec, fields in sections.items():
            console.print(f"\n [{CURRENT_HEX}]── {sec} ──{RESET}")
            for f in fields:
                data[f] = ask_field(f)

        save_path = os.path.join(os.getcwd(), "BND - Output", "Save-Dox")
        if not os.path.exists(save_path): os.makedirs(save_path, exist_ok=True)
        final_file = os.path.join(save_path, f"{fn}.txt")

        report = f"""
  ╔══════════════════════════════════════════════════════════════════╗
  ║                 BND-TOOLS // INFORMATION DOSSIER                 ║
  ╚══════════════════════════════════════════════════════════════════╝

  [+] IDENTITY
  > Last Name : {data.get('Last Name')}
  > First Name : {data.get('First Name')}
  > Age : {data.get('Age')}
  > Born on : {data.get('Date of Birth')}
  > City : {data.get('City')}
  > Address : {data.get('Address')}

  [+] CONTACTS
  > Email : {data.get('Email')}
  > Phone : {data.get('Phone')}
  > Discord : {data.get('Discord')}
  > Instagram : {data.get('Instagram')}
  > Twitter : {data.get('Twitter')}

  [+] FAMILY
  > Father : {data.get("Father's Name")} ({data.get("Father's Work")})
  > Mother : {data.get("Mother's Name")} ({data.get("Mother's Work")})

  [+] HARDWARE
  > IP : {data.get('IP Address')}
  > MAC : {data.get('MAC Address')}
  > Machine : {data.get('PC Model')} ({data.get('OS')})

  Generated by BND-TOOLS v2.0 PRIME
"""
        with open(final_file, "w", encoding="utf-8") as f: f.write(report)

        console.print(f"\n [{CURRENT_HEX}][✓]{RESET} [white]Dossier saved : {final_file}[/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

    except (KeyboardInterrupt, EOFError):
        pass