import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, re, requests, concurrent.futures, json, random, string
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box
from datetime import datetime

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# ============== BANNER ==============
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}D I S C O R D   N I T R O   S C A N N E R{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // NITRO SCANNER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.1))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== DISCORD USER VALIDATOR ==============
class DiscordUserValidator:
    """Validiert Discord Usernamen über die Discord API"""
    
    @staticmethod
    def check_username(username):
        """Prüft ob ein Username auf Discord existiert"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json',
            }
            
            response = requests.get(
                f'https://discord.com/api/v9/users/{username}',
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return True, response.json()
            elif response.status_code == 404:
                return False, None
            else:
                return None, None
                
        except requests.RequestException:
            return None, None

# ============== USERNAME GENERATOR ==============
class UsernameGenerator:
    """Generiert zufällige Usernamen mit bestimmter Länge"""
    
    @staticmethod
    def generate_username(length=4):
        """Generiert einen zufälligen Username mit bestimmter Länge"""
        letters = 'abcdefghijklmnopqrstuvwxyz'
        return ''.join(random.choices(letters, k=length))

# ============== WEBHOOK SENDER ==============
class WebhookSender:
    """Sendet gefundene User an Discord Webhook"""
    
    @staticmethod
    def send_to_webhook(webhook_url, username, user_data=None):
        """Sendet gefundenen User an Webhook"""
        if not webhook_url:
            return False
        
        try:
            embed = {
                "title": "🎯 Nitro Username Found!",
                "description": f"**Username:** `{username}`",
                "color": 0x0000FF,
                "timestamp": datetime.utcnow().isoformat(),
                "fields": [
                    {"name": "🔍 Found By", "value": "BND-TOOLS Nitro Scanner", "inline": True},
                    {"name": "📅 Date", "value": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "inline": True},
                    {"name": "📏 Length", "value": f"{len(username)} characters", "inline": True}
                ],
                "footer": {"text": "BND-TOOLS • Nitro Scanner", "icon_url": "https://cdn.discordapp.com/embed/avatars/0.png"}
            }
            
            if user_data:
                embed["fields"].append({"name": "📊 User Data", "value": f"```json\n{json.dumps(user_data, indent=2)[:500]}\n```", "inline": False})
            
            data = {
                "embeds": [embed],
                "content": f"@everyone 🎯 **Nitro Username gefunden:** `{username}`"
            }
            
            response = requests.post(webhook_url, json=data, timeout=10)
            return response.status_code == 204
            
        except requests.RequestException as e:
            console.print(f" [dim]Webhook send failed: {e}[/]")
            return False

# ============== NITRO SCANNER ==============
class NitroScanner:
    """Scanner sucht so lange bis ein Username gefunden wird"""
    
    def __init__(self, webhook_url=None):
        self.webhook_url = webhook_url
        self.found_users = []
        self.checked_count = 0
        self.validator = DiscordUserValidator()
        self.webhook_sender = WebhookSender()
        self.generator = UsernameGenerator()
    
    def scan_until_found(self, length=4, max_attempts=10000):
        """Scannt so lange bis ein Username gefunden wird"""
        
        console.print(f"\n[{CURRENT_HEX}]┌─[[/][bold white] Nitro Scanner [/][{CURRENT_HEX}]][/]")
        console.print(f" [{CURRENT_HEX}]│[/] Length: [bold white]{length} characters[/]")
        console.print(f" [{CURRENT_HEX}]│[/] Max Attempts: [bold white]{max_attempts}[/]")
        console.print(f" [{CURRENT_HEX}]│[/] Webhook: [bold white]{'✅ Enabled' if self.webhook_url else '❌ Disabled'}[/]")
        console.print(f" [{CURRENT_HEX}]└─▶[/] [dim]Searching...[/]\n")
        
        found = None
        
        with Progress(SpinnerColumn(style=CURRENT_HEX), TextColumn("[dim]{task.description}"), console=console) as p:
            task = p.add_task(f"Searching for {length}-letter username...", total=None)
            
            while self.checked_count < max_attempts:
                self.checked_count += 1
                
                # Generiere zufälligen Username
                username = self.generator.generate_username(length)
                
                # Prüfe ob User existiert
                result, user_data = self.validator.check_username(username)
                
                if result is True:
                    # USER GEFUNDEN!
                    found = user_data
                    found_username = user_data.get('username', username)
                    self.found_users.append(user_data)
                    
                    console.print(f"\n[{CURRENT_HEX}]✅[/] [bold white]FOUND:[/] {found_username}")
                    
                    # An Webhook senden
                    if self.webhook_url:
                        self.webhook_sender.send_to_webhook(self.webhook_url, found_username, user_data)
                    
                    break
                    
                elif result is False:
                    # User existiert nicht
                    if self.checked_count % 10 == 0:
                        console.print(f"[dim]❌ {username}[/]")
                    else:
                        console.print(f"[dim]❌ {username}[/]", end="\r")
                
                else:
                    # Error
                    console.print(f"[yellow]⚠️[/] [dim]{username} (error)[/]")
                
                p.update(task, advance=1)
        
        return found
    
    def get_stats(self):
        """Gibt Statistiken zurück"""
        return {
            "total_checked": self.checked_count,
            "found": len(self.found_users),
        }

# ============== MAIN ==============
if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]NITRO SCANNER[/]  [dim]//[/]  [{CURRENT_HEX}]USER SEARCH[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()
        
        # ===== WEBHOOK KONFIGURATION =====
        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Webhook [/][{CURRENT_HEX}]][/]")
        console.print(f" [{CURRENT_HEX}]│[/] [dim]Webhook URL (Enter zum Überspringen)[/]")
        webhook_input = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        
        webhook_url = webhook_input if webhook_input else None
        if webhook_url:
            console.print(f" [{CURRENT_HEX}]✅[/] [green]Webhook aktiv[/]")
        else:
            console.print(f" [{CURRENT_HEX}]ℹ️[/] [dim]Webhook deaktiviert[/]")
        
        console.print()
        
        # ===== BUCHSTABEN LÄNGE =====
        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Buchstaben [/][{CURRENT_HEX}]][/]")
        console.print(f" [{CURRENT_HEX}]│[/] [dim]Wie viele Buchstaben?[/]")
        console.print(f" [{CURRENT_HEX}]│[/]  [white]3[/]  [dim]Buchstaben[/]")
        console.print(f" [{CURRENT_HEX}]│[/]  [white]4[/]  [dim]Buchstaben[/]")
        console.print(f" [{CURRENT_HEX}]│[/]  [white]5[/]  [dim]Buchstaben[/]")
        console.print(f" [{CURRENT_HEX}]│[/]  [white]6[/]  [dim]Buchstaben[/]")
        
        length_input = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        
        try:
            username_length = int(length_input)
            if username_length < 3:
                username_length = 3
            elif username_length > 6:
                username_length = 6
        except (ValueError, EOFError):
            username_length = 4
            console.print(f" [{CURRENT_HEX}]ℹ️[/] [dim]Ungültig, verwende 4[/]")
        
        console.print(f" [{CURRENT_HEX}]✅[/] [green]Suche nach {username_length} Buchstaben[/]")
        console.print()
        
        # ===== MAX ATTEMPTS =====
        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Max Attempts [/][{CURRENT_HEX}]][/]")
        console.print(f" [{CURRENT_HEX}]│[/] [dim]Maximale Versuche (Enter = 1000)[/]")
        
        attempts_input = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        
        try:
            max_attempts = int(attempts_input)
            if max_attempts < 10:
                max_attempts = 10
            elif max_attempts > 50000:
                max_attempts = 50000
        except (ValueError, EOFError):
            max_attempts = 1000
            console.print(f" [{CURRENT_HEX}]ℹ️[/] [dim]Ungültig, verwende 1000[/]")
        
        console.print(f" [{CURRENT_HEX}]✅[/] [green]Max {max_attempts} Versuche[/]")
        console.print()
        
        # ===== SCANNEN =====
        scanner = NitroScanner(webhook_url=webhook_url)
        found_user = scanner.scan_until_found(length=username_length, max_attempts=max_attempts)
        
        # ===== ERGEBNISSE =====
        console.print()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]📊 ERGEBNISSE[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        
        stats = scanner.get_stats()
        
        stats_tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, show_header=False, padding=(0, 2))
        stats_tbl.add_column("", style=f"dim {CURRENT_HEX}", width=20)
        stats_tbl.add_column("", style="white")
        stats_tbl.add_row("Buchstaben", f"{username_length}")
        stats_tbl.add_row("Versuche", str(stats["total_checked"]))
        
        if found_user:
            stats_tbl.add_row("Gefunden", f"[bold green]{found_user.get('username', 'Unknown')}[/]")
            stats_tbl.add_row("User ID", found_user.get('id', 'Unknown'))
            if webhook_url:
                stats_tbl.add_row("Webhook", "✅ Gesendet")
        else:
            stats_tbl.add_row("Gefunden", "[red]❌ Kein User gefunden[/]")
        
        console.print(Align.center(stats_tbl))
        
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")
        
    except (KeyboardInterrupt, EOFError):
        console.print(f"\n[{CURRENT_HEX}][!] Abgebrochen.[/]")
        time.sleep(1)