import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, json
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

BASE_DIR = os.path.join(os.getcwd(), 'BND - Input', 'DATA-BASE')

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}L O C A L   B R E A C   D A T A B A S E   Q U E R Y{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // DATABASE SEARCH")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.1))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def perform_search(term):
    res = []
    f_count = 0
    if not os.path.exists(BASE_DIR): 
        return [], 0, "DATA-BASE folder not found."
    
    for root, _, files in os.walk(BASE_DIR):
        for f in files:
            f_count += 1
            path = os.path.join(root, f)
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as fh:
                    for i, line in enumerate(fh, 1):
                        if term.lower() in line.lower():
                            res.append({"f": f, "l": i, "c": line.strip()})
            except Exception:
                continue
    return res, f_count, None

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]DATABASE SEARCH[/]  [dim]//[/]  [{CURRENT_HEX}]OSINT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()

        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Search term [/][{CURRENT_HEX}]][/]")
        term = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        if not term: sys.exit(0)

        with Progress(SpinnerColumn(style=CURRENT_HEX), TextColumn("[dim]{task.description}"), console=console, transient=True) as p:
            p.add_task(f"Scanning archives for '{term}'...", total=None)
            results, count, error = perform_search(term)

        if error:
            console.print(f"\n [{CURRENT_HEX}][!]{RESET} [white]{error}[/]")
            time.sleep(2); sys.exit(0)

        os.system("cls" if os.name == "nt" else "clear")
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]SEARCH RESULTS[/]  [dim]//[/]  [{CURRENT_HEX}]CORE[/]"),
            border_style=CURRENT_HEX, padding=(0, 4)
        )))

        if not results:
            console.print(Align.center(f"\n [{CURRENT_HEX}][!]{RESET} [white]No results found for '{term}' in {count} files.[/]"))
        else:
            tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, header_style=f"bold {CURRENT_HEX}")
            tbl.add_column("FILE", style="dim white")
            tbl.add_column("LINE", justify="right", style=CURRENT_HEX)
            tbl.add_column("CONTENT", style="white")

            for r in results[:100]:
                # Highlight suchbegriff mit aktueller Farbe
                match_text = r['c'].replace(term, f"[{CURRENT_HEX}]{term}{RESET}")
                if term.lower() != term:
                    match_text = match_text.replace(term.lower(), f"[{CURRENT_HEX}]{term.lower()}{RESET}")
                    match_text = match_text.replace(term.capitalize(), f"[{CURRENT_HEX}]{term.capitalize()}{RESET}")
                tbl.add_row(r['f'], str(r['l']), match_text)
            
            console.print(Align.center(tbl))
            console.print(Align.center(f"\n [{CURRENT_HEX}][✓]{RESET} [white]{len(results)} matches found [/][dim]({count} files analyzed)[/]"))

        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

    except (KeyboardInterrupt, EOFError):
        pass