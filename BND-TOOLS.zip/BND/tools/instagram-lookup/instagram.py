#!/usr/bin/env python3
"""Instagram Profile Lookup - Retrieve public Instagram data"""

import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, threading, random, re
import subprocess
import webbrowser
import requests
from rich.console import Console, Group  # <-- Group kommt hier rein!
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box

console = Console()

# -- COLORS --
C_RED     = "#CC0000"
C_NEON    = "#FF2020"
C_WHITE   = "#FFFFFF"
C_SILVER  = "#CCCCCC"
C_DIM     = "#444444"
C_OK      = "#00FF00"
C_NO      = "#440000"
C_PINK    = "#FF69B4"
C_PURPLE  = "#9B00FF"

ASCII = r"""
   ██╗███╗   ██╗███████╗████████╗ █████╗  ██████╗ ██████╗  █████╗ ███╗   ███╗
   ██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██╔════╝ ██╔══██╗██╔══██╗████╗ ████║
   ██║██╔██╗ ██║███████╗   ██║   ███████║██║  ███╗██████╔╝███████║██╔████╔██║
   ██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║
   ██║██║ ╚████║███████║   ██║   ██║  ██║╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║
   ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝
"""

SUBTITLE = " I N S T A G R A M   P R O F I L E   L O O K U P   //   O S I N T "

def boot():
    if sys.platform.startswith("win"):
        os.system("title INSTAGRAM OSINT // PROFILE ANALYZER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(255 * abs(math.sin(t * 6 - c * 0.2)))))
                        sys.stdout.write(f"\033[38;2;{v};{int(v*0.3)};{int(v*0.5)}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  \033[38;2;255;105;180m{SUBTITLE}\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def make_layout():
    l = Layout()
    l.split_column(
        Layout(name="header", size=4),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    l["body"].split_row(
        Layout(name="results", ratio=2),
        Layout(name="stats", ratio=1)
    )
    return l

async def lookup_instagram(username, update_fn):
    """Lookup Instagram profile"""
    found_data = []
    
    try:
        update_fn(f"Checking username: @{username}", 25, 100)
        time.sleep(0.5)
        
        update_fn("Fetching profile data...", 50, 100)
        
        url = f"https://www.instagram.com/{username}/?__a=1"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if 'graphql' in data:
                    user_data = data['graphql']['user']
                    found_data = [{
                        'username': user_data.get('username', username),
                        'full_name': user_data.get('full_name', ''),
                        'bio': user_data.get('biography', ''),
                        'followers': user_data.get('edge_followed_by', {}).get('count', 0),
                        'following': user_data.get('edge_follow', {}).get('count', 0),
                        'posts': user_data.get('edge_owner_to_timeline_media', {}).get('count', 0),
                        'is_private': user_data.get('is_private', False),
                        'is_verified': user_data.get('is_verified', False),
                        'profile_pic': user_data.get('profile_pic_url_hd', '')
                    }]
                    update_fn("Profile found successfully!", 100, 100)
                else:
                    update_fn("Profile is private or not found", 100, 100)
            else:
                update_fn("Profile is private or not found", 100, 100)
        except Exception:
            update_fn("Profile is private or not found", 100, 100)
        
        update_fn("Opening profile in browser...", 100, 100)
        time.sleep(0.5)
        webbrowser.open(f"https://instagram.com/{username}")
        
    except Exception as e:
        update_fn(f"Error: {str(e)}", 100, 100)
    
    return found_data

def main():
    boot()
    
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {C_PINK}]INSTAGRAM OSINT[/]  [dim]//[/]  [white]PROFILE ANALYZER[/]  [dim]//[/]  [{C_PINK}]INTELLIGENCE[/]"),
        border_style="#FF69B4", padding=(0, 6)
    )))
    console.print()
    
    console.print(f" [{C_PINK}]●[/] [white]Instagram Profile Lookup[/]")
    console.print(f" [{C_PINK}]●[/] [white]Enter username (with or without @)[/]")
    console.print()
    
    username = console.input(f" [{C_PINK}]└─▶[/] [bold white]Enter Username >> ").strip()
    
    username = username.lstrip('@')
    
    if not username:
        console.print(f"\n [{C_RED}][x][/] No username provided.")
        time.sleep(2)
        return

    layout = make_layout()
    found_data = []
    current_status = "Initializing..."
    progress_val = 0
    start_time = time.time()

    def update_view(status, progress, total):
        nonlocal current_status, progress_val
        current_status = status
        progress_val = progress

    async def scan_thread():
        nonlocal found_data
        found_data = await lookup_instagram(username, update_view)

    loop_thread = threading.Thread(target=lambda: asyncio.run(scan_thread()), daemon=True)
    loop_thread.start()

    with Live(layout, refresh_per_second=10, screen=True) as live:
        while loop_thread.is_alive():
            layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {C_PINK}]PROFILE SCANNER[/] [dim]||[/] [white]ANALYZING...[/]")), border_style="#FF69B4"))
            
            res_table = Table(box=box.SIMPLE, expand=True, show_header=True, header_style=f"bold {C_PINK}")
            res_table.add_column("PROFILE DATA", ratio=2)
            res_table.add_column("VALUE", ratio=1, justify="center")
            
            if found_data:
                data = found_data[0]
                res_table.add_row("Username", f"[bold {C_OK}]@{data['username']}[/]")
                res_table.add_row("Full Name", data['full_name'] if data['full_name'] else "Not set")
                res_table.add_row("Bio", data['bio'][:30] + "..." if len(data['bio']) > 30 else data['bio'])
                res_table.add_row("Followers", f"{data['followers']:,}")
                res_table.add_row("Following", f"{data['following']:,}")
                res_table.add_row("Posts", f"{data['posts']:,}")
                res_table.add_row("Status", "🔒 Private" if data['is_private'] else "🌐 Public")
                res_table.add_row("Verified", "✅ Yes" if data['is_verified'] else "❌ No")
            else:
                res_table.add_row("Status", f"[bold {C_RED}]Profile not found or private[/]")
                res_table.add_row("Tip", "Try checking the Instagram app")
            
            layout["results"].update(Panel(res_table, title="[bold white]PROFILE INFORMATION", border_style="#FF69B4"))
            
            elapsed = time.time() - start_time
            stats_grp = Group(
                Text.from_markup(f"\n[{C_PINK}]USERNAME:[/] [white]@{username}"),
                Text.from_markup(f"[{C_PINK}]STATUS  :[/] [white]{current_status}"),
                Text.from_markup(f"[{C_PINK}]FOUND   :[/] [bold green]{len(found_data)}[/] records"),
                Text.from_markup(f"[{C_PINK}]ELAPSED :[/] [white]{int(elapsed)}s"),
                Text.from_markup(f"\n[{C_PINK}][bold]PROGRESS :[/] [white]{progress_val}%"),
            )
            layout["stats"].update(Panel(stats_grp, title="[bold white]LIVE STATS", border_style="#FF69B4"))
            
            layout["footer"].update(Panel(Align.center(Text.from_markup(f"[dim]INSTAGRAM OSINT SYSTEM - SECURE ANALYSIS[/]")), border_style="#FF69B4"))
            time.sleep(0.1)

    os.system("cls")
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold green]ANALYSIS COMPLETED FOR @{username}"),
        border_style="green", box=box.HEAVY, padding=(1, 5)
    )))
    
    if found_data:
        data = found_data[0]
        table = Table(title=f"[bold white]@{username} - PROFILE REPORT", box=box.ROUNDED, border_style="green", expand=True)
        table.add_column("Property", style="white")
        table.add_column("Value", style="green", justify="center")
        table.add_row("Username", f"@{data['username']}")
        table.add_row("Full Name", data['full_name'] if data['full_name'] else "Not set")
        table.add_row("Bio", data['bio'] if data['bio'] else "No bio")
        table.add_row("Followers", f"{data['followers']:,}")
        table.add_row("Following", f"{data['following']:,}")
        table.add_row("Posts", f"{data['posts']:,}")
        table.add_row("Privacy", "🔒 Private" if data['is_private'] else "🌐 Public")
        table.add_row("Verified", "✅ Yes" if data['is_verified'] else "❌ No")
        console.print(table)
        
        console.print(f"\n [{C_OK}]●[/] Profile opened in browser!")
    else:
        console.print(f"\n [{C_RED}][!][/] Could not retrieve profile data.")
        console.print(f" [{C_RED}]●[/] The profile might be private or doesn't exist.")
        console.print(f" [{C_RED}]●[/] Try checking manually: https://instagram.com/{username}")

    console.input(f"\n [dim]Press [bold {C_PINK}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit()