import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, json, requests, hashlib, re
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // USER LOOKUP")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== DATA BREACH FUNCTIONS ==============

def search_breachdirectory(email_or_username):
    """Sucht in BreachDirectory nach Daten"""
    try:
        url = f"https://breachdirectory.p.rapidapi.com/?query={email_or_username}"
        headers = {
            "X-RapidAPI-Key": "dein-api-key",  # User muss eigenen Key eintragen
            "X-RapidAPI-Host": "breachdirectory.p.rapidapi.com"
        }
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if data.get("success") and data.get("result"):
                return data.get("result", [])
    except requests.RequestException as e:
        console.print(f" [dim]BreachDirectory lookup failed: {e}[/]")
    return []

def search_leakcheck(email_or_username):
    """Suchte auf LeakCheck"""
    try:
        url = f"https://leakcheck.io/api/public?check={email_or_username}"
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if data.get("found", False):
                return data.get("result", [])
    except requests.RequestException as e:
        console.print(f" [dim]LeakCheck lookup failed: {e}[/]")
    return []

def search_scylla(email_or_username):
    """Sucht in Scylla Database"""
    try:
        url = f"https://scylla.so/api/search?q={email_or_username}"
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if data.get("results"):
                return data.get("results", [])
    except requests.RequestException as e:
        console.print(f" [dim]Scylla lookup failed: {e}[/]")
    return []

def check_email_breaches(email):
    """Checkt Email auf Breaches über haveibeenpwned"""
    breaches = []
    try:
        url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
        headers = {"hibp-api-key": "dein-api-key"}  # Optional
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            breaches = r.json()
        elif r.status_code == 404:
            breaches = []
    except requests.RequestException as e:
        console.print(f" [dim]HIBP lookup failed: {e}[/]")
    return breaches

def search_username_osint(username):
    """Sucht Username auf verschiedenen Plattformen"""
    platforms = {
        "GitHub": f"https://github.com/{username}",
        "Twitter": f"https://twitter.com/{username}",
        "Instagram": f"https://www.instagram.com/{username}",
        "Reddit": f"https://www.reddit.com/user/{username}",
        "YouTube": f"https://www.youtube.com/@{username}",
        "TikTok": f"https://www.tiktok.com/@{username}",
        "Snapchat": f"https://www.snapchat.com/add/{username}",
        "Spotify": f"https://open.spotify.com/user/{username}",
        "Pinterest": f"https://www.pinterest.com/{username}",
        "Twitch": f"https://www.twitch.tv/{username}",
        "Steam": f"https://steamcommunity.com/id/{username}",
        "PlayStation": f"https://psnprofiles.com/{username}",
        "Xbox": f"https://xboxgamertag.com/search/{username}",
        "Discord": f"https://discord.com/users/{username}"
    }
    
    found = []
    for platform, url in platforms.items():
        try:
            r = requests.get(url, timeout=5, allow_redirects=False)
            if r.status_code == 200:
                found.append({"platform": platform, "url": url, "status": "Active"})
            elif r.status_code == 302 or r.status_code == 301:
                found.append({"platform": platform, "url": url, "status": "Redirect"})
        except requests.RequestException:
            pass
    
    return found

def check_pastebin(email):
    """Sucht Email in Pastebin"""
    results = []
    try:
        url = f"https://psbdmp.ws/api/v3/search?q={email}"
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            data = r.json()
            if data.get("data"):
                for paste in data.get("data", [])[:10]:
                    results.append({
                        "title": paste.get("title", "Unknown"),
                        "date": paste.get("date", "Unknown"),
                        "url": f"https://psbdmp.ws/p/{paste.get('id', '')}"
                    })
    except requests.RequestException as e:
        console.print(f" [dim]Pastebin search failed: {e}[/]")
    return results

# ============== DISCORD USER INFO (Public) ==============

def get_discord_user(user_id):
    """Holt öffentliche Discord User Info"""
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    try:
        url = f"https://discord.com/api/v9/users/{user_id}"
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json()
        return None
    except requests.RequestException as e:
        console.print(f" [dim]Discord API error: {e}[/]")
        return None

def get_discord_user_by_name(username, discriminator="0000"):
    """Sucht Discord User via Username#Tag"""
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    try:
        url = f"https://discord.com/api/v9/users/{username}/{discriminator}"
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json()
        return None
    except requests.RequestException as e:
        console.print(f" [dim]Discord API error: {e}[/]")
        return None

# ============== MAIN LOOKUP FUNCTION ==============

def lookup_user(query):
    """Hauptfunktion für User Lookup ohne Token"""
    result = {
        "found": False,
        "discord": None,
        "breaches": [],
        "platforms": [],
        "pastebin": [],
        "email": None,
        "username": query
    }
    
    # Prüfe ob es eine Email ist
    is_email = re.match(r"[^@]+@[^@]+\.[^@]+", query)
    
    # Extrahiere Username aus Email
    username = query
    if is_email:
        username = query.split('@')[0]
        result["email"] = query
    
    # 1. Discord User Info (öffentlich)
    if query.isdigit():
        discord_user = get_discord_user(query)
    else:
        # Versuche Username#Tag Format
        if "#" in query:
            parts = query.split("#")
            if len(parts) == 2:
                discord_user = get_discord_user_by_name(parts[0], parts[1])
            else:
                discord_user = None
        else:
            # Versuche als User ID zu interpretieren
            discord_user = get_discord_user(query) if query.isdigit() else None
    
    if discord_user:
        result["found"] = True
        result["discord"] = discord_user
    
    # 2. Breach Data (nur bei Email)
    if is_email:
        try:
            # Have I Been Pwned
            breaches = check_email_breaches(query)
            if breaches:
                result["breaches"].extend(breaches)
        except requests.RequestException as e:
            console.print(f" [dim]Breach check failed: {e}[/]")
    
    # 3. Plattformen suchen
    platforms = search_username_osint(username)
    if platforms:
        result["platforms"] = platforms
    
    # 4. Pastebin suchen
    if is_email:
        pastes = check_pastebin(query)
        if pastes:
            result["pastebin"] = pastes
    
    return result

# ============== MAIN ==============

def main():
    boot()
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]//[/] [white]USER INTELLIGENCE[/]"),
        border_style=CURRENT_HEX, padding=(0, 6)
    )))
    console.print()
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Username / Email / Discord ID [/][bold {CURRENT_HEX}]][/]")
    query = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    
    if not query:
        console.print("\n [red]No input provided![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    console.print(f"\n [dim]Searching intelligence on: [white]{query}[/]...[/]\n")
    
    result = lookup_user(query)
    
    # 1. Discord User Info
    if result["discord"]:
        user = result["discord"]
        
        table = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, show_header=False, expand=True)
        table.add_column("Key", style=f"dim {CURRENT_HEX}", width=20)
        table.add_column("Value", style="white")
        
        username = user.get("username", "Unknown")
        discriminator = user.get("discriminator", "0000")
        
        table.add_row("Discord ID", user.get("id", "—"))
        table.add_row("Username", f"{username}#{discriminator}")
        table.add_row("Global Name", user.get("global_name", "—") or "[dim]Not set[/]")
        
        # Account Created
        created_at = user.get("id")
        if created_at:
            timestamp = (int(created_at) >> 22) + 1420070400000
            created_date = datetime.fromtimestamp(timestamp/1000).strftime("%Y-%m-%d %H:%M:%S")
            table.add_row("Account Created", created_date)
        
        # Badges
        flags = user.get("public_flags", 0)
        badges = []
        badge_map = {
            1: "Staff", 2: "Partner", 4: "HypeSquad Events",
            8: "Bug Hunter", 64: "HypeSquad Bravery", 128: "HypeSquad Brilliance",
            256: "HypeSquad Balance", 512: "Early Supporter", 1024: "Team User",
            4096: "Bug Hunter Level 2", 16384: "Verified Bot", 65536: "Verified Developer",
            131072: "Certified Moderator"
        }
        for flag, name in badge_map.items():
            if flags & flag:
                badges.append(name)
        
        if badges:
            table.add_row("Badges", "\n".join(badges))
        
        # Avatar
        avatar = user.get("avatar")
        if avatar:
            avatar_url = f"https://cdn.discordapp.com/avatars/{user['id']}/{avatar}.png"
            table.add_row("Avatar", avatar_url)
        
        console.print(Align.center(Panel(table, title=f"[bold {CURRENT_HEX}]* Discord Profile[/]", border_style=CURRENT_HEX)))
    else:
        console.print(Align.center(Panel(
            f"[bold yellow]⚠ Discord User Not Found[/]",
            border_style="yellow"
        )))
    
    # 2. Breaches
    if result["breaches"]:
        breach_table = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style="red", expand=True)
        breach_table.add_column("Breach", style="white")
        breach_table.add_column("Date", style="dim")
        breach_table.add_column("Data Classes", style="dim")
        
        for breach in result["breaches"]:
            breach_table.add_row(
                breach.get("Name", "Unknown"),
                breach.get("BreachDate", "Unknown"),
                "\n".join(breach.get("DataClasses", [])[:3]) if breach.get("DataClasses") else "—"
            )
        
        console.print(Align.center(Panel(
            breach_table,
            title=f"[bold red]* Data Breaches Found ({len(result['breaches'])})[/]",
            border_style="red"
        )))
    else:
        if result.get("email"):
            console.print(Align.center(Panel(
                "[bold green]✓ No data breaches found for this email[/]",
                border_style="green"
            )))
    
    # 3. Platforms
    if result["platforms"]:
        platform_table = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, expand=True)
        platform_table.add_column("Platform", style=f"{CURRENT_HEX}")
        platform_table.add_column("URL", style="white")
        platform_table.add_column("Status", style="dim")
        
        for p in result["platforms"]:
            platform_table.add_row(p["platform"], p["url"], p["status"])
        
        console.print(Align.center(Panel(
            platform_table,
            title=f"[bold {CURRENT_HEX}]* Found Profiles ({len(result['platforms'])})[/]",
            border_style=CURRENT_HEX
        )))
    
    # 4. Pastebin
    if result["pastebin"]:
        paste_table = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style="yellow", expand=True)
        paste_table.add_column("Title", style="white")
        paste_table.add_column("Date", style="dim")
        paste_table.add_column("URL", style="dim")
        
        for paste in result["pastebin"]:
            paste_table.add_row(paste["title"], paste["date"], paste["url"])
        
        console.print(Align.center(Panel(
            paste_table,
            title=f"[bold yellow]* Pastebin Results ({len(result['pastebin'])})[/]",
            border_style="yellow"
        )))
    
    # 5. Summary
    total = 0
    if result["discord"]: total += 1
    total += len(result["breaches"])
    total += len(result["platforms"])
    total += len(result["pastebin"])
    
    console.print(Align.center(Panel(
        Text.from_markup(f"""[bold {CURRENT_HEX}]═══════════════════════════════════════════
[white]Query: {query}
[CURRENT_HEX]Discord: [white]{'Found' if result['discord'] else 'Not Found'}
[CURRENT_HEX]Breaches: [white]{len(result['breaches'])}
[CURRENT_HEX]Platforms: [white]{len(result['platforms'])}
[CURRENT_HEX]Pastebin: [white]{len(result['pastebin'])}
[CURRENT_HEX]Total Hits: [white]{total}
[CURRENT_HEX]═══════════════════════════════════════════
[dim]BND-TOOLS // USER INTELLIGENCE"""),
        border_style=CURRENT_HEX
    )))
    
    console.print()
    console.input(" [dim]Press [bold red]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    main()