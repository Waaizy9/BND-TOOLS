import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, json, requests
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // TOKEN CHECKER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def check_token(token):
    """Überprüft einen Discord Token"""
    headers = {
        "Authorization": token,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    
    try:
        r = requests.get("https://discord.com/api/v9/users/@me", headers=headers, timeout=10)
        
        if r.status_code == 200:
            data = r.json()
            user_id = data.get("id", "Unknown")
            username = data.get("username", "Unknown")
            discriminator = data.get("discriminator", "0000")
            email = data.get("email", "No email")
            phone = data.get("phone", "No phone")
            verified = data.get("verified", False)
            mfa_enabled = data.get("mfa_enabled", False)
            
            # Prüfe Nitro
            nitro = False
            try:
                nr = requests.get("https://discord.com/api/v9/users/@me/billing/subscriptions", headers=headers, timeout=5)
                if nr.status_code == 200:
                    subs = nr.json()
                    nitro = len(subs) > 0
            except (requests.RequestException, ValueError):
                pass
            
            return {
                "valid": True,
                "user_id": user_id,
                "username": username,
                "discriminator": discriminator,
                "email": email,
                "phone": phone,
                "verified": verified,
                "mfa_enabled": mfa_enabled,
                "nitro": nitro
            }
        elif r.status_code == 401:
            return {"valid": False, "error": "Invalid Token"}
        else:
            return {"valid": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"valid": False, "error": str(e)}

def main():
    boot()
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]//[/] [white]DISCORD TOKEN CHECKER[/]"),
        border_style=CURRENT_HEX, padding=(0, 6)
    )))
    console.print()
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Discord Token [/][bold {CURRENT_HEX}]][/]")
    token = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    
    if not token:
        console.print("\n [red]No token provided![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    console.print(f"\n [dim]Checking token...[/]\n")
    
    result = check_token(token)
    
    if result.get("valid"):
        table = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, show_header=False, expand=True)
        table.add_column("Key", style=f"dim {CURRENT_HEX}", width=20)
        table.add_column("Value", style="white")
        
        table.add_row("Status", "[bold green]✓ VALID[/]")
        table.add_row("User ID", result.get("user_id", "—"))
        table.add_row("Username", f"{result.get('username', '—')}#{result.get('discriminator', '0000')}")
        table.add_row("Email", result.get("email", "—") or "[dim]Not provided[/]")
        table.add_row("Phone", result.get("phone", "—") or "[dim]Not provided[/]")
        table.add_row("Verified", "[bold green]✓ Yes[/]" if result.get("verified") else "[bold red]✗ No[/]")
        table.add_row("MFA Enabled", "[bold green]✓ Yes[/]" if result.get("mfa_enabled") else "[bold red]✗ No[/]")
        table.add_row("Nitro", "[bold yellow]⭐ Yes[/]" if result.get("nitro") else "[dim]No[/]")
        
        console.print(Align.center(Panel(table, title=f"[bold {CURRENT_HEX}]* Token Info[/]", border_style=CURRENT_HEX)))
    else:
        console.print(Align.center(Panel(
            f"[bold red]✗ INVALID TOKEN[/]\n\n[white]Error: {result.get('error', 'Unknown')}",
            border_style="red"
        )))
    
    console.print()
    console.input(" [dim]Press [bold red]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    main()