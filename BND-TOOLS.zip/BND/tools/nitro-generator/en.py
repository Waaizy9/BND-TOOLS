import random
import string
import json
import requests
import os
import sys
import time
from colorama import Fore, init

init(autoreset=True)

# BND-GEN Banner in Blau
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
DIM = "\033[90m"
RESET = "\033[0m"

BANNER = f"""
{BLUE}
  ██████╗ ███╗   ██╗██████╗     ██████╗ ███████╗███╗   ██╗
  ██╔══██╗████╗  ██║██╔══██╗    ██╔════╝ ██╔════╝████╗  ██║
  ██████╔╝██╔██╗ ██║██║  ██║    ██║  ███╗█████╗  ██╔██╗ ██║
  ██╔══██╗██║╚██╗██║██║  ██║    ██║   ██║██╔══╝  ██║╚██╗██║
  ██████╔╝██║ ╚████║██████╔╝    ╚██████╔╝███████╗██║ ╚████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝      ╚═════╝ ╚══════╝╚═╝  ╚═══╝
{RESET}
{WHITE} v1.0  |  by BND-Team{BLUE}                                                                             discord.gg/bnd{RESET}
{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}
"""

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear()
    print(BANNER)
    print()

def error_message(error):
    """Display an error message."""
    print(f"{RED}[!] Error: {error}{RESET}")

def verify_webhook(url):
    """Verify if the webhook is valid and send a test message."""
    try:
        response = requests.get(url)
        if response.status_code == 200:
            payload = {
                'content': f"""# BND-Nitro-Gen

> __**Your webhook is working! You can start generating nitro!**__

> https://discord.gg/bnd

> https://github.com/waaizy9/BND-TOOLS

> __Star for more features <3__

||@everyone||"""
            }
            headers = {
                'Content-Type': 'application/json'
            }
            requests.post(url, data=json.dumps(payload), headers=headers)
            return True
        else:
            error_message("Invalid Webhook URL")
            return False
    except requests.exceptions.RequestException as e:
        error_message(f"Error verifying webhook: {e}")
        return False

def send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar):
    """Send a notification to the webhook."""
    payload = {
        'embeds': [embed_content],
        'username': webhook_username,
        'avatar_url': webhook_avatar
    }

    headers = {
        'Content-Type': 'application/json'
    }

    try:
        requests.post(webhook_url, data=json.dumps(payload), headers=headers)
    except requests.exceptions.RequestException as e:
        error_message(f"Error sending to webhook: {e}")

def verify_nitro_code(webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Verify if a Discord Nitro code is valid."""
    code_nitro = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(16))
    url_nitro = f'https://discord.gift/{code_nitro}'
    try:
        response = requests.get(f'https://discord.com/api/v9/entitlements/gift-codes/{code_nitro}?with_application=false&with_subscription_plan=true', timeout=5)
        if response.status_code == 200:
            embed_content = {
                'title': 'Valid Nitro!',
                'description': f"**__Nitro:__**\n```{url_nitro}```",
                'color': webhook_color,
                'footer': {
                    "text": webhook_username,
                    "icon_url": webhook_avatar,
                }
            }
            if webhook:
                send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar)
            print(f"{GREEN}[+] Valid | Nitro: {url_nitro}{RESET}")
            return True
        else:
            print(f"{RED}[-] Invalid | Nitro: {url_nitro}{RESET}")
            return False
    except requests.exceptions.ReadTimeout:
        error_message("Request timeout expired")
    except requests.exceptions.RequestException as e:
        error_message(f"Error verifying Nitro code: {e}")
    return False

def generate_nitros(num_nitros, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Generate and verify the specified number of Nitro codes."""
    valid_codes = []
    invalid_codes = []
    
    print(f"\n{BLUE}[>] Starting Nitro Generator...{RESET}")
    print(f"{DIM}Generating {num_nitros} codes...{RESET}\n")
    
    for i in range(num_nitros):
        code_nitro = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(16))
        url_nitro = f'https://discord.gift/{code_nitro}'
        
        try:
            response = requests.get(f'https://discord.com/api/v9/entitlements/gift-codes/{code_nitro}?with_application=false&with_subscription_plan=true', timeout=5)
            if response.status_code == 200:
                valid_codes.append(url_nitro)
                print(f"{GREEN}[{i+1}/{num_nitros}] ✓ VALID | {url_nitro}{RESET}")
                
                if webhook:
                    embed_content = {
                        'title': 'Valid Nitro!',
                        'description': f"**__Nitro:__**\n```{url_nitro}```",
                        'color': webhook_color,
                        'footer': {"text": webhook_username, "icon_url": webhook_avatar},
                    }
                    send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar)
            else:
                invalid_codes.append(url_nitro)
                print(f"{RED}[{i+1}/{num_nitros}] ✗ INVALID | {url_nitro}{RESET}")
        except (ValueError, EOFError):
            invalid_codes.append(url_nitro)
            print(f"{RED}[{i+1}/{num_nitros}] ✗ ERROR | {url_nitro}{RESET}")
        
        if i < num_nitros - 1:
            time.sleep(0.5)  # Protection against rate-limits
    
    # Summary
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}┌──{BLUE} GENERATION SUMMARY{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Total generated:{RESET} {CYAN}{num_nitros}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Valid codes:{RESET} {GREEN}{len(valid_codes)}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Invalid codes:{RESET} {RED}{len(invalid_codes)}{RESET}")
    print(f"{BLUE}└──{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    
    # Save valid codes
    if valid_codes:
        save = input(f"\n{BLUE}[?]{RESET} {WHITE}Save valid codes to file? (y/n): {RESET}").strip().lower()
        if save in ('y', 'yes'):
            out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "BND - Output")
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            out_file = os.path.join(out_dir, "nitro_valid.txt")
            with open(out_file, "w", encoding="utf-8") as f:
                for code in valid_codes:
                    f.write(code + "\n")
            print(f"{GREEN}[+] Saved to: {out_file}{RESET}")

def main():
    print_header()
    
    print(f"{BLUE}┌──{BLUE} NITRO GENERATOR{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}└──{RESET} {WHITE}Discord Nitro Code Generator{RESET}")
    print()
    
    try:
        use_webhook = input(f"{BLUE}[?]{RESET} {WHITE}Use a Webhook? (y/n): {RESET}").strip().lower() in ['y', 'yes']
        
        if use_webhook:
            webhook_url = input(f"{BLUE}[?]{RESET} {WHITE}Webhook URL: {RESET}").strip()
            if not verify_webhook(webhook_url):
                input(f"\n{WHITE}Press Enter to continue...{RESET}")
                return
            webhook_username = "BND-Nitro-Gen"
            webhook_avatar = "https://cdn.discordapp.com/embed/avatars/0.png"
            webhook_color = 0x0000CD  # Blau
        else:
            webhook_url = webhook_username = webhook_avatar = webhook_color = None

        num_nitros = int(input(f"{BLUE}[?]{RESET} {WHITE}How many Nitro codes to generate?: {RESET}").strip())
        num_nitros = max(1, min(num_nitros, 100))  # Max 100 codes

    except Exception as e:
        error_message(e)
        input(f"\n{WHITE}Press Enter to continue...{RESET}")
        return

    try:
        generate_nitros(num_nitros, use_webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
    except Exception as e:
        error_message(e)
    
    print()
    input(f"{WHITE}Press Enter to exit...{RESET}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Aborted!{RESET}")
        input("\nPress Enter to exit...")