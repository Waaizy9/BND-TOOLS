import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, socket, ssl, json, asyncio, aiohttp

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // DOMAIN INTEL // OSINT CORE")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def get_dns_info(domain):
    data = {}
    try:
        data["IP Access (A)"] = socket.gethostbyname(domain)
    except Exception:
        data["IP Access (A)"] = "Not Found"
    return data

async def get_headers(domain):
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"http://{domain}", timeout=5) as r:
                return dict(r.headers)
    except (aiohttp.ClientError, asyncio.TimeoutError):
        return None

def main():
    boot()
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]DOMAIN INTELLIGENCE V2[/]"), border_style=CURRENT_HEX, padding=(0, 5))))
    console.print()
    
    domain = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Domain (ex: domain.com) >> ").strip().lower().replace("https://","").replace("http://","").split("/")[0]
    if not domain: return

    os.system("cls" if os.name == "nt" else "clear")
    with Progress(SpinnerColumn(style=CURRENT_HEX), TextColumn(f"[bold {CURRENT_HEX}]INTERROGATING DNS SERVERS..."), console=console, transient=True) as p:
        p.add_task("", total=None)
        dns = get_dns_info(domain)
        time.sleep(0.8)
        p.columns[1].text = f"[bold {CURRENT_HEX}]CAPTURING HTTP HEADERS..."
        headers = asyncio.run(get_headers(domain))
        time.sleep(0.8)

    layout = Layout()
    layout.split_column(Layout(name="header", size=4), Layout(name="body", ratio=1))
    layout["body"].split_row(Layout(name="left"), Layout(name="right"))

    layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {CURRENT_HEX}]INTELLIGENCE REPORT : [white]{domain}")), border_style=CURRENT_HEX))
    
    dns_table = Table(title="[bold white]DNS & NETWORK RECORDS", box=box.SIMPLE, expand=True)
    dns_table.add_column("DNS TAG", style=CURRENT_HEX)
    dns_table.add_column("INTEL VALUE", style="white")
    for k, v in dns.items(): 
        dns_table.add_row(k, v)
    layout["left"].update(Panel(dns_table, border_style=CURRENT_HEX))

    head_table = Table(title="[bold white]CORE HTTP HEADERS", box=box.SIMPLE, expand=True)
    head_table.add_column("RESPONSE TAG", style=CURRENT_HEX)
    head_table.add_column("VALUE DETECTED", style="white", overflow="fold")
    if headers:
        for k in ["Server", "Content-Type", "Strict-Transport-Security", "X-Frame-Options", "X-Powered-By"]:
            if k in headers: 
                head_table.add_row(k, headers[k])
    else:
        head_table.add_row("Status", "Remote Host Unreachable")
    
    layout["right"].update(Panel(head_table, border_style=CURRENT_HEX))

    console.print(layout)
    console.print(f"\n [{CURRENT_HEX}][!]{RESET} [white]Intelligence collection finished. Check OSINT Framework for deep WHOIS.[/]")
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit()