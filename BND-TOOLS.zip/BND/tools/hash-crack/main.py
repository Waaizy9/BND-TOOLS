import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, hashlib, json, threading, itertools, string

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.rule import Rule

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except (json.JSONDecodeError, OSError):
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // HASH CRACK")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== HASH FUNCTIONS ==============
def detect_hash_type(hash_string):
    hash_string = hash_string.strip()
    length = len(hash_string)
    
    if length == 32:
        return "MD5"
    elif length == 40:
        return "SHA1"
    elif length == 64:
        return "SHA256"
    elif length == 128:
        return "SHA512"
    elif length == 96:
        return "SHA384"
    elif length == 56:
        return "SHA224"
    elif length == 60 and hash_string.startswith("$2y$"):
        return "BCRYPT"
    elif length == 32 and hash_string.startswith("$1$"):
        return "MD5CRYPT"
    else:
        return "UNKNOWN"

def hash_word(word, hash_type):
    word = word.strip()
    if hash_type == "MD5":
        return hashlib.md5(word.encode()).hexdigest()
    elif hash_type == "SHA1":
        return hashlib.sha1(word.encode()).hexdigest()
    elif hash_type == "SHA256":
        return hashlib.sha256(word.encode()).hexdigest()
    elif hash_type == "SHA512":
        return hashlib.sha512(word.encode()).hexdigest()
    elif hash_type == "SHA384":
        return hashlib.sha384(word.encode()).hexdigest()
    elif hash_type == "SHA224":
        return hashlib.sha224(word.encode()).hexdigest()
    else:
        return None

def crack_hash(target_hash, wordlist, hash_type):
    target_hash = target_hash.strip().lower()
    cracked = None
    total = len(wordlist)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console
    ) as progress:
        task = progress.add_task("[yellow]Cracking hash...", total=total)
        
        for i, word in enumerate(wordlist):
            word = word.strip()
            if word:
                if hash_word(word, hash_type) == target_hash:
                    cracked = word
                    progress.update(task, completed=total)
                    break
                if i % 100 == 0:
                    progress.update(task, advance=100)
        progress.update(task, completed=total)
    
    return cracked

def load_wordlist(file_path):
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return [line.strip() for line in f if line.strip()]
        return None
    except Exception:
        return None

def generate_wordlist_file():
    default_words = [
        "password", "123456", "123456789", "qwerty", "abc123", "admin",
        "letmein", "welcome", "monkey", "dragon", "master", "sunshine",
        "princess", "shadow", "superman", "hello", "fuckyou", "hacker",
        "bnd", "tools", "discord", "nitro", "1234", "12345", "1234567",
        "12345678", "1234567890", "password1", "password123", "qwerty123",
        "admin123", "letmein123", "welcome123", "monkey123", "dragon123",
        "qwertyuiop", "asdfghjkl", "zxcvbnm", "iloveyou", "123123",
        "adminadmin", "password!", "P@ssw0rd", "Passw0rd", "qwerty12345"
    ]
    
    wordlist_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wordlist.txt")
    with open(wordlist_path, 'w') as f:
        for word in default_words:
            f.write(word + "\n")
    return wordlist_path

# ============== MAIN MENU ==============
def main_menu():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]HASH CRACK[/]"), border_style=CURRENT_HEX, padding=(0, 5))))
    console.print()
    
    menu_text = f"""
[bold {CURRENT_HEX}]┌────────────────────────────────────────────┐
│  [white]01[/] [white]▶[/] Crack Single Hash                 │
│  [white]02[/] [white]▶[/] Crack Hash from File              │
│  [white]03[/] [white]▶[/] Detect Hash Type                  │
│  [white]04[/] [white]▶[/] Generate Hash from Word           │
│  [white]05[/] [white]▶[/] Generate Wordlist                 │
│  [white]06[/] [white]▶[/] Brute Force (Dictionary)          │
│  [white]99[/] [white]▶[/] Exit                               │
└────────────────────────────────────────────┘
"""
    
    menu = Panel(Text.from_markup(menu_text), border_style=CURRENT_HEX, padding=(0, 2))
    console.print(Align.center(menu))
    console.print()
    return console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Select option >> ").strip()

# ============== CRACK SINGLE ==============
def crack_single():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]CRACK SINGLE HASH[/]"), border_style=CURRENT_HEX)))
    
    target_hash = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Hash to crack >> ").strip()
    if not target_hash:
        console.print(" [bold red]Hash required![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    hash_type = detect_hash_type(target_hash)
    console.print(f" [dim]Detected: [bold]{hash_type}[/]")
    
    if hash_type == "UNKNOWN":
        console.print(" [bold yellow]Warning: Unknown hash type![/]")
        hash_type = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Enter hash type (MD5/SHA1/SHA256/SHA512) >> ").strip().upper()
        if hash_type not in ["MD5", "SHA1", "SHA256", "SHA512", "SHA384", "SHA224"]:
            console.print(" [bold red]Invalid hash type![/]")
            console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
            return
    
    wordlist_file = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Wordlist file (enter for default) >> ").strip()
    if not wordlist_file or not os.path.exists(wordlist_file):
        wordlist_file = generate_wordlist_file()
        console.print(f" [dim]Using default wordlist: {wordlist_file}[/]")
    
    wordlist = load_wordlist(wordlist_file)
    if not wordlist:
        console.print(" [bold red]Wordlist empty or not found![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    console.print(f"\n [bold yellow]Cracking hash...[/]")
    console.print(f" [dim]Words in wordlist: {len(wordlist)}[/]")
    
    result = crack_hash(target_hash, wordlist, hash_type)
    
    if result:
        console.print(f"\n [bold green]✓ CRACKED![/]")
        console.print(f" [bold green]Hash: {target_hash}[/]")
        console.print(f" [bold green]Type: {hash_type}[/]")
        console.print(f" [bold green]Word: {result}[/]")
    else:
        console.print(f"\n [bold red]✗ Not found in wordlist![/]")
    
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== CRACK FROM FILE ==============
def crack_from_file():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]CRACK HASH FROM FILE[/]"), border_style=CURRENT_HEX)))
    
    hash_file = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Hash file (one hash per line) >> ").strip()
    if not hash_file or not os.path.exists(hash_file):
        console.print(" [bold red]File not found![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    wordlist_file = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Wordlist file >> ").strip()
    if not wordlist_file or not os.path.exists(wordlist_file):
        wordlist_file = generate_wordlist_file()
        console.print(f" [dim]Using default wordlist: {wordlist_file}[/]")
    
    wordlist = load_wordlist(wordlist_file)
    if not wordlist:
        console.print(" [bold red]Wordlist empty![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    with open(hash_file, 'r') as f:
        hashes = [line.strip() for line in f if line.strip()]
    
    console.print(f" [dim]Hashes to crack: {len(hashes)}[/]")
    console.print(f" [dim]Words in wordlist: {len(wordlist)}[/]")
    
    results = []
    for i, h in enumerate(hashes):
        console.print(f" [dim]Cracking {i+1}/{len(hashes)}...[/]")
        hash_type = detect_hash_type(h)
        if hash_type != "UNKNOWN":
            result = crack_hash(h, wordlist, hash_type)
            results.append((h, hash_type, result))
        else:
            results.append((h, "UNKNOWN", None))
    
    console.print("\n [bold green]RESULTS:[/]")
    table = Table(box=box.ROUNDED, border_style=CURRENT_HEX)
    table.add_column("#", style=f"bold {CURRENT_HEX}")
    table.add_column("Hash", style="white")
    table.add_column("Type", style="dim")
    table.add_column("Result", style="green")
    
    for i, (h, t, r) in enumerate(results, 1):
        result_text = r if r else "[red]FAILED[/]"
        table.add_row(str(i), h[:20] + "...", t, result_text)
    
    console.print(table)
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== DETECT HASH ==============
def detect_hash():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]DETECT HASH TYPE[/]"), border_style=CURRENT_HEX)))
    
    hash_string = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Enter hash >> ").strip()
    if not hash_string:
        console.print(" [bold red]Hash required![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    hash_type = detect_hash_type(hash_string)
    table = Table(box=box.ROUNDED, border_style=CURRENT_HEX)
    table.add_column("Property", style=f"bold {CURRENT_HEX}")
    table.add_column("Value", style="white")
    table.add_row("Hash", hash_string[:30] + ("..." if len(hash_string) > 30 else ""))
    table.add_row("Length", str(len(hash_string)))
    table.add_row("Detected Type", hash_type)
    console.print(table)
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== GENERATE HASH ==============
def generate_hash():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]GENERATE HASH[/]"), border_style=CURRENT_HEX)))
    
    word = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Word to hash >> ").strip()
    if not word:
        console.print(" [bold red]Word required![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    hash_type = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Hash type (MD5/SHA1/SHA256/SHA512) >> ").strip().upper()
    if hash_type not in ["MD5", "SHA1", "SHA256", "SHA512", "SHA384", "SHA224"]:
        hash_type = "MD5"
        console.print(f" [dim]Using default: MD5[/]")
    
    result = hash_word(word, hash_type)
    table = Table(box=box.ROUNDED, border_style=CURRENT_HEX)
    table.add_column("Property", style=f"bold {CURRENT_HEX}")
    table.add_column("Value", style="white")
    table.add_row("Word", word)
    table.add_row("Hash Type", hash_type)
    table.add_row("Hash", result)
    console.print(table)
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== GENERATE WORDLIST ==============
def generate_wordlist():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]GENERATE WORDLIST[/]"), border_style=CURRENT_HEX)))
    
    filename = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Filename (default: wordlist.txt) >> ").strip()
    if not filename:
        filename = "wordlist.txt"
    
    if not os.path.dirname(filename):
        filename = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    
    words = []
    console.print(" [dim]Enter words (empty line to finish):[/]")
    while True:
        word = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Word >> ").strip()
        if not word:
            break
        words.append(word)
    
    if words:
        with open(filename, 'w') as f:
            for word in words:
                f.write(word + "\n")
        console.print(f" [bold green]✓ Wordlist saved to: {filename}[/]")
        console.print(f" [dim]Words: {len(words)}[/]")
    else:
        console.print(" [bold yellow]No words entered![/]")
    
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== BRUTE FORCE ==============
def brute_force():
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BRUTE FORCE[/]"), border_style=CURRENT_HEX)))
    
    target_hash = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Hash to crack >> ").strip()
    if not target_hash:
        console.print(" [bold red]Hash required![/]")
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
        return
    
    hash_type = detect_hash_type(target_hash)
    console.print(f" [dim]Detected: [bold]{hash_type}[/]")
    
    if hash_type == "UNKNOWN":
        console.print(" [bold yellow]Warning: Unknown hash type![/]")
        hash_type = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Enter hash type >> ").strip().upper()
        if hash_type not in ["MD5", "SHA1", "SHA256", "SHA512"]:
            console.print(" [bold red]Invalid hash type![/]")
            console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")
            return
    
    max_length = 4
    try:
        max_length = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Max length (1-4) >> ").strip() or "4")
        if max_length > 4:
            max_length = 4
            console.print(" [dim]Max length set to 4 (performance)[/]")
    except (ValueError, EOFError):
        max_length = 4
    
    chars = string.ascii_lowercase + string.digits
    console.print(f" [dim]Charset: {chars[:20]}...[/]")
    console.print(f" [dim]Max length: {max_length}[/]")
    
    found = None
    
    def try_word(word):
        nonlocal found
        if hash_word(word, hash_type) == target_hash:
            found = word
            return True
        return False
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("[yellow]Brute forcing...", total=None)
        
        for length in range(1, max_length + 1):
            progress.update(task, description=f"[yellow]Trying length {length}...")
            for combo in itertools.product(chars, repeat=length):
                word = ''.join(combo)
                if try_word(word):
                    progress.update(task, description="[green]Found!")
                    break
                if found:
                    break
            if found:
                break
    
    if found:
        console.print(f"\n [bold green]✓ CRACKED![/]")
        console.print(f" [bold green]Hash: {target_hash}[/]")
        console.print(f" [bold green]Type: {hash_type}[/]")
        console.print(f" [bold green]Word: {found}[/]")
    else:
        console.print(f"\n [bold red]✗ Not found in character set![/]")
    
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to continue...[/]")

# ============== MAIN ==============
def main():
    boot()
    while True:
        try:
            choice = main_menu()
            if choice == "1":
                crack_single()
            elif choice == "2":
                crack_from_file()
            elif choice == "3":
                detect_hash()
            elif choice == "4":
                generate_hash()
            elif choice == "5":
                generate_wordlist()
            elif choice == "6":
                brute_force()
            elif choice == "99":
                console.print("\n [bold red]Exiting...[/]")
                break
            else:
                console.print("\n [bold red]Invalid option![/]")
                time.sleep(1)
            os.system("cls" if os.name == "nt" else "clear")
        except KeyboardInterrupt:
            console.print("\n [bold red]Exiting...[/]")
            break

if __name__ == "__main__":
    main()