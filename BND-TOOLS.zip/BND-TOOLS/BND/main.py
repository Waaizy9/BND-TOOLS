#!/usr/bin/env python3
"""BND-TOOLS — V2.0 - Blue Style Menu mit Animation"""

import os
import sys
import time
import random
import shutil
import json
import webbrowser
import subprocess

# Setze das richtige Working Directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))
_BND = os.path.dirname(os.path.abspath(__file__))

if _BND not in sys.path:
    sys.path.insert(0, _BND)

# ============== FARBEN ==============
def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

BLUE = hex_to_ansi("#0000CD")
WHITE = "\033[97m"
DIM = "\033[90m"
RESET = "\033[0m"
BOLD = "\033[1m"

# Verfügbare Farben
COLORS = {
    "RED": hex_to_ansi("#ff0000"),
    "GREEN": hex_to_ansi("#00ff00"),
    "BLUE": hex_to_ansi("#0000ff"),
    "YELLOW": hex_to_ansi("#ffff00"),
    "PURPLE": hex_to_ansi("#9b00ff"),
    "CYAN": hex_to_ansi("#00ffff"),
    "ORANGE": hex_to_ansi("#ff6600"),
    "PINK": hex_to_ansi("#ff69b4"),
    "LIME": hex_to_ansi("#bfff00"),
    "WHITE": "\033[97m",
    "ROSE": hex_to_ansi("#ff0088"),
    "GOLD": hex_to_ansi("#ffd700"),
}

VERSION = "2.0"
AUTHOR = "BND-Team"
DISCORD_URL = "https://discord.gg/Gc2MKCJvtm"
GITHUB_URL = "https://github.com/waaizy9/BND-TOOLS"
SHOP_URL = "https://bnd.mysellauth.com/"
CONFIG_FILE = os.path.join(os.path.dirname(__file__), "config.json")

TOOLS_DIR = os.path.join(os.path.dirname(__file__), "tools")

def load_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"theme": "BLUE"}

def save_config(theme):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump({"theme": theme}, f)
        return True
    except:
        return False

def get_current_color():
    config = load_config()
    theme = config.get("theme", "BLUE")
    return COLORS.get(theme, WHITE)

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_status(message, status="info"):
    """Zeigt eine Statusmeldung an"""
    current_color = get_current_color()
    symbols = {"info": "*", "success": "+", "error": "!", "loading": ">"}
    colors = {"info": WHITE, "success": current_color, "error": current_color, "loading": WHITE}
    print(f"{colors.get(status, WHITE)}[{symbols.get(status, '*')}] {message}{RESET}")

def print_header():
    clear()
    current_color = get_current_color()
    
    logo = f"""{current_color}
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
{RESET}"""
    
    print(logo)
    print(f"{WHITE} v{VERSION}  |  by {current_color}{AUTHOR}{RESET}                                                                             {current_color}{DISCORD_URL}{RESET}")
    print(f"{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}")
    print()

# ============== TOOL AUSFÜHRUNG ==============
# ============== TOOL AUSFÜHRUNG ==============
def run_tool_script(tool_name):
    """Führt ein Python-Skript aus dem tools Ordner aus"""
    
    tool_path = os.path.join(TOOLS_DIR, tool_name)
    
    # Spezialfall für email-bomber
    if tool_name == "email-bomber":
        possible_files = ["email-bomber.py", "main.py", "en.py", "__main__.py", "bomber.py"]
        for file in possible_files:
            file_path = os.path.join(tool_path, file)
            if os.path.exists(file_path):
                print_status(f"Starting Email Bomber...", "loading")
                time.sleep(0.5)
                try:
                    result = subprocess.call([sys.executable, file_path], cwd=tool_path)
                    if result != 0:
                        print_status(f"Email Bomber exited with error {result}", "error")
                    else:
                        print_status("Email Bomber finished", "success")
                except Exception as e:
                    print_status(f"Error: {e}", "error")
                input(f"\n{WHITE}Press Enter to continue...{RESET}")
                return
        
        # Wenn keine Datei gefunden wurde
        try:
            files = os.listdir(tool_path)
            print_status(f"No Python file found in {tool_name}", "error")
            print_status(f"Files in folder: {', '.join(files)}", "info")
        except:
            print_status(f"Folder {tool_path} not found!", "error")
        
        input(f"\n{WHITE}Press Enter to continue...{RESET}")
        return
    
    # Spezialfall für webhook-spammer
    if tool_name == "webhook-spammer":
        possible_files = ["webhook-spammer.py", "main.py", "en.py", "__main__.py", "spammer.py"]
        for file in possible_files:
            file_path = os.path.join(tool_path, file)
            if os.path.exists(file_path):
                print_status(f"Starting {tool_name}...", "loading")
                time.sleep(0.5)
                result = subprocess.call([sys.executable, file_path], cwd=tool_path)
                if result != 0:
                    print_status(f"{tool_name} exited with error {result}", "error")
                else:
                    print_status(f"{tool_name} finished", "success")
                input(f"\n{WHITE}Press Enter to continue...{RESET}")
                return
        
        try:
            files = os.listdir(tool_path)
            print_status(f"No Python file found in {tool_name}", "error")
            print_status(f"Files in folder: {', '.join(files)}", "info")
        except:
            print_status(f"Folder {tool_path} not found!", "error")
        
        input(f"\n{WHITE}Press Enter to continue...{RESET}")
        return
    
    # Für andere Tools
    main_py = os.path.join(tool_path, "main.py")
    tool_py = os.path.join(tool_path, f"{tool_name}.py")
    
    if os.path.exists(main_py):
        print_status(f"Starting {tool_name}...", "loading")
        time.sleep(0.5)
        subprocess.call([sys.executable, main_py], cwd=tool_path)
    elif os.path.exists(tool_py):
        print_status(f"Starting {tool_name}...", "loading")
        time.sleep(0.5)
        subprocess.call([sys.executable, tool_py], cwd=tool_path)
    else:
        py_files = [f for f in os.listdir(tool_path) if f.endswith('.py')]
        if py_files:
            print_status(f"Starting {tool_name}...", "loading")
            time.sleep(0.5)
            subprocess.call([sys.executable, os.path.join(tool_path, py_files[0])], cwd=tool_path)
        else:
            print_status(f"No Python file found in {tool_name}", "error")
            input(f"\n{WHITE}Press Enter to continue...{RESET}")

def run_command(cmd):
    """Führt einen Befehl aus"""
    try:
        subprocess.run(cmd, shell=True)
    except Exception as e:
        print_status(f"Error: {e}", "error")

# ============== TOOL DEFINITIONEN ==============
def get_tools_for_category(cat_key):
    """Holt die Tools für eine Kategorie mit besserer Übersicht"""
    
    # HOME Kategorie
    if cat_key == "home":
        return [
            ("01", "GitHub", lambda: webbrowser.open(GITHUB_URL)),
            ("02", "Discord", lambda: webbrowser.open(DISCORD_URL)),
            ("03", "Premium Shop", lambda: webbrowser.open(SHOP_URL)),
            ("04", "Changelog", tool_changelog),
            ("05", "Credits", tool_credits),
            ("06", "Setup Config", color_setup),
            ("07", "Links / MAJ", tool_links_maj),
        ]
    
    # OSINT Kategorie
    elif cat_key == "osint":
        return [
            ("01", "Username Hunter", lambda: run_tool_script("username-hunter")),
            ("02", "Email Tracker", lambda: run_tool_script("email-tracker")),
            ("03", "Email Lookup", lambda: run_tool_script("email-lookup")),
            ("04", "Phone Number Lookup", lambda: run_tool_script("number-info")),
            ("05", "IP Lookup", lambda: run_tool_script("ip-lookup")),
            ("06", "Domain Intel", lambda: run_tool_script("domain-intel")),
            ("07", "Wallet Tracker", lambda: run_tool_script("wallet-tracker")),
            ("08", "Dorking Query", lambda: run_tool_script("dorking-query")),
            ("09", "Instagram Lookup", lambda: run_tool_script("instagram-lookup")),
        ]
    
    
    # DISCORD Kategorie - NUR 3 TOOLS
    elif cat_key == "discord":
        return [
            ("01", "Token Checker", lambda: run_tool_script("discord-token")),
            ("02", "User Lookup", lambda: run_tool_script("discord-user")),
        ]
    
    # IP/WEB Kategorie
    elif cat_key == "ip-web":
        return [
            ("01", "IP Localise", lambda: run_tool_script("ip-localisation")),
            ("02", "IP Lookup", lambda: run_tool_script("ip-lookup")),
            ("03", "IP Pinger", lambda: run_tool_script("ip-pinger")),
            ("04", "IP VPN Detector", lambda: run_tool_script("ip-vpn-detector")),
            ("05", "Website Info", lambda: run_tool_script("website-info")),
            ("06", "Web Cloner", lambda: run_tool_script("website-cloner")),
        ]
    
    # GENERATOR Kategorie
    elif cat_key == "generator":
        return [
            ("01", "Nitro Gen", lambda: run_tool_script("nitro-generator")),
            ("02", "Amazon Gen", lambda: run_tool_script("amazon-generator")),
            ("03", "Netflix Gen", lambda: run_tool_script("netflix-generator")),
        ]
    
    # CRYPTO/UTILS Kategorie
    elif cat_key == "crypto-utils":
        return [
            ("01", "Hash Crack", lambda: run_tool_script("hash-crack")),
            ("02", "Zip Cracker", lambda: run_tool_script("zip-cracker")),
            ("03", "Keylogger", lambda: run_tool_script("keylogger")),
        ]
    
    # ATTACK Kategorie
    elif cat_key == "attack":
        return [
            ("01", "Email Bomber", lambda: run_tool_script("email-bomber")),
            ("02", "Discord Nuker", lambda: run_tool_script("discord-nuker")),
            ("03", "Webhook Spammer", lambda: run_tool_script("webhook-spammer")),
        ]
    
    # TOOLS Kategorie
    elif cat_key == "tools":
        return [
            ("01", "Help", tool_help),
            ("02", "Version", tool_version_info),
            ("03", "Settings", color_setup),
        ]
    
    return [("00", "⭐ Premium", lambda: None)]

# ============== INTERNE FUNKTIONEN ==============
def tool_changelog():
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} CHANGELOG{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}BND-TOOLS v{VERSION}{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}✨ New Features:{RESET}
 {current_color}├──{RESET}   • Matrix Rain Boot Effect
 {current_color}├──{RESET}   • Dynamic Color Scheme
 {current_color}├──{RESET}   • 3x3 Grid Menu Layout
 {current_color}├──{RESET}   • Page Navigation with Animation
 {current_color}├──{RESET}   • Color Configuration Menu
 {current_color}├──{RESET}   • Updated Discord Tools (Token Checker, User Lookup,
 {current_color}├──{RESET}   • Improved Category Structure
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}🐛 Bug Fixes:{RESET}
 {current_color}├──{RESET}   • Fixed Rich Markup Errors
 {current_color}├──{RESET}   • Improved Stability
 {current_color}├──{RESET}   • Fixed Duplicate Menu Entries
 {current_color}│{RESET}
 {current_color}└──{RESET}
""")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

def tool_credits():
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} CREDITS{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}BND-TOOLS v{VERSION}{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}👨‍💻 Developer:{RESET} {current_color}BND-Team{RESET}
 {current_color}├──{RESET} {WHITE}🎨 Design:{RESET} {current_color}BND-Team{RESET}
 {current_color}├──{RESET} {WHITE}🔧 Testing:{RESET} {current_color}Community{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}📧 Discord:{RESET} {current_color}{DISCORD_URL}{RESET}
 {current_color}├──{RESET} {WHITE}🐙 GitHub:{RESET} {current_color}{GITHUB_URL}{RESET}
 {current_color}│{RESET}
 {current_color}└──{RESET} {WHITE}Thanks for using BND-TOOLS!{RESET}
""")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

def tool_version_info():
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} VERSION INFO{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}Version: {VERSION}{RESET}
 {current_color}├──{RESET} {WHITE}Author: BND-Team{RESET}
 {current_color}├──{RESET} {WHITE}Python: {sys.version.split()[0]}{RESET}
 {current_color}├──{RESET} {WHITE}Platform: {sys.platform}{RESET}
 {current_color}│{RESET}
 {current_color}└──{RESET}
""")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

def tool_links_maj():
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} LINKS & UPDATES{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}📌 Important Links:{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}• Discord:{RESET} {current_color}{DISCORD_URL}{RESET}
 {current_color}├──{RESET} {WHITE}• GitHub:{RESET}  {current_color}{GITHUB_URL}{RESET}
 {current_color}├──{RESET} {WHITE}• Shop:{RESET}     {current_color}{SHOP_URL}{RESET}
 {current_color}│{RESET}
 {current_color}└──{RESET}
""")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

def tool_help():
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} HELP{RESET}
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}Navigation:{RESET}
 {current_color}├──{RESET}   • {current_color}N{RESET} - Next Page/Category
 {current_color}├──{RESET}   • {current_color}P{RESET} - Previous Page/Category
 {current_color}├──{RESET}   • {current_color}Q{RESET} - Quit
 {current_color}├──{RESET}   • {current_color}1-9{RESET} - Select Tool
 {current_color}│{RESET}
 {current_color}├──{RESET} {WHITE}Categories:{RESET}
 {current_color}├──{RESET}   • {current_color}HOME{RESET} - Main Menu
 {current_color}├──{RESET}   • {current_color}OSINT{RESET} - Information Gathering
 {current_color}├──{RESET}   • {current_color}PENTESTING{RESET} - Security Testing
 {current_color}├──{RESET}   • {current_color}DISCORD{RESET} - Discord Tools (Token Checker, User Lookup,
 {current_color}├──{RESET}   • {current_color}IP/WEB{RESET} - IP & Web Tools
 {current_color}├──{RESET}   • {current_color}GENERATOR{RESET} - Account Generator
 {current_color}├──{RESET}   • {current_color}UTILS{RESET} - Utilities
 {current_color}├──{RESET}   • {current_color}ATTACK{RESET} - Attack Tools
 {current_color}├──{RESET}   • {current_color}TOOLS{RESET} - Help & Settings
 {current_color}│{RESET}
 {current_color}└──{RESET}
""")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

# ============== SETUP CONFIG ==============
def color_setup():
    colors_list = [
        "RED", "GREEN", "BLUE", "YELLOW", "PURPLE", 
        "CYAN", "ORANGE", "PINK", "LIME", "WHITE", 
        "ROSE", "GOLD"
    ]
    selected = 0
    config = load_config()
    current_theme = config.get("theme", "BLUE")
    
    for i, c in enumerate(colors_list):
        if c == current_theme:
            selected = i
            break
    
    while True:
        clear()
        print_header()
        
        print(f"{WHITE}╔══════════════════════════════════════════════════════════════════╗{RESET}")
        print(f"{WHITE}║  {BOLD}Color Configuration{RESET}{WHITE}                                              ║{RESET}")
        print(f"{WHITE}╠══════════════════════════════════════════════════════════════════╣{RESET}")
        
        mid = (len(colors_list) + 1) // 2
        for i in range(mid):
            line = f"{WHITE}║{RESET}  "
            if i < len(colors_list):
                color_name = colors_list[i]
                color_code = COLORS.get(color_name, WHITE)
                if selected == i:
                    line += f"{BLUE}►{RESET} {color_code}{color_name:<12}{RESET}  "
                else:
                    line += f"  {color_code}{color_name:<12}{RESET}  "
            else:
                line += " " * 16
            
            line += " "
            
            if i + mid < len(colors_list):
                color_name = colors_list[i + mid]
                color_code = COLORS.get(color_name, WHITE)
                if selected == i + mid:
                    line += f"{BLUE}►{RESET} {color_code}{color_name:<12}{RESET}"
                else:
                    line += f"  {color_code}{color_name:<12}{RESET}"
            
            print(line)
        
        print(f"{WHITE}╚══════════════════════════════════════════════════════════════════╝{RESET}")
        print()
        print(f"{DIM}╭──────────────────────────────────────────────────────────────────────╮{RESET}")
        print(f"{DIM}│                         ↑ ↓ select · Enter save                      │{RESET}")
        print(f"{DIM}╰──────────────────────────────────────────────────────────────────────╯{RESET}")
        
        import msvcrt
        key = msvcrt.getch()
        
        if key == b'\xe0':
            key = msvcrt.getch()
            if key == b'H':
                selected = (selected - 1) % len(colors_list)
            elif key == b'P':
                selected = (selected + 1) % len(colors_list)
        elif key == b'\r':
            selected_color = colors_list[selected]
            save_config(selected_color)
            print(f"\n{WHITE}[+] Theme changed to {selected_color}!{RESET}")
            time.sleep(1.5)
            break
        elif key == b'q':
            break

# ============== ANIMATION ==============
def quick_animation():
    try:
        cols, rows = shutil.get_terminal_size((80, 25))
    except:
        cols, rows = 80, 25
    
    sys.stdout.write("\033[s")
    for _ in range(8):
        x = random.randint(1, cols - 5)
        y = random.randint(1, rows - 3)
        char = random.choice("01")
        intensity = random.randint(150, 255)
        color = f"\033[38;2;0;0;{intensity}m"
        sys.stdout.write(f"\033[{y};{x}H{color}{char}{RESET}")
        time.sleep(0.008)
    sys.stdout.write("\033[u")
    sys.stdout.flush()
    time.sleep(0.05)

# ============== MENÜ ==============
def show_menu(current_cat, categories, current_page=0, total_pages=1, page_tools=None):
    cat_name = categories[current_cat][1]
    current_color = get_current_color()
    
    print(f"""
 {current_color}┌──{current_color} [{cat_name}]{RESET}  ·  {WHITE}Page {current_page + 1}/{total_pages}{RESET}
 {current_color}│{RESET}
 {current_color}├──{current_color} BND-TOOLS{RESET}""")
    
    if page_tools:
        for row in range(3):
            line = f" {current_color}│{RESET}   "
            for col in range(3):
                idx = row * 3 + col
                if idx < len(page_tools):
                    code, label, _ = page_tools[idx]
                    line += f"{current_color}[{code}]{RESET} {WHITE}{label[:15]:<15}{RESET}"
                    if col < 2:
                        line += " " * 2
                else:
                    line += " " * 20
            print(line)
    
    next_cat = categories[(current_cat + 1) % len(categories)][1].lower()
    prev_cat = categories[(current_cat - 1) % len(categories)][1].lower()
    
    print(f"""
 {current_color}├──{RESET}  {current_color}[{current_color}N{current_color}]{RESET}  {WHITE}next{RESET}  ──>  {current_color}{next_cat}{RESET}
 {current_color}├──{RESET}  {current_color}[{current_color}P{current_color}]{RESET}  {WHITE}prev{RESET}  ──>  {current_color}{prev_cat}{RESET}
 {current_color}├──{RESET}  {current_color}[{current_color}H{current_color}]{RESET}  {WHITE}help{RESET}
 {current_color}│{RESET}
 {current_color}└──{RESET}  {current_color}[{current_color}Q{current_color}]{RESET}  {WHITE}quit{RESET}
{RESET}
 {current_color}┌─[{current_color}bnd@tool{RESET}]──[{WHITE}~/{cat_name.lower()}{RESET}]
 {current_color}└── >>{RESET} """, end="")

def run_tool(action, label):
    clear()
    print_header()
    current_color = get_current_color()
    print(f"""
 {current_color}┌──{current_color} {label}{RESET}
 {current_color}│{RESET}
 {current_color}└──{RESET} {WHITE}Starting...{RESET}
""")
    try:
        action()
    except Exception as e:
        print(f"{current_color}[!] Error: {WHITE}{e}{RESET}")
    print(f"\n{WHITE}Press Enter to continue...{RESET}")
    input()

def main():
    try:
        from lib.boot import boot
        boot(skip_anim=False)
    except:
        pass
    
    categories = [
        ("home", "HOME"),
        ("osint", "OSINT"),
        ("discord", "DISCORD"),
        ("ip-web", "IP/WEB"),
        ("generator", "GENERATOR"),
        ("crypto-utils", "UTILS"),
        ("attack", "ATTACK"),
        ("tools", "TOOLS"),
    ]
    
    current_cat = 0
    current_page = 0
    tools_per_page = 9
    
    while True:
        tools = get_tools_for_category(categories[current_cat][0])
        total_pages = max(1, (len(tools) + tools_per_page - 1) // tools_per_page)
        current_page = min(current_page, total_pages - 1)
        
        start_idx = current_page * tools_per_page
        end_idx = min(start_idx + tools_per_page, len(tools))
        page_tools = tools[start_idx:end_idx]
        
        print_header()
        show_menu(current_cat, categories, current_page, total_pages, page_tools)
        
        choice = input().strip().lower()
        
        if choice == 'q':
            print(f"\n{get_current_color()}[*] Goodbye!{RESET}")
            break
        elif choice == 'h':
            tool_help()
        elif choice == 'n':
            if current_page + 1 < total_pages:
                quick_animation()
                current_page += 1
            else:
                quick_animation()
                current_cat = (current_cat + 1) % len(categories)
                current_page = 0
        elif choice == 'p':
            if current_page > 0:
                quick_animation()
                current_page -= 1
            else:
                quick_animation()
                current_cat = (current_cat - 1) % len(categories)
                current_page = 0
        elif choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(page_tools):
                code, label, action = page_tools[idx]
                if action:
                    run_tool(action, label)
        else:
            continue

if __name__ == "__main__":
    main()