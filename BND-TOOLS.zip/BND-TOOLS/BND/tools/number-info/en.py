import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, phonenumbers, json
from phonenumbers import geocoder, carrier, timezone as ph_tz
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except:
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""
SUBTITLE = f"{CURRENT_COLOR}G L O B A L   T E L E P H O N Y   I N T E L L I G E N C E{RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // NUMBER INFO")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write(" ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        # Verwende die ausgewählte Farbe
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.1))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def analyze_num(num_str):
    try:
        parsed = phonenumbers.parse(num_str, None)
        if not phonenumbers.is_valid_number(parsed): return None
        
        return {
            "National": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL),
            "International": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "E164": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164),
            "Country": geocoder.country_name_for_number(parsed, "en"),
            "Region": geocoder.description_for_number(parsed, "en"),
            "Carrier": carrier.name_for_number(parsed, "en") or "Unknown",
            "Timezone": ", ".join(ph_tz.time_zones_for_number(parsed)),
            "Type": str(phonenumbers.number_type(parsed)).split(".")[-1]
        }
    except: return None

if __name__ == "__main__":
    try:
        boot()
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]NUMBER INFO[/]  [dim]//[/]  [{CURRENT_HEX}]OSINT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print()

        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Phone Number (+ prefix) [/][{CURRENT_HEX}]][/]")
        num = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        if not num: sys.exit(0)

        data = analyze_num(num)
        if not data:
            console.print(f"\n [{CURRENT_HEX}][!] Invalid number or unrecognized format (eg: +1...).{RESET}")
            time.sleep(2); sys.exit(0)

        tbl = Table(box=box.MINIMAL_DOUBLE_HEAD, border_style=CURRENT_HEX, show_header=False, padding=(0, 2))
        tbl.add_column("K", style=f"dim {CURRENT_HEX}", width=18)
        tbl.add_column("V", style="white")

        for k, v in data.items():
            tbl.add_row(k.upper(), str(v))

        os.system("cls" if os.name == "nt" else "clear")
        console.print(Align.center(Panel(
            Text.from_markup(f"[{CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]NUMBER INFO[/]  [dim]//[/]  [{CURRENT_HEX}]REPORT[/]"),
            border_style=CURRENT_HEX, padding=(0, 6)
        )))
        console.print(Align.center(tbl))
        console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

    except (KeyboardInterrupt, EOFError):
        pass