#!/usr/bin/env python3
"""BND-TOOLS - Discord Tools"""

import os
import sys
import time
import requests
import json
import re
import base64
import random
import string
import threading
import concurrent.futures
from datetime import datetime, timezone

# Farben
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
DIM = "\033[90m"
RESET = "\033[0m"
BOLD = "\033[1m"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear()
    print(f"{BLUE}")
    print("  ██████╗ ███╗   ██╗██████╗     ██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗ ")
    print("  ██╔══██╗████╗  ██║██╔══██╗    ██╔══██╗██║██╔════╝██╔═══██╗██╔══██╗██╔══██╗██╔══██╗")
    print("  ██████╔╝██╔██╗ ██║██║  ██║    ██║  ██║██║███████╗██║   ██║██████╔╝██████╔╝██║  ██║")
    print("  ██╔══██╗██║╚██╗██║██║  ██║    ██║  ██║██║╚════██║██║   ██║██╔══██╗██╔══██╗██║  ██║")
    print("  ██████╔╝██║ ╚████║██████╔╝    ██████╔╝██║███████║╚██████╔╝██║  ██║██║  ██║██████╔╝")
    print("  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ")
    print(f"{RESET}")
    print(f"{WHITE} v1.0  |  by BND-Team{BLUE}                                                                             discord.gg/bnd{RESET}")
    print(f"{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}")
    print()

def print_status(message, status="info"):
    symbols = {"info": "*", "success": "+", "error": "!", "loading": ">"}
    colors = {"info": WHITE, "success": GREEN, "error": RED, "loading": CYAN}
    print(f"{colors.get(status, WHITE)}[{symbols.get(status, '*')}] {message}{RESET}")

def _mask_token(token, show=12):
    token = token.strip()
    if len(token) <= show + 4:
        return token[:4] + "…"
    return token[:show] + "…" + token[-4:]

def _user_tag(data):
    u = data.get("username", "?")
    disc = data.get("discriminator", "0")
    return u if not disc or disc == "0" else f"{u}#{disc}"

def _parse_uid(raw):
    raw = (raw or "").strip()
    m = re.search(r"(\d{17,20})", raw)
    return m.group(1) if m else ""

_BADGE_FLAGS = [
    (1 << 0, "Staff"), (1 << 1, "Partner"), (1 << 2, "HypeSquad Events"),
    (1 << 3, "Bug Hunter"), (1 << 6, "Bravery"), (1 << 7, "Brilliance"),
    (1 << 8, "Balance"), (1 << 9, "Early Supporter"), (1 << 14, "Bug Hunter L2"),
    (1 << 16, "Verified Bot"), (1 << 17, "Early Verified Bot"),
    (1 << 18, "Moderator Alumni"), (1 << 22, "Active Developer"),
]

def _decode_badges(flags):
    if not flags:
        return "Keine"
    names = [n for bit, n in _BADGE_FLAGS if int(flags) & bit]
    return ", ".join(names) if names else "Keine"

def _snowflake_info(uid):
    sid = int(uid)
    ts_ms = (sid >> 22) + 1420070400000
    created = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
    now = datetime.now(timezone.utc)
    age_days = (now - created).days
    years, rem = divmod(age_days, 365)
    months, days = divmod(rem, 30)
    age = f"{years}J {months}M {days}T" if years else f"{months}M {days}T" if months else f"{days}T"
    return {
        "created": created.strftime("%Y-%m-%d %H:%M:%S UTC"),
        "created_local": created.astimezone().strftime("%Y-%m-%d %H:%M:%S"),
        "age": age,
        "age_days": age_days,
        "years": years,
        "months": months,
        "days": days,
        "timestamp_ms": ts_ms,
        "unix": ts_ms // 1000,
        "worker": (sid & 0x3E0000) >> 17,
        "process": (sid & 0x1F000) >> 12,
        "increment": sid & 0xFFF,
        "hex": f"0x{sid:X}",
        "avatar_idx": (sid >> 22) % 6,
    }

def _api(method, url, token=None, body=None, timeout=12):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    if body is not None:
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = token.strip()
    try:
        r = requests.request(method, url, headers=headers, json=body, timeout=timeout)
        try:
            data = r.json() if r.text else {}
        except:
            data = {}
        return r.status_code, data
    except Exception as ex:
        return 0, {"error": str(ex)}

# ============== TOOLS ==============

def token_checker():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} TOKEN CHECKER{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Überprüft einen Discord Token{RESET}
""")
    token = input(f"\n {BLUE}└─>>{RESET} {WHITE}Discord Token: {RESET}").strip()
    if not token:
        print_status("Kein Token eingegeben!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status("Prüfe Token...", "loading")
    code, data = _api("GET", "https://discord.com/api/v9/users/@me", token=token)
    
    if code == 200:
        sf = _snowflake_info(data.get('id', '0'))
        print(f"""
 {BLUE}┌──{BLUE} TOKEN ERGEBNIS{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {GREEN}✓ TOKEN GÜLTIG{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{BLUE} 📋 BENUTZERDATEN{RESET}
 {BLUE}├──{RESET} {WHITE}Benutzername: {CYAN}{_user_tag(data)}{RESET}
 {BLUE}├──{RESET} {WHITE}Display Name: {CYAN}{data.get('global_name', '—')}{RESET}
 {BLUE}├──{RESET} {WHITE}User ID: {CYAN}{data.get('id', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Email: {CYAN}{data.get('email', 'versteckt')}{RESET}
 {BLUE}├──{RESET} {WHITE}Handynr.: {CYAN}{'Ja' if data.get('phone') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Verifiziert: {CYAN}{'Ja' if data.get('verified') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}MFA: {CYAN}{'Ja' if data.get('mfa_enabled') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Nitro: {CYAN}{'Ja' if data.get('premium_type') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Bot: {CYAN}{'Ja' if data.get('bot') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}System: {CYAN}{'Ja' if data.get('system') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Badges: {CYAN}{_decode_badges(data.get('public_flags', 0))}{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{BLUE} 🕐 SNOWFLAKE DATEN{RESET}
 {BLUE}├──{RESET} {WHITE}Erstellt: {CYAN}{sf['created']}{RESET}
 {BLUE}├──{RESET} {WHITE}Erstellt (lokal): {CYAN}{sf['created_local']}{RESET}
 {BLUE}├──{RESET} {WHITE}Account Alter: {CYAN}{sf['age']} ({sf['age_days']} Tage){RESET}
 {BLUE}├──{RESET} {WHITE}Unix Timestamp: {CYAN}{sf['unix']}{RESET}
 {BLUE}├──{RESET} {WHITE}Worker ID: {CYAN}{sf['worker']}{RESET}
 {BLUE}├──{RESET} {WHITE}Process ID: {CYAN}{sf['process']}{RESET}
 {BLUE}├──{RESET} {WHITE}Increment: {CYAN}{sf['increment']}{RESET}
 {BLUE}├──{RESET} {WHITE}Hex: {CYAN}{sf['hex']}{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{BLUE} 🔗 LINKS{RESET}
 {BLUE}├──{RESET} {WHITE}Profil: {CYAN}https://discord.com/users/{data.get('id', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Avatar: {CYAN}https://cdn.discordapp.com/avatars/{data.get('id', '?')}/{data.get('avatar', '0')}.png{RESET}
 {BLUE}└──{RESET}
""")
    else:
        print(f"""
 {BLUE}┌──{BLUE} TOKEN ERGEBNIS{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {RED}✗ TOKEN UNGÜLTIG (HTTP {code}){RESET}
""")
    
    input(f"\n{WHITE}Press Enter...{RESET}")

def user_lookup():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} USER LOOKUP{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Zeigt alle verfügbaren Daten zu einer User ID an{RESET}
""")
    uid = input(f"\n {BLUE}└─>>{RESET} {WHITE}User ID: {RESET}").strip()
    uid = _parse_uid(uid)
    if not uid:
        print_status("Ungültige User ID!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status("Lade Benutzerdaten...", "loading")
    
    # Versuche Daten über API zu bekommen (mit Bot Token optional)
    token = input(f"\n {BLUE}[?]{RESET} {WHITE}Bot Token (optional, für mehr Daten): {RESET}").strip()
    if token and not token.lower().startswith("bot "):
        token = f"Bot {token}"
    
    code, data = _api("GET", f"https://discord.com/api/v9/users/{uid}", token=token if token else None)
    
    sf = _snowflake_info(uid)
    
    print(f"""
 {BLUE}┌──{BLUE} USER LOOKUP RESULT{RESET}
 {BLUE}│{RESET}
""")
    
    if code == 200 and data:
        print(f"""
 {BLUE}├──{BLUE} 📋 BENUTZERDATEN{RESET}
 {BLUE}├──{RESET} {WHITE}Benutzername: {CYAN}{_user_tag(data)}{RESET}
 {BLUE}├──{RESET} {WHITE}Display Name: {CYAN}{data.get('global_name', '—')}{RESET}
 {BLUE}├──{RESET} {WHITE}User ID: {CYAN}{data.get('id', uid)}{RESET}
 {BLUE}├──{RESET} {WHITE}Bot: {CYAN}{'Ja' if data.get('bot') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}System: {CYAN}{'Ja' if data.get('system') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Badges: {CYAN}{_decode_badges(data.get('public_flags', 0))}{RESET}
 {BLUE}├──{RESET} {WHITE}Accent Color: {CYAN}{data.get('accent_color', '—')}{RESET}
""")
    else:
        print(f"""
 {BLUE}├──{BLUE} 📋 BENUTZERDATEN{RESET}
 {BLUE}├──{RESET} {YELLOW}⚠ Keine API-Daten (kein Bot Token oder Benutzer nicht gefunden){RESET}
""")
    
    print(f"""
 {BLUE}├──{BLUE} 🕐 SNOWFLAKE DATEN (aus ID berechnet){RESET}
 {BLUE}├──{RESET} {WHITE}Erstellungsdatum: {CYAN}{sf['created']}{RESET}
 {BLUE}├──{RESET} {WHITE}Erstellt (lokal): {CYAN}{sf['created_local']}{RESET}
 {BLUE}├──{RESET} {WHITE}Account Alter: {CYAN}{sf['age']} ({sf['age_days']} Tage){RESET}
 {BLUE}├──{RESET} {WHITE}Jahre: {CYAN}{sf['years']}{RESET}
 {BLUE}├──{RESET} {WHITE}Monate: {CYAN}{sf['months']}{RESET}
 {BLUE}├──{RESET} {WHITE}Tage: {CYAN}{sf['days']}{RESET}
 {BLUE}├──{RESET} {WHITE}Unix Timestamp: {CYAN}{sf['unix']}{RESET}
 {BLUE}├──{RESET} {WHITE}Timestamp (ms): {CYAN}{sf['timestamp_ms']}{RESET}
 {BLUE}├──{RESET} {WHITE}Worker ID: {CYAN}{sf['worker']}{RESET}
 {BLUE}├──{RESET} {WHITE}Process ID: {CYAN}{sf['process']}{RESET}
 {BLUE}├──{RESET} {WHITE}Increment: {CYAN}{sf['increment']}{RESET}
 {BLUE}├──{RESET} {WHITE}Hex: {CYAN}{sf['hex']}{RESET}
 {BLUE}├──{RESET} {WHITE}Avatar Index: {CYAN}{sf['avatar_idx']}{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{BLUE} 🔗 LINKS{RESET}
 {BLUE}├──{RESET} {WHITE}Profil: {CYAN}https://discord.com/users/{uid}{RESET}
 {BLUE}├──{RESET} {WHITE}Standard Avatar: {CYAN}https://cdn.discordapp.com/embed/avatars/{sf['avatar_idx']}.png{RESET}
""")
    
    if code == 200 and data and data.get('avatar'):
        print(f" {BLUE}├──{RESET} {WHITE}Avatar: {CYAN}https://cdn.discordapp.com/avatars/{uid}/{data['avatar']}.png{RESET}")
    if code == 200 and data and data.get('banner'):
        print(f" {BLUE}├──{RESET} {WHITE}Banner: {CYAN}https://cdn.discordapp.com/banners/{uid}/{data['banner']}.png?size=512{RESET}")
    
    print(f"""
 {BLUE}└──{RESET}
""")
    input(f"\n{WHITE}Press Enter...{RESET}")

def token_login():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} TOKEN LOGIN{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Loggt mit Token in Discord ein{RESET}
""")
    token = input(f"\n {BLUE}└─>>{RESET} {WHITE}Discord Token: {RESET}").strip()
    if not token:
        print_status("Kein Token eingegeben!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status("Prüfe Token...", "loading")
    code, data = _api("GET", "https://discord.com/api/v9/users/@me", token=token)
    
    if code != 200:
        print_status("Token ungültig!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status(f"Eingeloggt als {_user_tag(data)}", "success")
    
    import webbrowser
    webbrowser.open("https://discord.com/login")
    
    print(f"""
 {BLUE}┌──{BLUE} MANUELLER LOGIN{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}1. Öffne Discord in deinem Browser{RESET}
 {BLUE}├──{RESET} {WHITE}2. Drücke F12 → Console{RESET}
 {BLUE}├──{RESET} {WHITE}3. Füge ein:{RESET}
 {BLUE}│{RESET}
 {BLUE}│   {CYAN}function login(t){{setInterval(()=>{{document.body.appendChild(document.createElement(\"iframe\")).contentWindow.localStorage.token=`\"${{t}}\"`}},50);setTimeout(()=>location.reload(),2500);}} login(\"{token}\"){RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET}
""")
    input(f"\n{WHITE}Press Enter...{RESET}")

def invite_resolver():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} INVITE RESOLVER{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Zeigt Informationen zu einem Discord Invite an{RESET}
""")
    invite = input(f"\n {BLUE}└─>>{RESET} {WHITE}Invite Code oder Link: {RESET}").strip()
    if not invite:
        print_status("Kein Invite eingegeben!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    m = re.search(r"(?:discord\.gg/|discord(?:app)?\.com/invite/)([A-Za-z0-9-]+)", invite)
    code = m.group(1) if m else invite.split("/")[-1]
    
    print_status(f"Löse Invite auf...", "loading")
    c, data = _api("GET", f"https://discord.com/api/v9/invites/{code}?with_counts=true")
    
    if c == 200:
        guild = data.get("guild", {})
        channel = data.get("channel", {})
        inviter = data.get("inviter", {})
        print(f"""
 {BLUE}┌──{BLUE} INVITE INFO{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}Code: {CYAN}{code}{RESET}
 {BLUE}├──{RESET} {WHITE}Server: {CYAN}{guild.get('name', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Server ID: {CYAN}{guild.get('id', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Channel: {CYAN}{channel.get('name', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Channel ID: {CYAN}{channel.get('id', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Mitglieder: {CYAN}{data.get('approximate_member_count', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Online: {CYAN}{data.get('approximate_presence_count', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Erstellt von: {CYAN}{_user_tag(inviter) if inviter else 'Unbekannt'}{RESET}
 {BLUE}├──{RESET} {WHITE}Link: {CYAN}https://discord.gg/{code}{RESET}
 {BLUE}└──{RESET}
""")
    else:
        print_status(f"Invite ungültig! (HTTP {c})", "error")
    
    input(f"\n{WHITE}Press Enter...{RESET}")

def guild_leaver():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} GUILD LEAVER{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Verlässt alle Server mit dem Token{RESET}
""")
    token = input(f"\n {BLUE}└─>>{RESET} {WHITE}Discord Token: {RESET}").strip()
    if not token:
        print_status("Kein Token eingegeben!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status("Prüfe Token...", "loading")
    code, user = _api("GET", "https://discord.com/api/v9/users/@me", token=token)
    if code != 200:
        print_status("Token ungültig!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print_status(f"Token gültig für {_user_tag(user)}", "success")
    
    print_status("Lade Serverliste...", "loading")
    c, guilds = _api("GET", "https://discord.com/api/v9/users/@me/guilds", token=token)
    
    if c != 200 or not isinstance(guilds, list):
        print_status("Konnte Server nicht laden!", "error")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    print(f"""
 {BLUE}┌──{BLUE} SERVERLISTE{RESET}
 {BLUE}│{RESET}
""")
    for g in guilds[:20]:
        owner = "👑" if g.get("owner") else "  "
        print(f" {BLUE}├──{RESET} {owner} {WHITE}{g.get('name', '?')}{RESET} {DIM}({g.get('id', '?')}){RESET}")
    if len(guilds) > 20:
        print(f" {BLUE}├──{RESET} {DIM}... und {len(guilds) - 20} weitere{RESET}")
    print(f"""
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Total: {len(guilds)} Server{RESET}
""")
    
    confirm = input(f"\n {BLUE}[?]{RESET} {WHITE}ALLE Server verlassen? (yes/no): {RESET}").lower()
    if confirm not in ("yes", "y"):
        print_status("Abgebrochen", "info")
        input(f"\n{WHITE}Press Enter...{RESET}")
        return
    
    left = 0
    failed = 0
    for g in guilds:
        if g.get("owner"):
            url = f"https://discord.com/api/v9/guilds/{g['id']}"
        else:
            url = f"https://discord.com/api/v9/users/@me/guilds/{g['id']}"
        c, _ = _api("DELETE", url, token=token)
        if c in (200, 204):
            left += 1
            print(f" {BLUE}[+]{RESET} {WHITE}Verlassen: {g.get('name', '?')}{RESET}")
        else:
            failed += 1
            print(f" {RED}[-]{RESET} {WHITE}Fehler: {g.get('name', '?')} (HTTP {c}){RESET}")
        time.sleep(0.3)
    
    print(f"""
 {BLUE}┌──{BLUE} ZUSAMMENFASSUNG{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {GREEN}Verlassen: {left}{RESET}
 {BLUE}├──{RESET} {RED}Fehlgeschlagen: {failed}{RESET}
 {BLUE}└──{RESET}
""")
    input(f"\n{WHITE}Press Enter...{RESET}")

# ============== MENÜ ==============

def show_menu():
    print(f"""
 {BLUE}┌──{BLUE} BND DISCORD{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}01. Token Checker{RESET}
 {BLUE}├──{RESET} {WHITE}02. User Lookup (mit Snowflake){RESET}
 {BLUE}├──{RESET} {WHITE}03. Invite Resolver{RESET}
 {BLUE}├──{RESET} {WHITE}04. Token Login{RESET}
 {BLUE}├──{RESET} {WHITE}05. Guild Leaver{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}00. Zurück{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET}
""")

def main():
    tools = {
        "1": token_checker, "01": token_checker,
        "2": user_lookup, "02": user_lookup,
        "3": invite_resolver, "03": invite_resolver,
        "4": token_login, "04": token_login,
        "5": guild_leaver, "05": guild_leaver,
    }
    
    while True:
        print_header()
        show_menu()
        choice = input(f" {BLUE}└─>>{RESET} {WHITE}").strip()
        
        if choice in ("0", "00", "q", "Q"):
            break
        elif choice in tools:
            tools[choice]()
        else:
            print_status("Ungültige Auswahl!", "error")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Abgebrochen!{RESET}")