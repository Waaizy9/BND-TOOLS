import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, aiohttp, json, random, threading
from datetime import datetime

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich import box
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except:
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND NETFLIX GEN Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ███╗   ██╗███████╗████████╗███████╗██╗██╗  ██╗
  ██╔══██╗████╗  ██║██╔══██╗    ████╗  ██║██╔════╝╚══██╔══╝██╔════╝██║╚██╗██╔╝
  ██████╔╝██╔██╗ ██║██║  ██║    ██╔██╗ ██║█████╗     ██║   █████╗  ██║ ╚███╔╝ 
  ██╔══██╗██║╚██╗██║██║  ██║    ██║╚██╗██║██╔══╝     ██║   ██╔══╝  ██║ ██╔██╗ 
  ██████╔╝██║ ╚████║██████╔╝    ██║ ╚████║███████╗   ██║   ██║     ██║██╔╝ ██╗
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝     ╚═╝╚═╝  ╚═╝
"""

# Netflix Code Formate
NETFLIX_FORMATS = {
    "1": {"name": "Standard (16)", "blocks": [16], "separator": "", "example": "ABCD1234EFGH5678"},
    "2": {"name": "4x4 Blöcke", "blocks": [4, 4, 4, 4], "separator": "-", "example": "ABCD-1234-EFGH-5678"},
    "3": {"name": "2x8 Blöcke", "blocks": [8, 8], "separator": "-", "example": "ABCD1234-EFGH5678"},
    "4": {"name": "4x4 mit Unterstrichen", "blocks": [4, 4, 4, 4], "separator": "_", "example": "ABCD_1234_EFGH_5678"},
    "5": {"name": "5x3 + 1", "blocks": [5, 5, 5, 1], "separator": "-", "example": "ABCD1-234EF-GH567-8"},
}

NETFLIX_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // NETFLIX GEN // OSINT CORE")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def generate_netflix_code(blocks, separator=""):
    """Generiert einen Netflix-Code"""
    code_parts = []
    for block_size in blocks:
        part = ''.join(random.choice(NETFLIX_CHARS) for _ in range(block_size))
        code_parts.append(part)
    return separator.join(code_parts)

def generate_batch(count, blocks, separator=""):
    """Generiert einen Batch von Netflix-Codes"""
    codes = []
    for _ in range(count):
        codes.append(generate_netflix_code(blocks, separator))
    return codes

def save_codes(codes, format_name):
    """Speichert die Codes in einer Datei"""
    output_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Void - Output", "Generated")
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"netflix_codes_{timestamp}.txt"
    filepath = os.path.join(output_dir, filename)
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"# BND NETFLIX GEN\n")
        f.write(f"# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"# Format: {format_name}\n")
        f.write(f"# Total: {len(codes)}\n")
        f.write(f"# {'='*50}\n\n")
        f.write("\n".join(codes))
    
    return filepath

def main():
    boot()
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]NETFLIX GIFT CARD GENERATOR V2[/]"), border_style=CURRENT_HEX, padding=(0, 5))))
    console.print()
    
    # Format auswählen
    console.print(Text.from_markup(f"[bold {CURRENT_HEX}]📋 Verfgügbare Formate:[/]"))
    console.print()
    
    format_table = Table(box=box.ROUNDED, border_style=CURRENT_HEX, header_style=f"bold {CURRENT_HEX}")
    format_table.add_column("ID", style="bold yellow", width=4)
    format_table.add_column("Format Name", style="bold white")
    format_table.add_column("Beispiel", style="cyan")
    format_table.add_column("Blöcke", style="dim")
    
    for key, fmt in NETFLIX_FORMATS.items():
        blocks = " + ".join([str(b) for b in fmt["blocks"]])
        format_table.add_row(key, fmt["name"], fmt["example"], blocks)
    
    console.print(format_table)
    console.print()
    
    # Format wählen
    while True:
        choice = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Format wählen (1-5) >> [/]").strip()
        if choice in NETFLIX_FORMATS:
            break
        console.print(f" [bold red]✗[/] Ungültige Auswahl. Bitte 1-5 wählen.")
    
    selected_format = NETFLIX_FORMATS[choice]
    blocks = selected_format["blocks"]
    separator = selected_format["separator"]
    format_name = selected_format["name"]
    
    console.print(f"\n [bold green]✓[/] Ausgewählt: [white]{format_name}[/]")
    console.print()
    
    # Anzahl der Codes
    while True:
        try:
            count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Anzahl der Codes >> [/]").strip())
            if count > 0:
                break
            console.print(f" [bold red]✗[/] Bitte eine Zahl größer als 0 eingeben.")
        except ValueError:
            console.print(f" [bold red]✗[/] Ungültige Eingabe. Bitte eine Zahl eingeben.")
    
    console.print()
    
    # Layout für Live-UI
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=6),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    
    codes = []
    progress = 0
    current_status = "Initialisiere Generator..."
    
    # Generierung in Thread starten
    def generate():
        nonlocal codes, progress, current_status
        codes = []
        total = count
        
        with Progress(
            SpinnerColumn(spinner_name="dots", style=f"bold {CURRENT_HEX}"),
            TextColumn("[bold white]{task.description}"),
            BarColumn(bar_width=40, style=CURRENT_HEX, complete_style="green"),
            TextColumn("[green]{task.completed}[white]/[white]{task.total}"),
            TimeElapsedColumn(),
            console=console,
            transient=True
        ) as progress_bar:
            task = progress_bar.add_task("[red]Generiere Netflix Codes...", total=total)
            
            batch_size = min(100, total)
            for i in range(0, total, batch_size):
                current_batch = min(batch_size, total - i)
                batch = generate_batch(current_batch, blocks, separator)
                codes.extend(batch)
                progress = int(((i + current_batch) / total) * 100)
                current_status = f"Generiere {i + current_batch} von {total} Codes..."
                progress_bar.update(task, completed=i + current_batch)
                
                if i + current_batch < total:
                    time.sleep(0.05)  # Kurze Pause für UI-Update
    
    # Generierung starten
    thread = threading.Thread(target=generate, daemon=True)
    thread.start()
    
    # Live-UI anzeigen
    with Live(layout, screen=True, refresh_per_second=10):
        while len(codes) < count:
            # Header
            header_text = Text.from_markup(
                f"[bold {CURRENT_HEX}]NETFLIX GENERATOR[/] [dim]||[/] [white]{format_name}[/] [dim]||[/] [{CURRENT_HEX}]{progress}%[/]"
            )
            layout["header"].update(Panel(
                Align.center(header_text),
                border_style=CURRENT_HEX,
                title=f"[bold {CURRENT_HEX}]BND-NETFLIX[/]",
                title_align="center"
            ))
            
            # Body - Codes anzeigen
            code_table = Table(box=box.SIMPLE, expand=True, header_style=f"bold {CURRENT_HEX}")
            code_table.add_column("#", style="bold yellow", width=6)
            code_table.add_column("Code", style="bold cyan")
            code_table.add_column("Länge", style="dim", width=10)
            
            if codes:
                display_count = min(20, len(codes))
                for i in range(display_count):
                    code = codes[i]
                    code_len = len(code.replace('-', '').replace('_', ''))
                    code_table.add_row(str(i+1), code, f"{code_len} chars")
                
                if len(codes) > 20:
                    code_table.add_row("...", f"[dim]{len(codes) - 20} weitere Codes...[/]", "")
            else:
                code_table.add_row("", "[dim]Warte auf Generierung...[/]", "")
            
            layout["body"].update(Panel(
                code_table,
                title=f"[bold white]LIVE GENERATION",
                border_style=CURRENT_HEX
            ))
            
            # Footer
            footer_text = Text.from_markup(
                f"[dim]BND NETFLIX GEN - {current_status}[/]"
            )
            layout["footer"].update(Panel(
                Align.center(footer_text),
                border_style=CURRENT_HEX
            ))
            
            time.sleep(0.1)
    
    # Fertig - Zusammenfassung anzeigen
    os.system("cls" if os.name == "nt" else "clear")
    
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold green]✓ GENERIERUNG ABGESCHLOSSEN[/]"),
        border_style="green",
        padding=(1, 5)
    )))
    console.print()
    
    # Statistik-Tabelle
    stats_table = Table(box=box.ROUNDED, border_style=CURRENT_HEX, header_style=f"bold {CURRENT_HEX}")
    stats_table.add_column("Metrik", style="bold white")
    stats_table.add_column("Wert", style="cyan")
    
    stats_table.add_row("Total generiert", f"{len(codes):,}")
    stats_table.add_row("Format", format_name)
    stats_table.add_row("Länge pro Code", f"{len(codes[0].replace('-', '').replace('_', '')) if codes else 0} chars")
    stats_table.add_row("Unique Codes", f"{len(set(codes)):,}")
    stats_table.add_row("Duplikate", f"{len(codes) - len(set(codes)):,}")
    
    console.print(stats_table)
    console.print()
    
    # Codes anzeigen (erste 10)
    console.print(Text.from_markup(f"[bold {CURRENT_HEX}]📋 Beispiel-Codes (erste 10):[/]"))
    console.print()
    
    preview_table = Table(box=box.SIMPLE, border_style=CURRENT_HEX)
    preview_table.add_column("#", style="bold yellow", width=6)
    preview_table.add_column("Code", style="bold cyan")
    preview_table.add_column("Länge", style="dim")
    
    for i in range(min(10, len(codes))):
        code = codes[i]
        code_len = len(code.replace('-', '').replace('_', ''))
        preview_table.add_row(str(i+1), code, str(code_len))
    
    console.print(preview_table)
    console.print()
    
    # Speichern
    save = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Codes speichern? (j/n) >> [/]").strip().lower()
    if save in ['j', 'ja', 'y', 'yes']:
        filepath = save_codes(codes, format_name)
        console.print(f"\n [bold green]✓[/] Gespeichert unter: [cyan]{filepath}[/]")
    else:
        console.print(f"\n [dim]Codes nicht gespeichert.[/]")
    
    console.print()
    console.input(f" [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print(f"\n[bold red]✗ Abgebrochen durch Benutzer.[/]")
        sys.exit()