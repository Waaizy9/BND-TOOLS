#!/usr/bin/env python3
"""Dorking Query Engine - Advanced search dork generator"""

import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, threading, random, re
import subprocess
import webbrowser
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box

console = Console()

# -- COLORS --
C_RED     = "#CC0000"
C_NEON    = "#FF2020"
C_WHITE   = "#FFFFFF"
C_SILVER  = "#CCCCCC"
C_DIM     = "#444444"
C_OK      = "#00FF00"
C_NO      = "#440000"
C_CYAN    = "#00FFFF"
C_PURPLE  = "#9B00FF"

ASCII = r"""
   ██████╗  ██████╗ ██████╗ ██╗  ██╗██╗███╗   ██╗ ██████╗ 
   ██╔══██╗██╔═══██╗██╔══██╗██║ ██╔╝██║████╗  ██║██╔════╝ 
   ██║  ██║██║   ██║██████╔╝█████╔╝ ██║██╔██╗ ██║██║  ███╗
   ██║  ██║██║   ██║██╔══██╗██╔═██╗ ██║██║╚██╗██║██║   ██║
   ██████╔╝╚██████╔╝██║  ██║██║  ██╗██║██║ ╚████║╚██████╔╝
   ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ 
"""

SUBTITLE = " D O R K I N G   Q U E R Y   E N G I N E   //   O S I N T "

def boot():
    if sys.platform.startswith("win"):
        os.system("title DORKING ENGINE // OSINT SEARCH")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(150 + 105 * math.sin(t * 8 - c * 0.25))))
                        sys.stdout.write(f"\033[38;2;{int(v*0.6)};0;{v}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  \033[38;2;150;100;255m{SUBTITLE}\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def make_layout():
    l = Layout()
    l.split_column(
        Layout(name="header", size=4),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    l["body"].split_row(
        Layout(name="results", ratio=2),
        Layout(name="stats", ratio=1)
    )
    return l

async def generate_dorks(query, engine, dork_type, update_fn):
    """Generate dork queries"""
    dork_map = {
        "1": f'intitle:"{query}"',
        "2": f'inurl:"{query}"',
        "3": f'filetype:pdf "{query}"',
        "4": f'site:{query}',
        "5": f'"{query}"',
        "6": f'intext:"{query}"',
        "7": f'cache:{query}',
        "8": f'related:{query}'
    }
    
    dork_names = {
        "1": "Title Search",
        "2": "URL Search", 
        "3": "File Type (PDF)",
        "4": "Site Search",
        "5": "Exact Match",
        "6": "Text Search",
        "7": "Cache",
        "8": "Related"
    }
    
    engine_urls = {
        "1": "https://www.google.com/search?q={dork}",
        "2": "https://www.bing.com/search?q={dork}",
        "3": "https://duckduckgo.com/?q={dork}"
    }
    
    engine_names = {
        "1": "Google",
        "2": "Bing",
        "3": "DuckDuckGo"
    }
    
    dork = dork_map.get(dork_type, f'"{query}"')
    dork_name = dork_names.get(dork_type, "Custom Dork")
    engine_name = engine_names.get(engine, "Unknown")
    
    update_fn(f"Generating {dork_name} for {engine_name}...", 50, 100)
    time.sleep(0.5)
    
    update_fn(f"Opening {engine_name} with dork...", 100, 100)
    time.sleep(0.5)
    
    if engine in engine_urls:
        url = engine_urls[engine].format(dork=dork)
        webbrowser.open(url)
        update_fn(f"✓ {engine_name} opened successfully", 100, 100)
    
    return [dork, dork_name, engine_name]

def main():
    boot()
    
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {C_PURPLE}]DORKING ENGINE[/]  [dim]//[/]  [white]OSINT SEARCH[/]  [dim]//[/]  [{C_PURPLE}]ADVANCED QUERY[/]"),
        border_style="#9B00FF", padding=(0, 6)
    )))
    console.print()
    
    console.print(f" [{C_PURPLE}]●[/] [white]Search Engines:[/]")
    console.print(f" [{C_PURPLE}]1[/] [white]Google[/]     [{C_PURPLE}]2[/] [white]Bing[/]     [{C_PURPLE}]3[/] [white]DuckDuckGo[/]")
    console.print()
    console.print(f" [{C_PURPLE}]●[/] [white]Dork Types:[/]")
    console.print(f" [{C_PURPLE}]1[/] [white]Title Search  [{C_PURPLE}]2[/] [white]URL Search   [{C_PURPLE}]3[/] [white]File Type (PDF)[/]")
    console.print(f" [{C_PURPLE}]4[/] [white]Site Search   [{C_PURPLE}]5[/] [white]Exact Match  [{C_PURPLE}]6[/] [white]Text Search[/]")
    console.print(f" [{C_PURPLE}]7[/] [white]Cache Search  [{C_PURPLE}]8[/] [white]Related Sites[/]")
    console.print()
    
    engine = console.input(f" [{C_PURPLE}]└─▶[/] [bold white]Select Engine (1-3) >> ").strip()
    
    if engine not in ["1", "2", "3"]:
        console.print(f"\n [{C_RED}][x][/] Invalid engine choice.")
        time.sleep(2)
        return
    
    dork_type = console.input(f" [{C_PURPLE}]└─▶[/] [bold white]Select Dork Type (1-8) >> ").strip()
    
    if dork_type not in ["1", "2", "3", "4", "5", "6", "7", "8"]:
        console.print(f"\n [{C_RED}][x][/] Invalid dork type.")
        time.sleep(2)
        return
    
    query = console.input(f" [{C_PURPLE}]└─▶[/] [bold white]Enter Target (domain/word) >> ").strip()
    
    if not query:
        console.print(f"\n [{C_RED}][x][/] No target provided.")
        time.sleep(2)
        return

    layout = make_layout()
    dork_result = []
    current_status = "Initializing..."
    progress_val = 0
    start_time = time.time()

    def update_view(status, progress, total):
        nonlocal current_status, progress_val
        current_status = status
        progress_val = progress

    async def scan_thread():
        nonlocal dork_result
        dork_result = await generate_dorks(query, engine, dork_type, update_view)

    loop_thread = threading.Thread(target=lambda: asyncio.run(scan_thread()), daemon=True)
    loop_thread.start()

    with Live(layout, refresh_per_second=10, screen=True) as live:
        while loop_thread.is_alive():
            layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {C_PURPLE}]DORK GENERATOR[/] [dim]||[/] [white]PROCESSING...[/]")), border_style="#9B00FF"))
            
            res_table = Table(box=box.SIMPLE, expand=True, show_header=True, header_style=f"bold {C_PURPLE}")
            res_table.add_column("DORK DATA", ratio=2)
            res_table.add_column("VALUE", ratio=1, justify="center")
            
            if dork_result:
                res_table.add_row("Query", f"[bold {C_OK}]{query}[/]")
                res_table.add_row("Dork Type", f"{dork_result[1]}")
                res_table.add_row("Engine", f"{dork_result[2]}")
                res_table.add_row("Dork String", f"{dork_result[0]}")
            
            layout["results"].update(Panel(res_table, title="[bold white]DORK CONFIGURATION", border_style="#9B00FF"))
            
            elapsed = time.time() - start_time
            stats_grp = Group(
                Text.from_markup(f"\n[{C_PURPLE}]TARGET :[/] [white]{query}"),
                Text.from_markup(f"[{C_PURPLE}]ENGINE :[/] [bold white]{dork_result[2] if dork_result else '...'}"),
                Text.from_markup(f"[{C_PURPLE}]TYPE   :[/] [white]{dork_result[1] if dork_result else '...'}"),
                Text.from_markup(f"[{C_PURPLE}]STATUS :[/] [white]{current_status}"),
                Text.from_markup(f"[{C_PURPLE}]ELAPSED:[/] [white]{int(elapsed)}s"),
                Text.from_markup(f"\n[{C_PURPLE}][bold]PROGRESS :[/] [white]{progress_val}%"),
            )
            layout["stats"].update(Panel(stats_grp, title="[bold white]LIVE STATS", border_style="#9B00FF"))
            
            layout["footer"].update(Panel(Align.center(Text.from_markup(f"[dim]DORKING QUERY ENGINE - OSINT SEARCH SYSTEM[/]")), border_style="#9B00FF"))
            time.sleep(0.1)

    os.system("cls")
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold green]DORK GENERATED SUCCESSFULLY"),
        border_style="green", box=box.HEAVY, padding=(1, 5)
    )))
    
    if dork_result:
        table = Table(title="[bold white]DORK SUMMARY", box=box.ROUNDED, border_style="green", expand=True)
        table.add_column("Property", style="white")
        table.add_column("Value", style="green", justify="center")
        table.add_row("Target", query)
        table.add_row("Dork Type", dork_result[1])
        table.add_row("Engine", dork_result[2])
        table.add_row("Dork String", f"[bold {C_CYAN}]{dork_result[0]}[/]")
        console.print(table)
        
        console.print(f"\n [{C_OK}]●[/] Search opened in browser!")
    else:
        console.print(f"\n [{C_RED}][!][/] Failed to generate dork.")

    console.input(f"\n [dim]Press [bold {C_PURPLE}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit()