#!/usr/bin/env python3
"""BND-NUKE - Launcher"""
import os
import sys
import subprocess

# Farben
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RESET = "\033[0m"

def main():
    print(f"\n{BLUE}[*] Starting BND-Nuke...{RESET}")
    
    # Suche nach der main.py oder void-nuke.py
    script_dir = os.path.dirname(__file__)
    
    # Versuche verschiedene mögliche Dateinamen
    possible_scripts = [
        os.path.join(script_dir, "main.py"),
        os.path.join(script_dir, "bnd-nuke.py"),
        os.path.join(script_dir, "void-nuke.py"),
        os.path.join(script_dir, "nuke.py"),
    ]
    
    for script in possible_scripts:
        if os.path.exists(script):
            print(f"{BLUE}[+] Found: {os.path.basename(script)}{RESET}")
            result = subprocess.call([sys.executable, script], cwd=script_dir)
            break
    else:
        print(f"{BLUE}[!] No nuke script found!{RESET}")
        print(f"{WHITE}Please create main.py or bnd-nuke.py{RESET}")
    
    input(f"\n{WHITE}Press Enter to continue...{RESET}")

if __name__ == "__main__":
    main()