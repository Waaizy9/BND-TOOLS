#!/usr/bin/env python3
"""Wallet Tracker - Track cryptocurrency wallet transactions"""

import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, threading, random, re
import subprocess
import json
import requests
from datetime import datetime
from rich.console import Console, Group  # <-- Group hier importieren!
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich import box
import webbrowser

console = Console()

# -- COLORS --
C_RED     = "#CC0000"
C_NEON    = "#FF2020"
C_WHITE   = "#FFFFFF"
C_SILVER  = "#CCCCCC"
C_DIM     = "#444444"
C_OK      = "#00FF00"
C_NO      = "#440000"
C_GOLD    = "#FFD700"
C_CYAN    = "#00FFFF"

ASCII = r"""
   ██╗    ██╗ █████╗ ██╗     ██╗     ███████╗████████╗
   ██║    ██║██╔══██╗██║     ██║     ██╔════╝╚══██╔══╝
   ██║ █╗ ██║███████║██║     ██║     █████╗     ██║   
   ██║███╗██║██╔══██║██║     ██║     ██╔══╝     ██║   
   ╚███╔███╔╝██║  ██║███████╗███████╗███████╗   ██║   
    ╚══╝╚══╝ ╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝   ╚═╝   
"""

SUBTITLE = " W A L L E T   T R A C K E R   //   C R Y P T O   I N T E L "

def boot():
    if sys.platform.startswith("win"):
        os.system("title WALLET TRACKER // CRYPTO OSINT")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(200 + 55 * math.sin(t * 10 - c * 0.2))))
                        sys.stdout.write(f"\033[38;2;{v};{int(v*0.3)};0m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  \033[38;2;255;200;50m{SUBTITLE}\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def make_layout():
    l = Layout()
    l.split_column(
        Layout(name="header", size=4),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    l["body"].split_row(
        Layout(name="results", ratio=2),
        Layout(name="stats", ratio=1)
    )
    return l

async def scan_wallet(address, currency, update_fn):
    """Scan wallet transactions"""
    found = []
    total = 0
    
    if currency.upper() == "BTC":
        try:
            update_fn("Fetching BTC blockchain data...", 0, 1)
            url = f"https://blockchain.info/rawaddr/{address}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                found = [data]
                update_fn("Data retrieved successfully", 1, 1)
            else:
                update_fn("Error fetching data", 0, 1)
        except Exception as e:
            update_fn(f"Error: {str(e)}", 0, 1)
    elif currency.upper() == "ETH":
        try:
            update_fn("Fetching ETH blockchain data...", 0, 1)
            url = f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data['status'] == '1':
                    found = [data]
                    update_fn("Data retrieved successfully", 1, 1)
                else:
                    update_fn("Error fetching data", 0, 1)
            else:
                update_fn("Error fetching data", 0, 1)
        except Exception as e:
            update_fn(f"Error: {str(e)}", 0, 1)
    else:
        update_fn(f"Support for {currency} coming soon!", 0, 1)
    
    return found

def main():
    boot()
    
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {C_GOLD}]WALLET TRACKER[/]  [dim]//[/]  [white]CRYPTO OSINT[/]  [dim]//[/]  [{C_GOLD}]ANALYZER[/]"),
        border_style="#FFD700", padding=(0, 6)
    )))
    console.print()
    
    console.print(f" [{C_GOLD}]●[/] [white]Supported Cryptocurrencies:[/]")
    console.print(f" [{C_GOLD}]1[/] [white]BTC (Bitcoin)[/]")
    console.print(f" [{C_GOLD}]2[/] [white]ETH (Ethereum)[/]")
    console.print(f" [{C_GOLD}]3[/] [white]SOL (Solana) - Coming Soon[/]")
    console.print()
    
    choice = console.input(f" [{C_GOLD}]└─▶[/] [bold white]Select Currency (1-3) >> ").strip()
    
    currency_map = {
        "1": "BTC",
        "2": "ETH",
        "3": "SOL"
    }
    
    if choice not in currency_map:
        console.print(f"\n [{C_RED}][x][/] Invalid choice.")
        time.sleep(2)
        return
    
    currency = currency_map[choice]
    address = console.input(f" [{C_GOLD}]└─▶[/] [bold white]Enter {currency} Address >> ").strip()
    
    if not address:
        console.print(f"\n [{C_RED}][x][/] No address provided.")
        time.sleep(2)
        return

    layout = make_layout()
    found_data = []
    current_status = "Initializing..."
    progress_val = 0
    total_val = 1
    start_time = time.time()

    def update_view(status, progress, total):
        nonlocal current_status, progress_val, total_val
        current_status = status
        progress_val = progress
        total_val = total

    async def scan_thread():
        nonlocal found_data
        found_data = await scan_wallet(address, currency, update_view)

    loop_thread = threading.Thread(target=lambda: asyncio.run(scan_thread()), daemon=True)
    loop_thread.start()

    with Live(layout, refresh_per_second=10, screen=True) as live:
        while loop_thread.is_alive():
            layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {C_GOLD}]WALLET SCANNER[/] [dim]||[/] [white]ANALYZING...[/]")), border_style="#FFD700"))
            
            res_table = Table(box=box.SIMPLE, expand=True, show_header=True, header_style=f"bold {C_GOLD}")
            res_table.add_column("DATA", ratio=2)
            res_table.add_column("VALUE", ratio=1, justify="center")
            
            if found_data:
                data = found_data[0]
                if currency == "BTC" and 'final_balance' in data:
                    balance = data.get('final_balance', 0) / 100000000
                    res_table.add_row("Balance", f"[bold {C_OK}]{balance:.8f} BTC[/]")
                    res_table.add_row("Total Received", f"{data.get('total_received', 0) / 100000000:.8f} BTC")
                    res_table.add_row("Total Sent", f"{data.get('total_sent', 0) / 100000000:.8f} BTC")
                    res_table.add_row("Transactions", f"{data.get('n_tx', 0)}")
                    if 'last_tx' in data:
                        last_tx = datetime.fromtimestamp(data['last_tx']).strftime('%Y-%m-%d %H:%M:%S')
                        res_table.add_row("Last Activity", last_tx)
                elif currency == "ETH" and 'result' in data:
                    balance = int(data['result']) / 1000000000000000000
                    res_table.add_row("Balance", f"[bold {C_OK}]{balance:.6f} ETH[/]")
                else:
                    res_table.add_row("No data", "Available")
            
            layout["results"].update(Panel(res_table, title=f"[bold white]{currency} WALLET DATA", border_style="#FFD700"))
            
            elapsed = time.time() - start_time
            stats_grp = Group(
                Text.from_markup(f"\n[{C_GOLD}]ADDRESS :[/] [white]{address[:20]}...{address[-8:]}"),
                Text.from_markup(f"[{C_GOLD}]CURRENCY:[/] [bold white]{currency}"),
                Text.from_markup(f"[{C_GOLD}]FOUND   :[/] [bold green]{len(found_data)}[/] records"),
                Text.from_markup(f"[{C_GOLD}]STATUS  :[/] [white]{current_status}"),
                Text.from_markup(f"[{C_GOLD}]ELAPSED :[/] [white]{int(elapsed)}s"),
                Text.from_markup(f"\n[{C_GOLD}][bold]PROGRESS :[/] [white]{int((progress_val/total_val)*100)}%"),
            )
            layout["stats"].update(Panel(stats_grp, title="[bold white]LIVE STATS", border_style="#FFD700"))
            
            layout["footer"].update(Panel(Align.center(Text.from_markup(f"[dim]WALLET TRACKER SYSTEM - SECURE ANALYSIS[/]")), border_style="#FFD700"))
            time.sleep(0.1)

    os.system("cls")
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold green]SCAN COMPLETED FOR {currency} WALLET"),
        border_style="green", box=box.HEAVY, padding=(1, 5)
    )))
    
    if found_data:
        table = Table(title=f"[bold white]{currency} WALLET INFORMATION", box=box.ROUNDED, border_style="green", expand=True)
        table.add_column("Property", style="white")
        table.add_column("Value", style="green", justify="center")
        
        data = found_data[0]
        if currency == "BTC":
            table.add_row("Address", address)
            table.add_row("Balance", f"{data.get('final_balance', 0) / 100000000:.8f} BTC")
            table.add_row("Total Received", f"{data.get('total_received', 0) / 100000000:.8f} BTC")
            table.add_row("Total Sent", f"{data.get('total_sent', 0) / 100000000:.8f} BTC")
            table.add_row("Transactions", f"{data.get('n_tx', 0)}")
        elif currency == "ETH":
            balance = int(data.get('result', 0)) / 1000000000000000000
            table.add_row("Address", address)
            table.add_row("Balance", f"{balance:.6f} ETH")
        
        console.print(table)
        
        explorers = {
            "BTC": f"https://www.blockchain.com/btc/address/{address}",
            "ETH": f"https://etherscan.io/address/{address}"
        }
        if currency in explorers:
            console.print(f"\n [{C_GOLD}]●[/] Opening {currency} explorer...")
            time.sleep(1)
            webbrowser.open(explorers[currency])
    else:
        console.print(f"\n [{C_RED}][!][/] No data available for this address.")

    console.input(f"\n [dim]Press [bold {C_GOLD}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit()