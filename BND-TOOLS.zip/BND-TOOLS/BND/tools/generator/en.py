import random
import string
import json
import requests
import os
import sys
import time
import re
from colorama import Fore, init

init(autoreset=True)

# BND-GEN Banner in Blau
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
DIM = "\033[90m"
RESET = "\033[0m"

BANNER = f"""
{BLUE}
  ██████╗ ███╗   ██╗██████╗     ██████╗ ███████╗███╗   ██╗
  ██╔══██╗████╗  ██║██╔══██╗    ██╔════╝ ██╔════╝████╗  ██║
  ██████╔╝██╔██╗ ██║██║  ██║    ██║  ███╗█████╗  ██╔██╗ ██║
  ██╔══██╗██║╚██╗██║██║  ██║    ██║   ██║██╔══╝  ██║╚██╗██║
  ██████╔╝██║ ╚████║██████╔╝    ╚██████╔╝███████╗██║ ╚████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝      ╚═════╝ ╚══════╝╚═╝  ╚═══╝
{RESET}
{WHITE} v1.0  |  by BND-Team{BLUE}                                                                             discord.gg/bnd{RESET}
{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}
"""

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear()
    print(BANNER)
    print()

def error_message(error):
    """Display an error message."""
    print(f"{RED}[!] Error: {error}{RESET}")

def verify_webhook(url):
    """Verify if the webhook is valid and send a test message."""
    try:
        response = requests.get(url)
        if response.status_code == 200:
            payload = {
                'content': f"""# BND-Giftcard-Gen

> __**Your webhook is working! You can start generating giftcards!**__

> https://discord.gg/bnd

> https://github.com/waaizy9/BND-TOOLS

> __Star for more features <3__

||@everyone||"""
            }
            headers = {'Content-Type': 'application/json'}
            requests.post(url, data=json.dumps(payload), headers=headers)
            return True
        else:
            error_message("Invalid Webhook URL")
            return False
    except requests.exceptions.RequestException as e:
        error_message(f"Error verifying webhook: {e}")
        return False

def send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar):
    """Send a notification to the webhook."""
    payload = {
        'embeds': [embed_content],
        'username': webhook_username,
        'avatar_url': webhook_avatar
    }
    headers = {'Content-Type': 'application/json'}
    try:
        requests.post(webhook_url, data=json.dumps(payload), headers=headers)
    except requests.exceptions.RequestException as e:
        error_message(f"Error sending to webhook: {e}")

# ============== AMAZON GIFT CARD FUNCTIONS ==============
def generate_amazon_code():
    """Generiert einen Amazon Giftcard Code"""
    formats = [
        lambda: ''.join(random.choices(string.digits, k=14)),
        lambda: ''.join(random.choices(string.digits, k=15)),
        lambda: ''.join(random.choices(string.digits, k=16)),
        lambda: '-'.join([''.join(random.choices(string.digits, k=4)) for _ in range(4)]),
        lambda: '-'.join([''.join(random.choices(string.digits, k=6)) for _ in range(3)]),
        lambda: ''.join(random.choices(string.ascii_uppercase + string.digits, k=16)),
        lambda: ''.join(random.choices(string.ascii_uppercase + string.digits, k=20)),
    ]
    return random.choice(formats)()

def verify_amazon_code(code, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Verifiziert einen Amazon Giftcard Code (simuliert)"""
    clean_code = re.sub(r'[^A-Z0-9]', '', code.upper())
    
    # Simulierte Validierung - 0.5% Trefferwahrscheinlichkeit
    if len(clean_code) >= 10 and len(clean_code) <= 20:
        if random.random() < 0.005:  # 0.5% Chance
            embed_content = {
                'title': '✅ Valid Amazon Gift Card!',
                'description': f"**__Code:__**\n```{code}```\n\n**__Value:__**\n```${random.randint(10, 100)}```",
                'color': webhook_color if webhook_color else 0x0000CD,
                'footer': {"text": "BND-Giftcard-Gen", "icon_url": "https://cdn.discordapp.com/embed/avatars/0.png"},
            }
            if webhook:
                send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar)
            return True, f"Valid Amazon Gift Card! Value: ${random.randint(10, 100)}"
    
    return False, "Invalid"

# ============== NETFLIX GIFT CARD FUNCTIONS ==============
def generate_netflix_code():
    """Generiert einen Netflix Giftcard Code"""
    formats = [
        lambda: ''.join(random.choices(string.digits, k=10)),
        lambda: ''.join(random.choices(string.digits, k=11)),
        lambda: ''.join(random.choices(string.digits, k=12)),
        lambda: '-'.join([''.join(random.choices(string.digits, k=4)) for _ in range(3)]),
        lambda: ''.join(random.choices(string.ascii_uppercase + string.digits, k=12)),
        lambda: ''.join(random.choices(string.ascii_uppercase + string.digits, k=16)),
    ]
    return random.choice(formats)()

def verify_netflix_code(code, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Verifiziert einen Netflix Giftcard Code (simuliert)"""
    clean_code = re.sub(r'[^A-Z0-9]', '', code.upper())
    
    # Simulierte Validierung - 0.5% Trefferwahrscheinlichkeit
    if len(clean_code) >= 8 and len(clean_code) <= 16:
        if random.random() < 0.005:  # 0.5% Chance
            embed_content = {
                'title': '✅ Valid Netflix Gift Card!',
                'description': f"**__Code:__**\n```{code}```\n\n**__Value:__**\n```${random.randint(10, 50)}```",
                'color': webhook_color if webhook_color else 0x0000CD,
                'footer': {"text": "BND-Giftcard-Gen", "icon_url": "https://cdn.discordapp.com/embed/avatars/0.png"},
            }
            if webhook:
                send_webhook(embed_content, webhook_url, webhook_username, webhook_avatar)
            return True, f"Valid Netflix Gift Card! Value: ${random.randint(10, 50)}"
    
    return False, "Invalid"

# ============== GENERATOR FUNCTIONS ==============
def generate_giftcards(platform, num_codes, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Generiert Giftcard Codes bis ein gültiger gefunden wurde"""
    valid_codes = []
    invalid_codes = []
    attempts = 0
    
    platform_name = "Amazon" if platform == "amazon" else "Netflix"
    generate_func = generate_amazon_code if platform == "amazon" else generate_netflix_code
    verify_func = verify_amazon_code if platform == "amazon" else verify_netflix_code
    
    print(f"\n{BLUE}[>] Starting {platform_name} Giftcard Generator...{RESET}")
    print(f"{DIM}Generating until valid code found (max {num_codes} attempts)...{RESET}\n")
    
    while attempts < num_codes:
        attempts += 1
        code = generate_func()
        
        is_valid, msg = verify_func(code, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        
        if is_valid:
            valid_codes.append(code)
            print(f"{GREEN}[{attempts}/{num_codes}] ✓ VALID | {code} - {msg}{RESET}")
            break
        else:
            invalid_codes.append(code)
            if attempts % 10 == 0:
                print(f"{RED}[{attempts}/{num_codes}] ✗ {msg} | {code}{RESET}")
            else:
                print(f"{DIM}[{attempts}/{num_codes}] ✗ {msg} | {code}{RESET}")
        
        if attempts < num_codes:
            time.sleep(0.1)  # Protection gegen Rate-Limits
    
    # Summary
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}┌──{BLUE} GENERATION SUMMARY{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Platform:{RESET} {CYAN}{platform_name}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Total attempts:{RESET} {CYAN}{attempts}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Valid codes:{RESET} {GREEN}{len(valid_codes)}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Invalid codes:{RESET} {RED}{len(invalid_codes)}{RESET}")
    print(f"{BLUE}└──{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    
    # Save valid codes
    if valid_codes:
        save = input(f"\n{BLUE}[?]{RESET} {WHITE}Save valid code to file? (y/n): {RESET}").strip().lower()
        if save in ('y', 'yes'):
            out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "BND - Output")
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            out_file = os.path.join(out_dir, f"{platform_name.lower()}_valid.txt")
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(f"{platform_name} Gift Card\n")
                f.write(f"Code: {valid_codes[0]}\n")
                f.write(f"Attempts: {attempts}\n")
                f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            print(f"{GREEN}[+] Saved to: {out_file}{RESET}")

def generate_both_giftcards(num_codes, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color):
    """Generiert sowohl Amazon als auch Netflix Codes"""
    results = {}
    
    # Amazon
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}┌──{BLUE} AMAZON GIFT CARD GENERATOR{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}└──{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    
    amazon_valid = []
    amazon_attempts = 0
    
    while amazon_attempts < num_codes:
        amazon_attempts += 1
        code = generate_amazon_code()
        is_valid, msg = verify_amazon_code(code, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        
        if is_valid:
            amazon_valid.append(code)
            print(f"{GREEN}[{amazon_attempts}/{num_codes}] ✓ VALID AMAZON | {code}{RESET}")
            break
        else:
            if amazon_attempts % 10 == 0:
                print(f"{RED}[{amazon_attempts}/{num_codes}] ✗ AMAZON | {code}{RESET}")
            else:
                print(f"{DIM}[{amazon_attempts}/{num_codes}] ✗ AMAZON | {code}{RESET}")
        
        if amazon_attempts < num_codes:
            time.sleep(0.1)
    
    # Netflix
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}┌──{BLUE} NETFLIX GIFT CARD GENERATOR{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}└──{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    
    netflix_valid = []
    netflix_attempts = 0
    
    while netflix_attempts < num_codes:
        netflix_attempts += 1
        code = generate_netflix_code()
        is_valid, msg = verify_netflix_code(code, webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        
        if is_valid:
            netflix_valid.append(code)
            print(f"{GREEN}[{netflix_attempts}/{num_codes}] ✓ VALID NETFLIX | {code}{RESET}")
            break
        else:
            if netflix_attempts % 10 == 0:
                print(f"{RED}[{netflix_attempts}/{num_codes}] ✗ NETFLIX | {code}{RESET}")
            else:
                print(f"{DIM}[{netflix_attempts}/{num_codes}] ✗ NETFLIX | {code}{RESET}")
        
        if netflix_attempts < num_codes:
            time.sleep(0.1)
    
    # Summary
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}┌──{BLUE} GENERATION SUMMARY{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Amazon attempts:{RESET} {CYAN}{amazon_attempts}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Amazon valid:{RESET} {GREEN}{len(amazon_valid)}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Netflix attempts:{RESET} {CYAN}{netflix_attempts}{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}Netflix valid:{RESET} {GREEN}{len(netflix_valid)}{RESET}")
    print(f"{BLUE}└──{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    
    # Save both
    if amazon_valid and netflix_valid:
        save = input(f"\n{BLUE}[?]{RESET} {WHITE}Save valid codes to file? (y/n): {RESET}").strip().lower()
        if save in ('y', 'yes'):
            out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "BND - Output")
            if not os.path.exists(out_dir):
                os.makedirs(out_dir)
            out_file = os.path.join(out_dir, "giftcards_valid.txt")
            with open(out_file, "w", encoding="utf-8") as f:
                f.write(f"Amazon Gift Card\n")
                f.write(f"Code: {amazon_valid[0]}\n")
                f.write(f"Attempts: {amazon_attempts}\n\n")
                f.write(f"Netflix Gift Card\n")
                f.write(f"Code: {netflix_valid[0]}\n")
                f.write(f"Attempts: {netflix_attempts}\n")
                f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            print(f"{GREEN}[+] Saved to: {out_file}{RESET}")

# ============== MAIN MENU ==============
def main():
    print_header()
    
    print(f"{BLUE}┌──{BLUE} GIFT CARD GENERATOR{RESET}")
    print(f"{BLUE}│{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}01{RESET} - {WHITE}Amazon Gift Cards{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}02{RESET} - {WHITE}Netflix Gift Cards{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}03{RESET} - {WHITE}Both (Amazon + Netflix){RESET}")
    print(f"{BLUE}└──{RESET}")
    print()
    
    try:
        choice = input(f"{BLUE}[?]{RESET} {WHITE}Select option (1-3): {RESET}").strip()
        
        use_webhook = input(f"{BLUE}[?]{RESET} {WHITE}Use a Webhook? (y/n): {RESET}").strip().lower() in ['y', 'yes']
        
        if use_webhook:
            webhook_url = input(f"{BLUE}[?]{RESET} {WHITE}Webhook URL: {RESET}").strip()
            if not verify_webhook(webhook_url):
                input(f"\n{WHITE}Press Enter to continue...{RESET}")
                return
            webhook_username = "BND-Giftcard-Gen"
            webhook_avatar = "https://cdn.discordapp.com/embed/avatars/0.png"
            webhook_color = 0x0000CD  # Blau
        else:
            webhook_url = webhook_username = webhook_avatar = webhook_color = None
        
        max_attempts = int(input(f"{BLUE}[?]{RESET} {WHITE}Max attempts per platform: {RESET}").strip())
        max_attempts = max(1, min(max_attempts, 10000))  # Max 10000 attempts

    except Exception as e:
        error_message(e)
        input(f"\n{WHITE}Press Enter to continue...{RESET}")
        return

    try:
        if choice == "1":
            generate_giftcards("amazon", max_attempts, use_webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        elif choice == "2":
            generate_giftcards("netflix", max_attempts, use_webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        elif choice == "3":
            generate_both_giftcards(max_attempts, use_webhook, webhook_url, webhook_username, webhook_avatar, webhook_color)
        else:
            error_message("Invalid option!")
    except Exception as e:
        error_message(e)
    
    print()
    input(f"{WHITE}Press Enter to exit...{RESET}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Aborted!{RESET}")
        input("\nPress Enter to exit...")