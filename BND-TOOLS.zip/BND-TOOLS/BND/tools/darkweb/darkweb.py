#!/usr/bin/env python3
"""BND-TOOLS - Darkweb Links"""

import os
import sys
import time
import webbrowser

BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
DIM = "\033[90m"
RESET = "\033[0m"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear()
    print(f"{BLUE}")
    print("  ██████╗ ███╗   ██╗██████╗     ██████╗ █████╗ ██████╗ ██╗  ██╗██╗    ██╗███████╗██████╗ ")
    print("  ██╔══██╗████╗  ██║██╔══██╗    ██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝██║    ██║██╔════╝██╔══██╗")
    print("  ██║  ██║██╔██╗ ██║██║  ██║    ██║  ██║███████║██████╔╝█████╔╝ ██║ █╗ ██║█████╗  ██████╔╝")
    print("  ██║  ██║██║╚██╗██║██║  ██║    ██║  ██║██╔══██║██╔══██╗██╔═██╗ ██║███╗██║██╔══╝  ██╔══██╗")
    print("  ██████╔╝██║ ╚████║██████╔╝    ██████╔╝██║  ██║██║  ██║██║  ██╗╚███╔███╔╝███████╗██████╔╝")
    print("  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚══╝╚══╝ ╚══════╝╚═════╝ ")
    print(f"{RESET}")
    print(f"{WHITE} v1.0  |  by BND-Team{BLUE}                                                                             discord.gg/bnd{RESET}")
    print(f"{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}")
    print()

def print_status(message, status="info"):
    symbols = {"info": "*", "success": "+", "error": "!", "loading": ">"}
    colors = {"info": WHITE, "success": GREEN, "error": RED, "loading": CYAN}
    print(f"{colors.get(status, WHITE)}[{symbols.get(status, '*')}] {message}{RESET}")

# Darkweb Links (Tor Links - benötigen Tor Browser)
DARKWEB_LINKS = {
    "1": {
        "name": "Hidden Wiki",
        "url": "http://zqktlwiuavvvqqt4ybvgvi7tyo4hjl5xgfuvpdf6otjiycgwqbym2qad.onion",
        "desc": "Das bekannteste Darkweb Verzeichnis"
    },
    "2": {
        "name": "DuckDuckGo (Tor)",
        "url": "https://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion",
        "desc": "Suchmaschine für das Darkweb"
    },
    "3": {
        "name": "ProPublica",
        "url": "https://www.propub3r6espa33w.onion",
        "desc": "Investigativer Journalismus"
    },
    "4": {
        "name": "Facebook (Tor)",
        "url": "https://www.facebookwkhpilnemxj7asaniu7vnjjbiltxjqhye3mhbshg7kx5tfyd.onion",
        "desc": "Facebook über Tor"
    },
    "5": {
        "name": "BBC (Tor)",
        "url": "https://www.bbcnewsv2vjtpsuy.onion",
        "desc": "BBC News Darkweb Version"
    },
    "6": {
        "name": "The New York Times",
        "url": "https://www.nytimes3xbfgragh.onion",
        "desc": "NY Times Darkweb Version"
    },
    "7": {
        "name": "SecureDrop",
        "url": "http://sdolvtfhatvsysc6l34d65ymdwxcujausv7k5jk4cy5ttzhjoi6fzvyd.onion",
        "desc": "Whistleblower Plattform"
    },
    "8": {
        "name": "Tor Metrics",
        "url": "https://metrics.torproject.org",
        "desc": "Tor Netzwerk Statistiken"
    },
    "9": {
        "name": "OnionShare",
        "url": "http://elx57ue5uyfplgva.onion",
        "desc": "Sichere Dateiübertragung"
    }
}

def darkweb_menu():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} DARKWEB LINKS{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Links funktionieren nur mit Tor Browser!{RESET}
""")
    
    print(f"\n{BLUE}┌──{BLUE} VERFÜGBARE LINKS{RESET}")
    for key, link in DARKWEB_LINKS.items():
        print(f"{BLUE}├──{RESET} {WHITE}{key}. {CYAN}{link['name']}{RESET}")
        print(f"{BLUE}│   {RESET}{DIM}   {link['desc']}{RESET}")
    print(f"{BLUE}├──{RESET}")
    print(f"{BLUE}├──{RESET} {WHITE}0. Zurück{RESET}")
    print(f"{BLUE}└──{RESET}")
    print()

def open_link(url, name):
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} ÖFFNE LINK{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Öffne {name}{RESET}
""")
    print(f"\n{BLUE}[>] Öffne in Browser...{RESET}")
    
    try:
        webbrowser.open(url)
        print_status(f"Geöffnet: {url}", "success")
    except Exception as e:
        print_status(f"Fehler: {e}", "error")
    
    print(f"\n{WHITE}Hinweis: Darkweb Links funktionieren nur mit Tor Browser!{RESET}")
    print(f"{DIM}Tor Browser Download: https://www.torproject.org/{RESET}")
    print()
    input(f"{WHITE}Press Enter to continue...{RESET}")

def main():
    while True:
        darkweb_menu()
        choice = input(f" {BLUE}└─>>{RESET} {WHITE}").strip()
        
        if choice == "0":
            break
        elif choice in DARKWEB_LINKS:
            open_link(DARKWEB_LINKS[choice]["url"], DARKWEB_LINKS[choice]["name"])
        else:
            print_status("Ungültige Auswahl!", "error")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Abgebrochen!{RESET}")