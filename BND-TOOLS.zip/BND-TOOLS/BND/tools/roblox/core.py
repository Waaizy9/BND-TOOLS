#!/usr/bin/env python3
"""BND-TOOLS - Roblox Tools"""

import sys, json, os, webbrowser, shutil, time
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import urllib.request
import urllib.error
import requests

# Farben
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
DIM = "\033[90m"
RESET = "\033[0m"

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    clear()
    print(f"{BLUE}")
    print("  ██████╗ ███╗   ██╗██████╗     ██████╗  ██████╗ ██████╗ ██╗      ██████╗ ██╗  ██╗")
    print("  ██╔══██╗████╗  ██║██╔══██╗    ██╔══██╗██╔═══██╗██╔══██╗██║     ██╔═══██╗██║  ██║")
    print("  ██████╔╝██╔██╗ ██║██║  ██║    ██████╔╝██║   ██║██████╔╝██║     ██║   ██║███████║")
    print("  ██╔══██╗██║╚██╗██║██║  ██║    ██╔══██╗██║   ██║██╔══██╗██║     ██║   ██║██╔══██║")
    print("  ██████╔╝██║ ╚████║██████╔╝    ██████╔╝╚██████╔╝██║  ██║███████╗╚██████╔╝██║  ██║")
    print("  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝")
    print(f"{RESET}")
    print(f"{WHITE} v1.0  |  by BND-Team{BLUE}                                                                             discord.gg/bnd{RESET}")
    print(f"{DIM}──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────{RESET}")
    print()

def print_status(message, status="info"):
    symbols = {"info": "*", "success": "+", "error": "!", "loading": ">"}
    colors = {"info": WHITE, "success": GREEN, "error": RED, "loading": CYAN}
    print(f"{colors.get(status, WHITE)}[{symbols.get(status, '*')}] {message}{RESET}")

def _tw():
    return max(52, min(70, shutil.get_terminal_size((80, 24)).columns - 4))

def _ask(prompt: str) -> str:
    return input(f"\n {BLUE}└─>>{RESET} {WHITE}{prompt}{RESET} ").strip()

def _pause():
    print()
    input(f"{WHITE}Press Enter...{RESET}")

def _norm_cookie(raw: str) -> str:
    raw = raw.strip()
    if raw.lower().startswith(".roblosecurity="):
        raw = raw.split("=", 1)[1].strip()
    return raw

def _parse_json(raw: bytes):
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}

def _as_dict(data):
    return data if isinstance(data, dict) else {}

def _rbx(method: str, url: str, cookie: str = None, body: dict = None, timeout: int = 12):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Accept": "application/json"}
    if cookie:
        headers["Cookie"] = f".ROBLOSECURITY={_norm_cookie(cookie)}"
    data = json.dumps(body).encode() if body is not None else None
    if body is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, _parse_json(r.read())
    except urllib.error.HTTPError as e:
        return e.code, _parse_json(e.read())
    except Exception as ex:
        return 0, {"error": str(ex)}

def _auth_user(cookie: str):
    code, data = _rbx("GET", "https://users.roblox.com/v1/users/authenticated", cookie=cookie)
    data = _as_dict(data)
    if code == 200 and data.get("id"):
        return data
    return None

def _show_table(title: str, rows: list):
    print(f"""
 {BLUE}┌──{BLUE} {title}{RESET}
 {BLUE}│{RESET}""")
    for k, v in rows:
        print(f" {BLUE}├──{RESET} {WHITE}{k}:{RESET} {CYAN}{v}{RESET}")
    print(f" {BLUE}└──{RESET}")

# ============== TOOLS ==============

def cookie_checker():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} COOKIE CHECKER{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Überprüft einen Roblox Cookie{RESET}
""")
    cookie = _ask("Roblox Cookie (.ROBLOSECURITY):")
    if not cookie:
        return
    print_status("Prüfe Cookie...", "loading")
    user = _auth_user(cookie)
    if not user:
        print_status("Cookie ungültig!", "error")
        _pause()
        return
    uid = user["id"]
    c_rbx, robux = _rbx("GET", f"https://economy.roblox.com/v1/users/{uid}/currency", cookie=cookie)
    robux_val = robux.get("robux", "?") if c_rbx == 200 else "?"
    print(f"""
 {BLUE}┌──{BLUE} COOKIE ERGEBNIS{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {GREEN}✓ COOKIE GÜLTIG{RESET}
 {BLUE}├──{RESET} {WHITE}Benutzername:{RESET} {CYAN}{user.get('name', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}User ID:{RESET} {CYAN}{uid}{RESET}
 {BLUE}├──{RESET} {WHITE}Display Name:{RESET} {CYAN}{user.get('displayName', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Robux:{RESET} {CYAN}{robux_val}{RESET}
 {BLUE}├──{RESET} {WHITE}Profil:{RESET} {CYAN}https://www.roblox.com/users/{uid}/profile{RESET}
 {BLUE}└──{RESET}
""")
    _pause()

def username_lookup():
    print_header()
    print(f"""
 {BLUE}┌──{BLUE} USERNAME LOOKUP{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET} {WHITE}Zeigt Informationen zu einem Roblox Benutzername{RESET}
""")
    query = _ask("Benutzername oder User ID:")
    if not query:
        return
    print_status("Suche Benutzer...", "loading")
    
    if query.isdigit():
        code, data = _rbx("GET", f"https://users.roblox.com/v1/users/{query}")
        if code == 200:
            user = _as_dict(data)
        else:
            user = None
    else:
        code, data = _rbx("POST", "https://users.roblox.com/v1/usernames/users",
                          body={"usernames": [query], "excludeBannedUsers": False})
        data = _as_dict(data)
        if code == 200 and data.get("data"):
            u = data["data"][0]
            code2, full = _rbx("GET", f"https://users.roblox.com/v1/users/{u['id']}")
            user = _as_dict(full) if code2 == 200 else None
        else:
            user = None
    
    if not user:
        print_status("Benutzer nicht gefunden!", "error")
        _pause()
        return
    
    uid = user["id"]
    c_fr, friends = _rbx("GET", f"https://friends.roblox.com/v1/users/{uid}/friends/count")
    friends_count = friends.get("count", "?") if c_fr == 200 else "?"
    
    print(f"""
 {BLUE}┌──{BLUE} BENUTZER INFO{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}Benutzername:{RESET} {CYAN}{user.get('name', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}User ID:{RESET} {CYAN}{uid}{RESET}
 {BLUE}├──{RESET} {WHITE}Display Name:{RESET} {CYAN}{user.get('displayName', '?')}{RESET}
 {BLUE}├──{RESET} {WHITE}Erstellt:{RESET} {CYAN}{user.get('created', '?')[:10]}{RESET}
 {BLUE}├──{RESET} {WHITE}Freunde:{RESET} {CYAN}{friends_count}{RESET}
 {BLUE}├──{RESET} {WHITE}Verifiziert:{RESET} {CYAN}{'Ja' if user.get('hasVerifiedBadge') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Gebannt:{RESET} {CYAN}{'Ja' if user.get('isBanned') else 'Nein'}{RESET}
 {BLUE}├──{RESET} {WHITE}Profil:{RESET} {CYAN}https://www.roblox.com/users/{uid}/profile{RESET}
 {BLUE}└──{RESET}
""")
    _pause()

def main():
    while True:
        print_header()
        print(f"""
 {BLUE}┌──{BLUE} ROBLOX TOOLS{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}1. Cookie Checker{RESET}
 {BLUE}├──{RESET} {WHITE}2. Username Lookup{RESET}
 {BLUE}│{RESET}
 {BLUE}├──{RESET} {WHITE}0. Zurück{RESET}
 {BLUE}│{RESET}
 {BLUE}└──{RESET}
""")
        choice = input(f" {BLUE}└─>>{RESET} {WHITE}").strip()
        
        if choice in ("0", "00", "q", "Q"):
            break
        elif choice in ("1", "01"):
            cookie_checker()
        elif choice in ("2", "02"):
            username_lookup()
        else:
            print_status("Ungültige Auswahl!", "error")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{RED}[!] Abgebrochen!{RESET}")