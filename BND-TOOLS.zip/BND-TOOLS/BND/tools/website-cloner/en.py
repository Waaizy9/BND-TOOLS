import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math
import requests
from urllib.parse import urlparse
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()
TIMEOUT = 10

# BND-WEB Banner in Blau
ASCII = r"""
  ██████╗ ███╗   ██╗██████╗     ██╗    ██╗███████╗██████╗ 
  ██╔══██╗████╗  ██║██╔══██╗    ██║    ██║██╔════╝██╔══██╗
  ██████╔╝██╔██╗ ██║██║  ██║    ██║ █╗ ██║█████╗  ██████╔╝
  ██╔══██╗██║╚██╗██║██║  ██║    ██║███╗██║██╔══╝  ██╔══██╗
  ██████╔╝██║ ╚████║██████╔╝    ╚███╔███╔╝███████╗██████╔╝
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝     ╚══╝╚══╝ ╚══════╝╚═════╝ 
"""

SUBTITLE = "B N D - W E B   -   W E B P A G E   S O U R C E   C L O N E R"

# Farben
BLUE = "\033[38;2;0;0;205m"
WHITE = "\033[97m"
RED = "\033[91m"
GREEN = "\033[92m"
CYAN = "\033[96m"
DIM = "\033[90m"
RESET = "\033[0m"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-WEB // WEB CLONER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        v = max(40, min(255, int(100 + 155 * math.sin(t * 10 - c * 0.2))))
                        sys.stdout.write(f"\033[38;2;0;0;{v}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {BLUE}{SUBTITLE}{RESET}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

if __name__ == "__main__":
    try:
        boot()

        console.print(Align.center(Panel(
            Text.from_markup("[bold blue]BND-WEB[/]  [dim]//[/]  [white]WEB CLONER[/]  [dim]//[/]  [blue]SOURCE CLONE[/]"),
            border_style="blue", padding=(0, 6)
        )))
        console.print()

        console.print(" [blue]┌─[[/][bold white] Target URL (e.g., https://site.com) [/][blue]][/]")
        target = console.input(" [blue]└─▶[/] [bold white]").strip()

        if not target:
            sys.exit(0)
        if not target.startswith("http"):
            target = "https://" + target

        domain = urlparse(target).netloc or "unknown_site"
        domain = domain.replace("www.", "")

        out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "BND - Output")
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)

        out_file = os.path.join(out_dir, f"{domain}_clone.html")

        console.print()
        with Progress(
            SpinnerColumn(spinner_name="point", style="blue"),
            TextColumn("[dim white]{task.description}"),
            console=console, transient=True,
        ) as p:
            p.add_task("Cloning webpage in progress...", total=None)
            
            try:
                r = requests.get(target, headers={"User-Agent": UA}, timeout=TIMEOUT)
                r.raise_for_status()
                html = r.text
                
                with open(out_file, "w", encoding="utf-8") as f:
                    f.write(html)
                success = True
            except Exception as e:
                success = False
                error_msg = str(e)

        if success:
            console.print(f" [bold green][✓][/] Source code successfully cloned.")
            console.print(f" [dim]File saved to :[/] [white]{out_file}[/]")
            
            css_count = html.count("stylesheet")
            js_count = html.count("<script")
            console.print(f"\n [dim]Statistics : {len(html)} characters, {css_count} CSS links, {js_count} script tags.[/]")
        else:
            console.print(f" [bold red][x] Cloning failed :[/] {error_msg}")

        console.print()
        print(f"\n{BLUE}{'='*60}{RESET}")
        print(f"{WHITE} Cloning completed! Press Enter to close...{RESET}")
        input()

    except (KeyboardInterrupt, EOFError):
        print(f"\n{RED}[!] Aborted!{RESET}")
        input("\nPress Enter to exit...")