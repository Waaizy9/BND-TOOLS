import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, threading, zipfile, random, json
from concurrent.futures import ThreadPoolExecutor

_VOID = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..'))
if _VOID not in sys.path:
    sys.path.insert(0, _VOID)

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except:
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

from lib import constants as C
from lib.void_common import open_premium_links

try:
    import pyzipper
except ImportError:
    pyzipper = None

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich import box

try:
    from tkinter import Tk, filedialog
    TK_AVAILABLE = True
except ImportError:
    TK_AVAILABLE = False

console = Console()

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

SUBTITLE = f"{CURRENT_COLOR} B N D   Z I P   -   B R U T E F O R C E   S Y S T E M   V 2 {RESET}"

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // ZIP CRACKER")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.write(f"\n  {SUBTITLE}\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

def ask_file():
    if TK_AVAILABLE and os.name == 'nt':
        try:
            root = Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            f = filedialog.askopenfilename(
                title="BND-TOOLS - Select ZIP file",
                filetypes=[("ZIP Archives", "*.zip"), ("All files", "*.*")]
            )
            root.destroy()
            return f
        except Exception:
            pass
    console.print(f"\n [{CURRENT_HEX}]┌─[[/][bold white] Target file path (.zip) [/][{CURRENT_HEX}]][/]")
    return console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip().strip('"')

password_found = None
stop_search = threading.Event()
stats = {"tested": 0, "speed": 0, "start_time": 0, "current_pwd": "..."}

def crack_worker(filepath, ext, passwords_chunk, progress, task):
    global password_found
    if stop_search.is_set(): return
    
    batch = 0
    try:
        _zf_class = pyzipper.AESZipFile if pyzipper else zipfile.ZipFile
        with _zf_class(filepath, 'r') as zf:
            filename = zf.namelist()[0]
            for pwd in passwords_chunk:
                if stop_search.is_set(): break
                try:
                    stats["current_pwd"] = pwd
                    with zf.open(filename, 'r', pwd=pwd.encode('utf-8', errors='ignore')) as f:
                        f.read(16)
                    password_found = pwd
                    stop_search.set()
                    progress.update(task, advance=batch+1, current=pwd[:15])
                    return
                except Exception:
                    batch += 1
                    stats["tested"] += 1
                    if batch >= 50:
                        progress.update(task, advance=batch, current=pwd[:15])
                        batch = 0
                        elapsed = time.time() - stats["start_time"]
                        if elapsed > 0:
                            stats["speed"] = stats["tested"] / elapsed
    except: pass
    if batch > 0 and not stop_search.is_set():
        progress.update(task, advance=batch, current="...")

def make_layout():
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    layout["body"].split_row(
        Layout(name="main_crack", ratio=3),
        Layout(name="sidebar", ratio=1)
    )
    return layout

def premium_screen():
    os.system("cls")
    with Progress(
        SpinnerColumn(spinner_name="dots2", style=CURRENT_HEX),
        TextColumn(f"[bold {CURRENT_HEX}]SCANNING FOR LICENSE..."),
        console=console, transient=True
    ) as p:
        p.add_task("", total=None)
        time.sleep(2)
        
    console.print("\n" * 2)
    pnl = Panel(
        Align.center(Group(
            Text.from_markup(f"\n[bold {CURRENT_HEX}]ACCESS REJECTED ![/]"),
            Text.from_markup(f"\n[white]The [bold {CURRENT_HEX}]ZIP CRACKER[/] module requires an active\n[bold {CURRENT_HEX}]BND PREMIUM[/] license."),
            Text.from_markup(f"\n[dim]Shop · Discord[/]"),
            Text.from_markup(f"\n[bold #5865F2]{C.SHOP}[/]"),
            Text.from_markup(f"\n[dim #5865F2]{C.DISCORD}[/]"),
            Text.from_markup(f"\n[dim white]Opening shop + Discord...[/]")
        )),
        border_style=CURRENT_HEX, box=box.DOUBLE_EDGE, padding=(1, 5), title=f"[bold {CURRENT_HEX}]LICENSE_MISSING_ERROR[/]"
    )
    console.print(Align.center(pnl))
    open_premium_links()
    console.print("\n")
    console.input(Align.center(f" [dim]Press [bold {CURRENT_HEX}]ENTER[/] to return to menu...[/]"))

def main():
    boot()
    
    console.print(Align.center(Panel(
        Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/]  [dim]//[/]  [white]BRUTEFORCE ENGINE[/]  [dim]//[/]  [{CURRENT_HEX}]ZIP CRACKER[/]"),
        border_style=CURRENT_HEX, padding=(0, 6)
    )))
    console.print()
    
    filepath = ask_file()
    if not filepath or not os.path.exists(filepath):
        console.print(f"\n [{CURRENT_HEX}][x][/] No file selected.")
        time.sleep(2)
        return
        
    console.print(f"\n [dim]Target:[/] [bold white]{os.path.basename(filepath)}[/]")
    console.print(Panel(
        Group(
            Text.from_markup(f" [{CURRENT_HEX}]01  » [/][bold white]Dictionary Attack (Combolist)"),
            Text.from_markup(f" [{CURRENT_HEX}]02  » [/][bold white]Random Bruteforce"),
            Text.from_markup(f" [{CURRENT_HEX}]07  » [/][bold {CURRENT_HEX}]RAR Cracker [PREMIUM]")
        ),
        title=f"[bold {CURRENT_HEX}]ATTACK MODULES[/]", border_style=CURRENT_HEX, box=box.ROUNDED, padding=(1, 2)
    ))
    
    choice = console.input(f"\n [{CURRENT_HEX}]└─▶[/] [bold white]choice >> ").strip()
    
    if choice == "7":
        premium_screen()
        return

    if choice == "1":
        script_dir = os.path.dirname(os.path.abspath(__file__))
        combolist_dir = os.path.abspath(os.path.join(script_dir, "..", "..", "..", "BND - Input", "Combolist"))
        
        if not os.path.exists(combolist_dir):
            console.print(f"\n [{CURRENT_HEX}][x][/] Combolist directory not found.")
            return
            
        passwords = set()
        for f_name in os.listdir(combolist_dir):
            file_path = os.path.join(combolist_dir, f_name)
            if os.path.isfile(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        for line in f:
                            if line.strip(): passwords.add(line.strip())
                except: pass
        passwords = list(passwords)
            
        if not passwords:
            console.print(f"\n [{CURRENT_HEX}][x][/] No password list loaded.")
            return
            
        console.print(f"\n [{CURRENT_HEX}][✓][/] {len(passwords)} passwords loaded.")
        
        default_threads = min(32, (os.cpu_count() or 4) + 4)
        console.print(f" [{CURRENT_HEX}]┌─[[/][bold white] Threads (1-100) [/][{CURRENT_HEX}]][/] [dim](Default: {default_threads})[/]")
        t_input = console.input(f" [{CURRENT_HEX}]└─▶[/] [bold white]").strip()
        try:
            workers = int(t_input)
            workers = max(1, min(100, workers))
        except ValueError:
            workers = default_threads

        chunk_size = 2000
        chunks = [passwords[i:i + chunk_size] for i in range(0, len(passwords), chunk_size)]
        
        global password_found
        password_found = None
        stop_search.clear()
        stats["tested"] = 0
        stats["start_time"] = time.time()

        layout = make_layout()
        
        with Progress(
            SpinnerColumn(spinner_name="point", style=CURRENT_HEX),
            TextColumn(f"[bold white]Cracking...[/] [bold {CURRENT_HEX}]{{task.percentage:>3.0f}}%"),
            BarColumn(complete_style=CURRENT_HEX, bar_width=None),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task = progress.add_task("crack", total=len(passwords), current="...")
            
            with Live(layout, refresh_per_second=10, screen=True) as live:
                with ThreadPoolExecutor(max_workers=workers) as executor:
                    futures = []
                    for chunk in chunks:
                        if stop_search.is_set(): break
                        futures.append(executor.submit(crack_worker, filepath, ".zip", chunk, progress, task))
                    
                    while any(not f.done() for f in futures) and not stop_search.is_set():
                        layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {CURRENT_HEX}]BND-ZIP ENGINE[/] [dim]||[/] [white]DICTIONARY ATTACK[/]")), border_style=CURRENT_HEX))
                        
                        main_body = Table.grid(expand=True)
                        main_body.add_row(progress)
                        layout["main_crack"].update(Panel(main_body, title="[bold white]PROCESSOR", border_style=CURRENT_HEX, padding=(2, 2)))
                        
                        side_table = Table.grid(expand=True)
                        side_table.add_row(Text.from_markup(f"[{CURRENT_HEX}]THREADS:[/] [white]{workers}"))
                        side_table.add_row(Text.from_markup(f"[{CURRENT_HEX}]TESTED :[/] [white]{stats['tested']}"))
                        side_table.add_row(Text.from_markup(f"[{CURRENT_HEX}]SPEED  :[/] [white]{int(stats['speed'])} p/s"))
                        side_table.add_row(Text.from_markup(f"\n[dim]CURRENT:[/]\n[bold silver]{stats['current_pwd'][:15]}..."))
                        layout["sidebar"].update(Panel(side_table, title="[bold white]STATS", border_style=CURRENT_HEX, padding=(1, 1)))
                        
                        layout["footer"].update(Panel(Align.center(Text.from_markup(f"[dim]SYSTEM RUNNING - BND PRIME V2[/]")), border_style=CURRENT_HEX))
                        time.sleep(0.1)

                    for f in futures:
                        if stop_search.is_set(): f.cancel()
    
    elif choice == "2":
        console.print(f"\n [{CURRENT_HEX}][!][/] Feature currently unavailable.")
        time.sleep(2)
        return
    else: return
        
    console.print()
    if password_found:
        console.print(Panel(
            Align.center(Text.from_markup(f"[bold green]SUCCESS: PASSWORD CAPTURED[white]\n\n[bold #00FF00]{password_found}")),
            border_style="green", box=box.HEAVY, padding=(1,4)
        ))
    else:
        console.print(f" [{CURRENT_HEX}][x][/] Failure: Termination without result.")

    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        stop_search.set()
        console.print(f"\n [{CURRENT_HEX}][!][/] System Interrupted.")