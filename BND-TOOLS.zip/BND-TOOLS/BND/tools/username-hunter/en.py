import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
import os, time, math, asyncio, aiohttp, json

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.align import Align
from rich.live import Live
from rich.table import Table
from rich.layout import Layout
from rich import box

console = Console()

# ============== FARBE AUS CONFIG LADEN ==============
CONFIG_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config.json")

def hex_to_ansi(hex_code):
    hex_code = hex_code.lstrip('#')
    r = int(hex_code[0:2], 16)
    g = int(hex_code[2:4], 16)
    b = int(hex_code[4:6], 16)
    return f"\033[38;2;{r};{g};{b}m"

def get_current_color():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                theme = config.get("theme", "BLUE")
                colors = {
                    "RED": "#ff0000",
                    "GREEN": "#00ff00", 
                    "BLUE": "#0000ff",
                    "YELLOW": "#ffff00",
                    "PURPLE": "#9b00ff",
                    "CYAN": "#00ffff",
                    "ORANGE": "#ff6600",
                    "PINK": "#ff69b4",
                    "LIME": "#bfff00",
                    "WHITE": "#ffffff",
                    "ROSE": "#ff0088",
                    "GOLD": "#ffd700"
                }
                hex_color = colors.get(theme, "#0000ff")
                return hex_to_ansi(hex_color), hex_color, theme
    except:
        pass
    return "\033[38;2;0;0;255m", "#0000ff", "BLUE"

CURRENT_COLOR, CURRENT_HEX, CURRENT_THEME = get_current_color()
RESET = "\033[0m"

# BND-TOOLS Banner
ASCII = rf"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
"""

SITES = [
    ("GitHub", "https://github.com/{}", "GitHub"),
    ("Twitter", "https://twitter.com/{}", "Twitter/X"),
    ("Instagram", "https://instagram.com/{}", "Instagram"),
    ("TikTok", "https://tiktok.com/@{}", "TikTok"),
    ("Reddit", "https://reddit.com/u/{}", "Reddit"),
    ("Twitch", "https://twitch.tv/{}", "Twitch"),
    ("YouTube", "https://youtube.com/@{}", "YouTube"),
    ("Steam", "https://steamcommunity.com/id/{}", "Steam"),
    ("Pinterest", "https://pinterest.com/{}", "Pinterest"),
    ("Telegram", "https://t.me/{}", "Telegram"),
    ("DailyMotion", "https://www.dailymotion.com/{}", "DailyMotion"),
    ("SoundCloud", "https://soundcloud.com/{}", "SoundCloud"),
    ("Roblox", "https://www.roblox.com/user.aspx?username={}", "Roblox")
]

def boot():
    if sys.platform.startswith("win"):
        os.system("title BND-TOOLS // USERNAME HUNTER // OSINT CORE")
    os.system("cls" if os.name == "nt" else "clear")
    sys.stdout.write("\033[?25l")
    lines = ASCII.strip("\n").split("\n")
    t0 = time.time()
    try:
        while time.time() - t0 < 1.4:
            t = time.time() - t0
            sys.stdout.write("\033[H\n")
            for line in lines:
                sys.stdout.write("  ")
                for c, ch in enumerate(line):
                    if ch == " ":
                        sys.stdout.write(" ")
                    else:
                        brightness = max(80, min(255, int(150 + 105 * math.sin(t * 10 - c * 0.2))))
                        if CURRENT_THEME == "RED":
                            sys.stdout.write(f"\033[38;2;{brightness};0;0m{ch}")
                        elif CURRENT_THEME == "GREEN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};0m{ch}")
                        elif CURRENT_THEME == "BLUE":
                            sys.stdout.write(f"\033[38;2;0;0;{brightness}m{ch}")
                        elif CURRENT_THEME == "YELLOW":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};0m{ch}")
                        elif CURRENT_THEME == "PURPLE":
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                        elif CURRENT_THEME == "CYAN":
                            sys.stdout.write(f"\033[38;2;0;{brightness};{brightness}m{ch}")
                        elif CURRENT_THEME == "ORANGE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};0m{ch}")
                        elif CURRENT_THEME == "PINK":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness//2};{brightness//2}m{ch}")
                        elif CURRENT_THEME == "WHITE":
                            sys.stdout.write(f"\033[38;2;{brightness};{brightness};{brightness}m{ch}")
                        else:
                            sys.stdout.write(f"\033[38;2;{brightness//2};0;{brightness}m{ch}")
                sys.stdout.write("\033[0m\n")
            sys.stdout.flush()
            time.sleep(0.025)
    finally:
        sys.stdout.write("\033[?25h\033[0m")
    os.system("cls" if os.name == "nt" else "clear")

async def check_site(session, url, name):
    try:
        async with session.get(url, timeout=5) as r:
            return name, r.status == 200
    except:
        return name, False

async def run_hunt(user, update_fn):
    async with aiohttp.ClientSession(headers={"User-Agent": "Mozilla/5.0"}) as session:
        tasks = []
        for name, url_tmpl, _ in SITES:
            tasks.append(check_site(session, url_tmpl.format(user), name))
        
        results = []
        for i, task in enumerate(asyncio.as_completed(tasks)):
            res = await task
            results.append(res)
            update_fn(res, i+1, len(SITES))
        return results

def main():
    boot()
    console.print(Align.center(Panel(Text.from_markup(f"[bold {CURRENT_HEX}]BND-TOOLS[/] [dim]||[/] [white]USERNAME HUNTER V2[/]"), border_style=CURRENT_HEX, padding=(0, 5))))
    console.print()
    
    user = console.input(f" [bold {CURRENT_HEX}]└─▶[/] [white]Username to hunt >> ").strip()
    if not user: return

    layout = Layout()
    layout.split_column(Layout(name="header", size=4), Layout(name="body", ratio=1), Layout(name="footer", size=3))
    
    results = []
    current_status = "Initializing..."
    progress = 0

    def update(res, count, total):
        nonlocal results, current_status, progress
        results.append(res)
        current_status = f"Scanning {res[0]}..."
        progress = int((count / total) * 100)

    import threading
    def start_loop(): asyncio.run(run_hunt(user, update))
    threading.Thread(target=start_loop, daemon=True).start()

    with Live(layout, screen=True, refresh_per_second=10):
        while len(results) < len(SITES):
            layout["header"].update(Panel(Align.center(Text.from_markup(f"[bold {CURRENT_HEX}]HUNTING : [white]{user}[/] [dim]||[/] [{CURRENT_HEX}]{progress}%")), border_style=CURRENT_HEX))
            
            table = Table(box=box.SIMPLE, expand=True, header_style=f"bold {CURRENT_HEX}")
            table.add_column("PLATFORM", ratio=1)
            table.add_column("STATUS", ratio=1, justify="center")
            
            for name, found in sorted(results):
                if found:
                    status = f"[bold green][✓] FOUND[/]"
                else:
                    status = f"[dim {CURRENT_HEX}][x] MISSING[/]"
                table.add_row(name.upper(), status)
            
            layout["body"].update(Panel(table, title="[bold white]LIVE SCAN", border_style=CURRENT_HEX))
            layout["footer"].update(Panel(Align.center(Text.from_markup(f"[dim]BND OSINT ENGINE - SCANNING {current_status}[/]")), border_style=CURRENT_HEX))
            time.sleep(0.1)

    os.system("cls" if os.name == "nt" else "clear")
    console.print(Align.center(Panel(Text.from_markup(f"[bold green]REPORT COMPLETED FOR : {user}"), border_style="green", padding=(1, 5))))
    
    final_table = Table(box=box.ROUNDED, border_style=CURRENT_HEX, expand=True)
    final_table.add_column("Platform", style="white")
    final_table.add_column("Result", justify="center")
    final_table.add_column("Direct Link", style=f"{CURRENT_HEX} underline")
    
    for name, found in sorted(results):
        if found:
            url = [s[1] for s in SITES if s[0] == name][0].format(user)
            final_table.add_row(name, "[bold green]OPERATIONAL[/]", url)
    
    console.print(final_table)
    console.input(f"\n [dim]Press [bold {CURRENT_HEX}]ENTER[/] to exit...[/]")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: sys.exit()