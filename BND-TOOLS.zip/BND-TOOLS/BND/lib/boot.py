"""Cinematic boot sequence for BND TOOLS - Matrix Rain Effect."""
import os, sys, time, shutil, math, random
import msvcrt

# ── CMD HINTERGRUND AUF SCHWARZ SETZEN ──
if os.name == "nt":
    os.system("color 0F")  # 0 = schwarzer Hintergrund, F = weiße Schrift

# ══════════════════════════════════════════════════════════════
#   CINEMATIC BOOT SYSTEM  ·  BND TOOLS  ·  MATRIX EDITION
# ══════════════════════════════════════════════════════════════

LOGO_RAW = r"""
  ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
  ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
  ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
  ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
  ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
  ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
""".strip("\n")

# Farbe #0000CD (Mittelblau)
BND_BLUE_R, BND_BLUE_G, BND_BLUE_B = 0, 0, 205

# Matrix-Zeichen (nur Zahlen und Buchstaben)
MATRIX_CHARS = list("01ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@#$%^&*")

def _ansi_rgb(r, g, b):        return f"\033[38;2;{r};{g};{b}m"
def _ansi_reset():              return "\033[0m"
def _ansi_bold():               return "\033[1m"
def _ansi_goto(row, col):       return f"\033[{row};{col}H"
def _ansi_hide_cursor():        return "\033[?25l"
def _ansi_show_cursor():        return "\033[?25h"
def _ansi_clear():              return "\033[2J\033[H"

def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()

def check_skip_boot():
    if msvcrt.kbhit():
        msvcrt.getch()
        return True
    return False

# ── PHASE 1 : MATRIX REGEN EFFECT ─────────────────────────────
def _phase_matrix_rain(tw, th, duration=2.5):
    """Matrix-artiger Zahlenregen vor dem Banner in Blau."""
    # Jede Spalte hat: [y-position, speed, char]
    columns = []
    for x in range(tw):
        columns.append({
            'y': random.randint(-th, 0),
            'speed': random.randint(1, 5),
            'char': random.choice(MATRIX_CHARS),
            'bright': False
        })
    
    t0 = time.time()
    frame = 0
    
    while time.time() - t0 < duration:
        if check_skip_boot():
            return
        
        buf = [_ansi_hide_cursor()]
        
        for x in range(tw):
            col = columns[x]
            
            # Bewege den Tropfen nach unten
            col['y'] += col['speed']
            
            # Reset wenn unten angekommen
            if col['y'] > th:
                col['y'] = random.randint(-20, -1)
                col['speed'] = random.randint(1, 4)
                col['char'] = random.choice(MATRIX_CHARS)
                col['bright'] = False
            # Zufällig Helligkeit ändern
            if random.random() < 0.05:
                col['bright'] = not col['bright']
            
            # Zeichne Haupttropfen (heller)
            y_main = int(col['y'])
            if 1 <= y_main <= th:
                if col['bright']:
                    color = _ansi_rgb(100, 100, 255)  # Hellblau
                else:
                    color = _ansi_rgb(0, 0, 205)      # #0000CD
                buf.append(f"{_ansi_goto(y_main, x+1)}{color}{col['char']}")
            
            # Zeichne Nachleuchten (dunkler)
            for trail in range(1, 4):
                y_trail = y_main - trail
                if 1 <= y_trail <= th:
                    intensity = max(0, 100 - trail * 30)
                    trail_color = _ansi_rgb(0, 0, intensity)
                    trail_char = random.choice(MATRIX_CHARS)
                    buf.append(f"{_ansi_goto(y_trail, x+1)}{trail_color}{trail_char}")
        
        # Optional: "BND TOOLS" Text im Matrix-Stil oben anzeigen
        if frame % 10 == 0:
            title = ">>> BND TOOLS INITIALIZING <<<"
            x_title = (tw - len(title)) // 2
            title_color = _ansi_rgb(0, 150, 255)
            for i, ch in enumerate(title):
                if 1 <= x_title + i <= tw:
                    buf.append(f"{_ansi_goto(3, x_title + i)}{title_color}{ch}")
        
        _write("".join(buf))
        time.sleep(0.03)
        frame += 1
    
    # Cleanup
    _write(_ansi_clear())

# ── PHASE 2 : LOGO ASSEMBLY ───────────────────────────────────
def _phase_vector_build(tw, th, logo_lines):
    """Reveal logo line by line with a solid white laser bar."""
    lh, lw = len(logo_lines), max(len(l) for l in logo_lines)
    lt, ll = (th - lh) // 2, (tw - lw) // 2
    for r, line in enumerate(logo_lines):
        if check_skip_boot(): break
        row = lt + r
        if row < 1 or row > th: continue
        # Drawing bar
        bar = _ansi_rgb(255, 255, 255) + "\u2588" * tw
        _write(f"{_ansi_goto(row, 1)}{bar}")
        time.sleep(0.015)
        # Replace with logo part
        colored = f"{_ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)}{line}"
        _write(f"{_ansi_goto(row, 1)}{' '*tw}") 
        _write(f"{_ansi_goto(row, ll)}{colored}")
        time.sleep(0.01)

# ── PHASE 3 : IDLE mit weißer Animation DURCH BND TOOLS ────────
def _phase_vector_idle(tw, th, logo_lines):
    """High-tech idle state with scanning white animation."""
    lh, lw = len(logo_lines), max(len(l) for l in logo_lines)
    lt, ll = (th - lh) // 2, (tw - lw) // 2
    t0 = time.time()
    sweep_dir = 1
    sweep_x = 0
    while True:
        if msvcrt.kbhit():
            k = msvcrt.getch()
            if k == b'\r': return
        t = time.time() - t0
        buf = [_ansi_hide_cursor()]
        
        # Weiße Laufschrift-Animation durch BND TOOLS
        sweep_x += sweep_dir * 3
        if sweep_x > tw + 30:
            sweep_x = tw + 30
            sweep_dir = -1
        elif sweep_x < -30:
            sweep_x = -30
            sweep_dir = 1
        
        for r, line in enumerate(logo_lines):
            row = lt + r
            if row < 1 or row > th: continue
            colored = ""
            for c, char in enumerate(line):
                if char == " ":
                    colored += " "
                    continue
                abs_c = ll + c
                dist = abs(abs_c - sweep_x)
                if dist < 2:
                    colored += f"{_ansi_rgb(255, 255, 255)}{char}"
                elif dist < 5:
                    colored += f"{_ansi_rgb(100, 100, 255)}{char}"
                else:
                    colored += f"{_ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)}{char}"
            buf.append(f"{_ansi_goto(row, ll)}{colored}")
        
        # UI Borders in Blau (#0000CD)
        br_c = _ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)
        buf.append(f"{_ansi_goto(lt-2, ll-4)}{br_c}\u250c\u2500[ BND-TOOLS ]\u2500\u2510")
        buf.append(f"{_ansi_goto(lt+lh+1, ll-4)}{br_c}\u2514\u2500" + "\u2500" * (lw+5) + "\u2518")
        
        # PRESS ENTER TO ACCESS BND TOOLS - komplett in Blau
        prompt = "[ PRESS ENTER TO ACCESS BND TOOLS ]"
        p_row = lt + lh + 3
        prompt_color = _ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)
        buf.append(f"{_ansi_goto(p_row, (tw-len(prompt))//2)}{_ansi_bold()}{prompt_color}{prompt}{_ansi_reset()}")
        
        _write("".join(buf))
        time.sleep(0.016)

# ── ORCHESTRATOR ─────────────────────────────────────────────
def _cinematic_boot():
    """Complete boot sequence with Matrix rain effect."""
    logo_lines = LOGO_RAW.split("\n")
    tw, th = shutil.get_terminal_size((120, 35))
    
    # Windows ANSI Support
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.GetStdHandle(-11)
        m = ctypes.c_ulong()
        ctypes.windll.kernel32.GetConsoleMode(h, ctypes.byref(m))
        ctypes.windll.kernel32.SetConsoleMode(h, m.value | 0x0004)
    
    _write(_ansi_hide_cursor())
    try:
        # PHASE 1: Matrix Regen Effect
        _phase_matrix_rain(tw, th, duration=2.5)
        
        # PHASE 2: Logo Assembly
        _phase_vector_build(tw, th, logo_lines)
        
        # PHASE 3: Idle Animation
        _phase_vector_idle(tw, th, logo_lines)
    except Exception as e:
        pass
    finally:
        _write(_ansi_show_cursor() + _ansi_reset() + _ansi_clear())

# ── BOOT ENTRY ───────────────────────────────────────────────
def boot(skip_anim=False):
    """Start the cinematic boot sequence."""
    if not skip_anim:
        _cinematic_boot()
    else:
        print("BND TOOLS - Quick Boot Mode")

# ══════════════════════════════════════════════════════════════
#   run_bnd Funktion für Kompatibilität mit main.py
# ══════════════════════════════════════════════════════════════
def run_bnd():
    """Hauptfunktion für BND-TOOLS - startet die Boot-Animation"""
    boot(skip_anim=False)

if __name__ == "__main__":
    boot()