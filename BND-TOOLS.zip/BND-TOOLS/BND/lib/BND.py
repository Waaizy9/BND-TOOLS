"""Cinematic boot sequence for BND TOOLS - Heavy then Minimal Matrix Rain."""
import os, sys, time, shutil, math, random
import msvcrt

# ══════════════════════════════════════════════════════════════
#   CINEMATIC BOOT SYSTEM  ·  BND TOOLS  ·  DUAL MATRIX
# ══════════════════════════════════════════════════════════════

LOGO_RAW = r"""
    ┌─[ BND-TOOLS ]─┐

            ██████╗ ███╗   ██╗██████╗     ████████╗ ██████╗  ██████╗ ██╗     ███████╗
            ██╔══██╗████╗  ██║██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     ██╔════╝
            ██████╔╝██╔██╗ ██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ███████╗
            ██╔══██╗██║╚██╗██║██║  ██║       ██║   ██║   ██║██║   ██║██║     ╚════██║
            ██████╔╝██║ ╚████║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗███████║
            ╚═════╝ ╚═╝  ╚═══╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝╚══════╝

  └────────────────────────────────────────────────────────────────────────────────────────┘
""".strip("\n")

BND_BLUE_R, BND_BLUE_G, BND_BLUE_B = 0, 0, 205
MATRIX_CHARS = list("01")

def _ansi_rgb(r, g, b): return f"\033[38;2;{r};{g};{b}m"
def _ansi_reset(): return "\033[0m"
def _ansi_bold(): return "\033[1m"
def _ansi_goto(row, col): return f"\033[{row};{col}H"
def _ansi_hide_cursor(): return "\033[?25l"
def _ansi_show_cursor(): return "\033[?25h"
def _ansi_clear(): return "\033[2J\033[H"
def _write(s): sys.stdout.write(s); sys.stdout.flush()

def check_skip_boot():
    if msvcrt.kbhit():
        msvcrt.getch()
        return True
    return False

# ══════════════════════════════════════════════════════════════
#   HEAVY MATRIX RAIN (für den Anfang - viel Regen)
# ══════════════════════════════════════════════════════════════
heavy_columns = []

def init_heavy_matrix(tw, th):
    global heavy_columns
    heavy_columns = []
    for x in range(tw):
        if random.random() < 0.7:  # 70% der Spalten haben Regen
            heavy_columns.append({
                'x': x + 1,
                'y': random.randint(-th, 0),
                'speed': random.randint(1, 4),
                'char': random.choice(MATRIX_CHARS)
            })

def update_heavy_matrix(tw, th):
    global heavy_columns
    buf = []
    for col in heavy_columns[:]:
        col['y'] += col['speed']
        if col['y'] > th:
            col['y'] = random.randint(-30, -1)
            col['speed'] = random.randint(1, 4)
            col['char'] = random.choice(MATRIX_CHARS)
        
        y = int(col['y'])
        if 1 <= y <= th:
            intensity = random.randint(150, 255)
            color = _ansi_rgb(0, 0, intensity)
            buf.append(f"{_ansi_goto(y, col['x'])}{color}{col['char']}")
            
            # Trail (Nachleuchten)
            for t in range(1, 4):
                yt = y - t
                if 1 <= yt <= th:
                    trail_intensity = max(50, intensity - t * 50)
                    trail_color = _ansi_rgb(0, 0, trail_intensity)
                    buf.append(f"{_ansi_goto(yt, col['x'])}{trail_color}{random.choice(MATRIX_CHARS)}")
    
    # Neue Tropfen nachlegen
    for x in range(tw):
        if random.random() < 0.02 and len(heavy_columns) < tw:
            heavy_columns.append({
                'x': x + 1,
                'y': random.randint(-20, -1),
                'speed': random.randint(1, 4),
                'char': random.choice(MATRIX_CHARS)
            })
    
    return "".join(buf)

# ══════════════════════════════════════════════════════════════
#   MINIMAL MATRIX RAIN (für den Prompt - wenig Regen)
# ══════════════════════════════════════════════════════════════
minimal_columns = []

def init_minimal_matrix(tw, th):
    global minimal_columns
    minimal_columns = []
    # Nur ganz wenig Tropfen (ca. 10-15 Stück insgesamt)
    for _ in range(tw // 20):
        minimal_columns.append({
            'x': random.randint(1, tw),
            'y': random.randint(-th, 0),
            'speed': random.randint(1, 2),
            'char': random.choice(MATRIX_CHARS)
        })

def update_minimal_matrix(tw, th):
    global minimal_columns
    buf = []
    for col in minimal_columns[:]:
        col['y'] += col['speed']
        if col['y'] > th:
            minimal_columns.remove(col)
            continue
        
        y = int(col['y'])
        if 1 <= y <= th:
            if random.random() < 0.5:  # Nur manchmal anzeigen (flackernd)
                intensity = random.randint(80, 150)
                color = _ansi_rgb(0, 0, intensity)
                buf.append(f"{_ansi_goto(y, col['x'])}{color}{col['char']}")
    
    # Selten neue Tropfen hinzufügen
    if random.random() < 0.03 and len(minimal_columns) < tw // 15:
        minimal_columns.append({
            'x': random.randint(1, tw),
            'y': random.randint(-10, -1),
            'speed': random.randint(1, 2),
            'char': random.choice(MATRIX_CHARS)
        })
    
    return "".join(buf)

# ── PHASE 1 : HEAVY MATRIX RAIN (viel Regen) ──────────────────
def _phase_matrix_rain_heavy(tw, th, duration=2.5):
    init_heavy_matrix(tw, th)
    t0 = time.time()
    frame = 0
    
    while time.time() - t0 < duration:
        if check_skip_boot(): return
        buf = [_ansi_hide_cursor()]
        buf.append(update_heavy_matrix(tw, th))
        
        if frame % 10 == 0:
            title = ">>> BND TOOLS INITIALIZING <<<"
            x_title = (tw - len(title)) // 2
            title_color = _ansi_rgb(0, 150, 255)
            for i, ch in enumerate(title):
                if 1 <= x_title + i <= tw:
                    buf.append(f"{_ansi_goto(3, x_title + i)}{title_color}{ch}")
        
        _write("".join(buf))
        time.sleep(0.03)
        frame += 1
    _write(_ansi_clear())

# ── PHASE 2 : LOGO ASSEMBLY ───────────────────────────────────
def _phase_vector_build(tw, th, logo_lines):
    lh, lw = len(logo_lines), max(len(l) for l in logo_lines)
    lt, ll = (th - lh) // 2, (tw - lw) // 2
    for r, line in enumerate(logo_lines):
        if check_skip_boot(): break
        row = lt + r
        if row < 1 or row > th: continue
        bar = _ansi_rgb(255, 255, 255) + "█" * tw
        _write(f"{_ansi_goto(row, 1)}{bar}")
        time.sleep(0.015)
        colored = f"{_ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)}{line}"
        _write(f"{_ansi_goto(row, 1)}{' '*tw}") 
        _write(f"{_ansi_goto(row, ll)}{colored}")
        time.sleep(0.01)

# ── PHASE 3 : IDLE mit MINIMAL MATRIX (wenig Regen) ───────────
def _phase_vector_idle(tw, th, logo_lines):
    lh, lw = len(logo_lines), max(len(l) for l in logo_lines)
    lt, ll = (th - lh) // 2, (tw - lw) // 2
    sweep_dir = 1
    sweep_x = 0
    frame = 0
    
    # MINIMAL MATRIX (wenig Regen)
    init_minimal_matrix(tw, th)
    
    while True:
        if msvcrt.kbhit():
            k = msvcrt.getch()
            if k == b'\r': return
        buf = [_ansi_hide_cursor()]
        
        # MINIMAL MATRIX HINTERGRUND (nur ganz wenig, nicht überfüllend)
        buf.append(update_minimal_matrix(tw, th))
        
        # WEIßE ANIMATION durch BND TOOLS
        sweep_x += sweep_dir * 3
        if sweep_x > tw + 30:
            sweep_x = tw + 30
            sweep_dir = -1
        elif sweep_x < -30:
            sweep_x = -30
            sweep_dir = 1
        
        for r, line in enumerate(logo_lines):
            row = lt + r
            if row < 1 or row > th: continue
            colored = ""
            for c, char in enumerate(line):
                if char == " ":
                    colored += " "
                    continue
                abs_c = ll + c
                dist = abs(abs_c - sweep_x)
                if dist < 2:
                    colored += f"{_ansi_rgb(255, 255, 255)}{char}"
                elif dist < 5:
                    colored += f"{_ansi_rgb(100, 100, 255)}{char}"
                else:
                    colored += f"{_ansi_rgb(BND_BLUE_R, BND_BLUE_G, BND_BLUE_B)}{char}"
            buf.append(f"{_ansi_goto(row, ll)}{colored}")
        
        # 🔥 PROMPT mit Puls + Unterstrich (ohne Glitch)
        prompt = "PRESS ENTER TO ACCESS BND TOOLS"
        p_row = lt + lh + 3
        p_x = (tw - len(prompt)) // 2
        
        # Pulsierender Effekt
        pulse = int(100 + 155 * (frame % 30) / 30)
        prompt_color = _ansi_rgb(0, 0, pulse)
        
        # Haupt-Prompt
        buf.append(f"{_ansi_goto(p_row, p_x)}{_ansi_bold()}{prompt_color}{prompt}{_ansi_reset()}")
        
        # Animierter Unterstrich (läuft hin und her)
        underscore_pos = int((frame % (len(prompt) * 2)))
        if underscore_pos > len(prompt):
            underscore_pos = len(prompt) * 2 - underscore_pos
        buf.append(f"{_ansi_goto(p_row + 1, p_x + underscore_pos)}{_ansi_rgb(0, 150, 255)}^")
        
        _write("".join(buf))
        time.sleep(0.04)
        frame += 1

# ── ORCHESTRATOR ─────────────────────────────────────────────
def _cinematic_boot():
    logo_lines = LOGO_RAW.split("\n")
    tw, th = shutil.get_terminal_size((120, 35))
    
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.GetStdHandle(-11)
        m = ctypes.c_ulong()
        ctypes.windll.kernel32.GetConsoleMode(h, ctypes.byref(m))
        ctypes.windll.kernel32.SetConsoleMode(h, m.value | 0x0004)
    
    _write(_ansi_hide_cursor())
    try:
        # PHASE 1: HEAVY Matrix Rain (viel Regen)
        _phase_matrix_rain_heavy(tw, th, duration=2.5)
        
        # PHASE 2: Logo Assembly
        _phase_vector_build(tw, th, logo_lines)
        
        # PHASE 3: Idle mit MINIMAL Matrix (wenig Regen)
        _phase_vector_idle(tw, th, logo_lines)
    except Exception as e:
        pass
    finally:
        _write(_ansi_show_cursor() + _ansi_reset() + _ansi_clear())

def boot(skip_anim=False):
    if not skip_anim:
        _cinematic_boot()
    else:
        print("BND TOOLS - Quick Boot Mode")

if __name__ == "__main__":
    boot()