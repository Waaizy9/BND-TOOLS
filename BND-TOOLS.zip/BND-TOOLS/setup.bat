@echo off
title BND-TOOLS v2.0 - Setup
color 0A
cls

echo ================================================
echo    BND-TOOLS v2.0 - Setup Wizard
echo ================================================
echo.

cd /d "%~dp0"

echo [1/4] Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo [ERROR] Python not found!
    echo Please download and install Python 3.8+
    echo https://python.org/downloads/
    echo.
    pause
    exit /b 1
)

echo.
echo [2/4] Installing dependencies...
pip install --upgrade pip -q
pip install requests rich colorama -q
echo [OK] Dependencies installed!

echo.
echo [3/4] Creating directories...
if not exist "BND\config" mkdir "BND\config"
if not exist "BND\data" mkdir "BND\data"
if not exist "BND\screenshots" mkdir "BND\screenshots"
if not exist "BND\tools\custom" mkdir "BND\tools\custom"
echo [OK] Directories created!

echo.
echo [4/4] Creating config files...
if not exist "BND\config\settings.json" (
    echo {} > "BND\config\settings.json"
)

echo.
echo ================================================
echo    Setup complete!
echo ================================================
echo.
echo You can now run BND-TOOLS with: start.bat
echo.
pause