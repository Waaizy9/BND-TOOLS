@echo off
title BND-TOOLS v2.0 - Ultimate Boot System
color 1F
cls

echo.
echo ================================================
echo    BND-TOOLS v2.0 - Starting...
echo ================================================
echo.

cd /d "%~dp0"

echo [*] Current directory: %CD%
echo.

echo [*] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo Please install Python 3.8 or higher
    echo Download: https://python.org/downloads/
    pause
    exit /b 1
)
python --version
echo.

echo [*] Checking dependencies...
python -c "import requests" >nul 2>&1
if errorlevel 1 (
    echo [*] Installing requests...
    pip install requests -q
)
python -c "import rich" >nul 2>&1
if errorlevel 1 (
    echo [*] Installing rich...
    pip install rich -q
)
python -c "import colorama" >nul 2>&1
if errorlevel 1 (
    echo [*] Installing colorama...
    pip install colorama -q
)
echo [OK] Dependencies OK
echo.

echo [*] Checking BND directory...
if not exist "BND\main.py" (
    echo [ERROR] BND\main.py not found!
    echo.
    echo Directory structure:
    dir
    echo.
    pause
    exit /b 1
)
echo [OK] BND\main.py found
echo.

echo [*] Checking lib directory...
if not exist "BND\lib" (
    echo [ERROR] BND\lib not found!
    pause
    exit /b 1
)
echo [OK] BND\lib found
echo.

echo [*] Checking boot module...
if exist "BND\lib\boot.py" (
    echo [OK] BND\lib\boot.py found
) else (
    echo [WARN] BND\lib\boot.py not found
    echo [*] Creating boot.py...
    echo from lib.BND import run_bnd > BND\lib\boot.py
    echo [OK] boot.py created
)
echo.

echo [*] Launching BND-TOOLS...
echo.
echo ================================================
echo.

cd /d "%~dp0BND"

python main.py

if errorlevel 1 (
    echo.
    echo ================================================
    echo [ERROR] BND-TOOLS crashed!
    echo ================================================
    echo.
    echo Possible solutions:
    echo 1. Run setup.bat first
    echo 2. Check Python version
    echo 3. Check lib\boot.py exists
    echo.
    pause
)

exit /b 0